/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 22, 2016
 *
 */
package com.rigsit.xanitizer.pub.callgraph;

import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;
import com.rigsit.xanitizer.pub.languageelements.ITypeDescriptor;

/**
 * The context to be used during call graph processing.
 * 
 * It allows to register taint sources, taint sinks and taint sanitizers for
 * this specific phase.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface ICallGraphAnalysisContext {
	/**
	 * Register a call-graph defined taint source.
	 * 
	 * @param sourceKindId
	 *            identifier of the source kind to be registered
	 * @param md
	 *            the method descriptor of the taint source being registered
	 * @param taintOut
	 *            comma-separated list of parameter positions of the taint
	 *            source; -1 is the return value, 0 the receiver, values from 1
	 *            the method argument positions
	 * @param simulationClassTDOrNull
	 *            null, or a class type descriptor; if non-null, only calls
	 *            originating in code belonging to package of this class are
	 *            used as taint sources
	 */
	void registerTaintSource(String sourceKindId, IMethodDescriptor md, String taintOut,
			ITypeDescriptor simulationClassTDOrNull);

	/**
	 * Register a call-graph defined taint sink.
	 * 
	 * @param sinkKindId
	 *            identifier of the sink kind to be registered
	 * @param md
	 *            the method descriptor of the taint sink being registered
	 * @param taintIn
	 *            comma-separated list of parameter positions of the taint sink;
	 *            0 is the receiver, values from 1 the method argument positions
	 * @param simulationClassTDOrNull
	 *            null, or a class type descriptor; if non-null, only calls
	 *            originating in code belonging to package of this class are
	 *            used as taint sinks
	 */
	void registerTaintSink(String sinkKindId, IMethodDescriptor md, String taintIn,
			ITypeDescriptor simulationClassTDOrNull);

	/**
	 * Register a call-graph defined taint sanitizer.
	 * 
	 * @param sanitizerKindId
	 *            identifier of the sanitizer kind to be registered
	 * @param md
	 *            the method descriptor of the taint sanitizer being registered
	 * @param taintIn
	 *            semicolon-separated list of parameter positions where taint
	 *            might flow into the taint sanitizer; 0 is the receiver, values
	 *            from 1 the method argument positions
	 * @param taintOut
	 *            semicolon-separated list of comma-separated lists of parameter
	 *            positions where taint might flow out of the method when, at
	 *            the corresponding parameter position of taintIn, some taint
	 *            flows into the method call; -1 is the return value, 0 is the
	 *            receiver, and values from 1 represent the corresponding method
	 *            argument positions
	 */
	void registerTaintSanitizer(String sanitizerKindId, IMethodDescriptor md, String taintIn,
			String taintOut);
}
