/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 22, 2016
 *
 */
package com.rigsit.xanitizer.pub.callgraph;

/**
 * A non-null call graph processor is returned by a framework plugin if
 * something special needs to be done by the framework after the call graph has
 * been created.
 * 
 * The environment calls the call graph processor twice:
 * 
 * In the first phase, all non-null call graph processors are executed for a
 * first time, and
 * 
 * in the second phase, the processors are executed for the second time. This
 * way, the processing of the second phase can use results created by other
 * plugins during the processing of the first phase.
 *
 * This is meant to be implemented by the simulation code.
 */
public interface ICallGraphProcessor {

	/**
	 * The environment-called method for the first phase of call graph
	 * processing.
	 * 
	 * @param callGraphAnalysisContext
	 *            context to use
	 */
	void processCallGraphFirstPhase(ICallGraphAnalysisContext callGraphAnalysisContext);

	/**
	 * The environment-called method for the second phase of call graph
	 * processing.
	 * 
	 * @param callGraphAnalysisContext
	 *            context to use
	 */
	void processCallGraphSecondPhase(ICallGraphAnalysisContext callGraphAnalysisContext);

}
