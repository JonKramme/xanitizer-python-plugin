/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 29, 2016
 *
 */
package com.rigsit.xanitizer.pub.callgraph;

import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;

/**
 * A spot where some other method is called in a method.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface ICallSiteReference {

	/**
	 * The byte code position of this call site reference.
	 * 
	 * @return the byte code index of this call site
	 */
	int getByteCodeIdx();

	/**
	 * The method that is being called at this spot.
	 * 
	 * @return method being called
	 */
	IMethodDescriptor getDeclaredTarget();

	/**
	 * Returns if the called method is static or not
	 * 
	 * @return if this is a static call
	 */
	boolean isStatic();
}
