/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 22, 2016
 *
 */
package com.rigsit.xanitizer.pub.callgraph;

import com.rigsit.xanitizer.pub.languageelements.IMethod;

/**
 * Specification of a caller in the call graph.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface ICallerSpec {

	/**
	 * The method in which the call occurs.
	 * 
	 * @return the calling method
	 */
	IMethod getCallingMethod();

	/**
	 * The declared method descriptor to which the call occurs.
	 * 
	 * @return the call site reference of the call
	 */
	ICallSiteReference getCallSiteReference();

}
