/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Dec 13, 2016
 *
 */
package com.rigsit.xanitizer.pub.callgraph;

import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;

/**
 * Special call graph processor for Spring MVC that is mainly implemented inside
 * Xanitizer.
 * 
 * Not meant to be implemented by plugin code.
 */
public interface ISpringMVCCallGraphProcessor extends ICallGraphProcessor {

	/**
	 * Register in the call graph processor that for some method, an associated
	 * view template has been identified.
	 * 
	 * @param methodDescriptor method for which a view template has been found
	 */
	void registerThatHandlerMethodHasAViewTemplate(IMethodDescriptor methodDescriptor);

}
