/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Apr 22, 2015
 *
 */
package com.rigsit.xanitizer.pub.codegeneration;

/**
 * This enum type describes how code should be generated that executes several
 * alternatives.
 */
public enum ControlFlowOfAlternativeInvocation {
	/**
	 * The alternatives are to be executed in a switch, selecting on a
	 * non-deterministic value, with a default case.
	 * 
	 * This should be used if data flows between the alternatives ARE NOT to be
	 * analyzed.
	 */
	SWITCH,

	/**
	 * The alternatives are to be executed in a switch, selecting on a
	 * non-deterministic value, with a loop around the switch, and a default
	 * label using which the loop is left.
	 * 
	 * This should be used if data flows between the alternatives ARE to be
	 * analyzed.
	 */
	SWITCH_IN_LOOP,
}