/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 16, 2016
 *
 */
package com.rigsit.xanitizer.pub.codegeneration;

import java.io.IOException;
import java.util.LinkedHashMap;

import com.rigsit.xanitizer.pub.languageelements.IMethodSelector;
import com.rigsit.xanitizer.pub.languageelements.ITypeDescriptor;

/**
 * Functionality for generating Java code for one simulation class.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IFrameworkSimulationClassCodeGenerator {

	/**
	 * The class being constructed
	 * 
	 * @return the class being constructed
	 */
	ITypeDescriptor getClassTD();

	/**
	 * Start a new method
	 * 
	 * @param prefix
	 *            a string that is generated (after replacing forbidden
	 *            characters) into the first part of the method name
	 * 
	 * @param useFrameworkSpecificSuffix
	 *            the last part of the method name is either a standard name (if
	 *            param==false) or a framework specific name (if param==true and
	 *            such a name is given for the current framework)
	 * 
	 * @return a method code generator to be used for specifying a method body
	 *         or null if the method name is not valid
	 */
	IFrameworkSimulationMethodCodeGenerator startNewZeroArgumentVoidSimulationMethodOrNull(
			String prefix, boolean useFrameworkSpecificSuffix);

	/**
	 * Determine a simulation method name
	 * 
	 * @param prefix
	 *            will be put into front of name
	 * 
	 * @param useFrameworkSpecificSuffix
	 *            the last part of the method is either a Standard name (if
	 *            false) or a framework specific name (if true and such a name
	 *            is given for the current framework)
	 * 
	 * @return the generated method name
	 */
	String mkMethodName(String prefix, boolean useFrameworkSpecificSuffix);

	/**
	 * Start a new method with a given name
	 * 
	 * @param methodHeader
	 *            the method header to use
	 * 
	 * @return a method code generator which is used for specifying a method
	 *         body
	 */
	IFrameworkSimulationMethodCodeGenerator startNewSimulationMethodOrNull(String methodHeader);

	/**
	 * Create a standard Java source code header for a method with the given
	 * method name and arguments.
	 * 
	 * @param methodName
	 *            the method name
	 * @param simulationMethodArguments
	 *            the method argument's names, and types
	 * @return null on failure, or a Java syntax method header
	 */
	String mkStandardHeaderOrNull(String methodName,
			LinkedHashMap<String, ITypeDescriptor> simulationMethodArguments);

	/**
	 * Add literal code to the class body
	 * 
	 * @param code
	 *            Java code to be added
	 * @throws IOException
	 *             if adding the code was not possible
	 */
	void add(String code) throws IOException;

	/**
	 * Finish the class and write out the generated code
	 * 
	 * @throws IOException
	 *             if writing the generated code to the disk was not possible
	 */
	void finish() throws IOException;

	/**
	 * Generate a secondary simulation method and return its selector; on
	 * failure, return null.
	 * 
	 * The primary method must be predefined, and have no argument. It will be
	 * invoked.
	 * 
	 * @param javaSpec
	 *            the java-style spec as given in a method pattern This is used
	 *            for the method header.
	 * @param nameComponentOfSecondarySimulationMethodToBeCreated
	 *            name component of the method to be created
	 * @param nameOfPrimarySimulationMethod
	 *            name of the primary simulation method to call in the body; may
	 *            have no argument
	 * @param methodCommentOrNull
	 *            comment for method, or null
	 * @return the method selector of the generated method, and if the method is
	 *         static
	 * @throws IOException
	 *             if generating the method code was not possible
	 */
	IMethodSelector generateSecondarySimulationMethodAndReturnMethodSelectorOrNull(String javaSpec,
			String nameComponentOfSecondarySimulationMethodToBeCreated,
			String nameOfPrimarySimulationMethod, String methodCommentOrNull) throws IOException;

	/**
	 * Return the method name for a sanitizer method. As a side effect, records
	 * that a sanitzer method must be generated for the class.
	 * 
	 * @return a method name to be used for sanitization
	 */
	String mkSanitizerMethodName();
}
