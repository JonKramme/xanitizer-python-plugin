/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 12, 2016
 *
 */
package com.rigsit.xanitizer.pub.codegeneration;

import java.io.IOException;

import com.rigsit.xanitizer.pub.languageelements.IClass;
import com.rigsit.xanitizer.pub.languageelements.IField;
import com.rigsit.xanitizer.pub.languageelements.IMethod;

/**
 * Functionality for creating Java simulation code, possibly in several class
 * files.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IFrameworkSimulationCodeGenerator {

	/**
	 * @param classFQNOrSimpleName
	 *            the class name to use; if it is a fully qualified name, the
	 *            package from this is used, otherwise, a standard package is
	 *            generated
	 * @param classCommentOrNull
	 *            null, or a comment for the class
	 * @param simulationMethodNameSuffixOrNull
	 *            a suffix to be used when generating method names for generated
	 *            methods (for readability); if null, no special suffix will be
	 *            used
	 * @param compilationOrderNumberOrMinus1
	 *            the number in the compilation order for the generated class;
	 *            -1 if the code has no dependencies on any other code, and can
	 *            therefore be compiled first
	 * @return the code generator for the content of the class
	 * @throws IOException
	 *             if a problem occurred while starting the new Java code file
	 */
	IFrameworkSimulationClassCodeGenerator startNewClass(String classFQNOrSimpleName,
			String classCommentOrNull, String simulationMethodNameSuffixOrNull,
			int compilationOrderNumberOrMinus1) throws IOException;

	/**
	 * Start a new Java source class, using the given class header.
	 * 
	 * @param classHeader
	 *            the header to use for this class
	 * @param simulationMethodNameSuffixOrNull
	 *            a suffix to be used when generating method names for generated
	 *            methods (for readability); if null, no special suffix will be
	 *            used
	 * @param compilationOrderNumberOrMinus1
	 *            the number in the compilation order for the generated class;
	 *            -1 if the code has no dependencies on any other code, and can
	 *            therefore be compiled first
	 * @return the code generator for the content of the class
	 * @throws IOException
	 *             if a problem occurred while starting the new Java code file
	 */
	IFrameworkSimulationClassCodeGenerator startNewClassWithGivenHeader(String classHeader,
			String simulationMethodNameSuffixOrNull, int compilationOrderNumberOrMinus1)
			throws IOException;

	/**
	 * Register that public access is needed for the given method
	 * 
	 * @param method
	 *            the method for which public access is needed
	 * 
	 * @return if the method is public, or can be made public
	 */
	boolean registerThatPublicAccessIsNeeded(IMethod method);

	/**
	 * Register that public access is needed for the given field
	 * 
	 * @param field
	 *            the field for which public access is needed
	 * 
	 * @return if the method is public, or can be made public
	 */
	boolean registerThatPublicAccessIsNeeded(IField field);

	/**
	 * Register that public access is needed for the given class
	 * 
	 * @param clazz
	 *            the class for which public access is needed
	 * 
	 * @return if the method is public, or can be made public
	 */
	boolean registerThatPublicAccessIsNeeded(IClass clazz);

	/**
	 * The package root used for Xanitizer-generated code, with dots as
	 * separators, and without a trailing dot
	 * 
	 * @return the package root used for classes generated during code
	 *         generation
	 */
	String getPkgRootForGeneratedCode();

	/**
	 * The package root used for framework simulation code, with dots as
	 * separators, and without a trailing dot
	 * 
	 * @return the package root used for framework simulation code
	 */
	String getPkgRootForFrameworkSimulationCode();
}
