/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 16, 2016
 *
 */
package com.rigsit.xanitizer.pub.codegeneration;

import java.io.IOException;

import com.rigsit.xanitizer.pub.languageelements.IClass;
import com.rigsit.xanitizer.pub.languageelements.IField;
import com.rigsit.xanitizer.pub.languageelements.IMethod;
import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;
import com.rigsit.xanitizer.pub.languageelements.IMethodSelector;
import com.rigsit.xanitizer.pub.languageelements.IMethodToBeInvokedInfo;
import com.rigsit.xanitizer.pub.languageelements.ITypeDescriptor;
import com.rigsit.xanitizer.pub.plugin.IFrameworkSimulationContext;

/**
 * Simulation code generation for the content of one method, basic
 * functionality.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IFrameworkSimulationMethodCodeGenerator {

	/**
	 * The type in which the method is being constructed.
	 * 
	 * @return the type
	 */
	ITypeDescriptor getClassTD();

	/**
	 * The selector of the method being constructed.
	 * 
	 * @return the selector
	 */
	IMethodSelector getMethodSelector();

	/**
	 * Add the given string to the generated method body.
	 * 
	 * @param code
	 *            code to be appended to method body
	 */
	void add(String code);

	/**
	 * If the last letter that has been generated is a line feed, replace it by
	 * a space.
	 * 
	 * Useful, for example, in order to avoid line feeds at the end of short
	 * "case:" lines, before a final "break". This makes for shorter code.
	 */
	void turnLastLetterInMethodIntoSpaceIfItIsALinefeed();

	/**
	 * Add a comment in front of the method.
	 * 
	 * The text may consist of several lines. All lines are prefixes with "// "
	 * , a line feed is appended, if necessary, and the result is added in front
	 * of the method declaration.
	 * 
	 * @param comment
	 *            text that will be formatted as comment;
	 */
	void addCommentBeforeMethod(String comment);

	/**
	 * Add a comment to the body of the method.
	 * 
	 * The text may consist of several lines. All lines are prefixes with "// "
	 * , a line feed is appended, if necessary, and the result is added to the
	 * method body.
	 * 
	 * @param comment
	 *            text that will be formatted as comment;
	 */
	void addComment(String comment);

	/**
	 * Generates a declaration of a new variable, of the given type. Returns the
	 * variable name.
	 * 
	 * The generated declaration is not terminated by a semicolon, so that an
	 * assignment might be added.
	 * 
	 * @param td
	 *            type of generated variable
	 * @param makeFinal
	 *            if the variable is to be declated final
	 * @return name of generated variable
	 */
	String addDeclOfNewVarWOSemicolon(ITypeDescriptor td, boolean makeFinal);

	/**
	 * Convenience method: generate a call to a void method, without a receiver,
	 * with the given argument list.
	 * 
	 * @param methodName
	 *            name of method to be called
	 * @param arguments
	 *            Java syntax texts of the arguments to be used for call
	 */
	void addLocalCallOfVoidMethod(String methodName, String... arguments);

	/**
	 * Create code for invoking a factory method for the given type.
	 * 
	 * @param javaSyntaxTypeFQN
	 *            type for which to call the factory method, in Java syntax
	 * @param declareAsTaintSource
	 *            if true, the factory invocation is registered as a taint
	 *            source
	 * @return the code that invokes the factory method
	 */
	String mkCodeForFactoryCall(String javaSyntaxTypeFQN, boolean declareAsTaintSource);

	/**
	 * Create code for invoking a factory method for the given type.
	 * 
	 * @param td
	 *            type for which to call the factory method
	 * @param declareAsTaintSource
	 *            if true, the factory invocation is registered as a taint
	 *            source
	 * @return the code that invokes the factory method
	 */
	String mkCodeForFactoryCall(ITypeDescriptor td, boolean declareAsTaintSource);

	/**
	 * Start a switch, optionally in a loop.
	 * 
	 * Can be used inside another switch/loop construct (the code generator
	 * manages a stack of nested loops).
	 * 
	 * Must be closed with corresponding <code>addSwitchLoopEnd</code>.
	 * 
	 * @param controlFlow
	 *            the kind of switch/loop combination to start
	 * 
	 * @param loopLabel
	 *            the label to use in case of a loop so that the loop can be
	 *            left prematurely
	 */
	void addSwitchLoopStart(ControlFlowOfAlternativeInvocation controlFlow, String loopLabel);

	/**
	 * End a switch/loop combination.
	 */
	void addSwitchLoopEnd();

	/**
	 * Generate code for an array initializer.
	 * 
	 * The given type must be an array type. The necessary number of opening
	 * braces are generated, the given code for the inner element(s) is added,
	 * and the closing braces are generated.
	 * 
	 * @param td
	 *            an array type
	 * @param innerElementsJavaCode
	 *            code to be used for the inner array element(s)
	 */
	void addArrayInitializer(ITypeDescriptor td, String innerElementsJavaCode);

	/**
	 * Generate casts that work from a source type to a target type
	 * 
	 * @param targetType
	 *            the target type
	 * @param srcType
	 *            the source type
	 * @param forceCastIfSrcAndTgtAreDifferent
	 *            normally if the types are assignment compatible, no casts are
	 *            generated; using this flag, generation of casts is forced for
	 *            different source and target types
	 */
	void addCastsFromType(ITypeDescriptor targetType, ITypeDescriptor srcType,
			boolean forceCastIfSrcAndTgtAreDifferent);

	/**
	 * Generate code that reads a field, and return the (new) variable
	 * containing the result
	 * 
	 * @param field
	 *            field to be read
	 * @param instanceVarOrNullOrEmpty
	 *            instance variable on which to read the field; if the field is
	 *            static, null.
	 * @return the name of the result variable
	 */
	String addFieldAccessGet(IField field, String instanceVarOrNullOrEmpty);

	/**
	 * Generate code that writes a value to a field
	 * 
	 * @param field
	 *            field to be written to
	 * @param instanceVarOrNull
	 *            instance variable on which to read the field; if the field is
	 *            static, null is used, since no instance variable is needed.
	 * @param valueVar
	 *            the value to be written
	 */
	void addFieldAccessPut(IField field, String instanceVarOrNull, String valueVar);

	/**
	 * Specify that the method being constructed is to be used as a start
	 * method, i.e. as an entry point from outside, when the call graph is being
	 * constructed.
	 */
	void registerAsStartMethod();

	/**
	 * Register that the given variable is of the given type.
	 * 
	 * This information is used when necessary casts are determined for
	 * situations in which this variable will be used
	 * 
	 * @param definedVarName
	 *            name of variable that has been defined
	 * @param typeOfDefinedVar
	 *            type of the variable
	 */
	void registerDefinedVarNameToType(String definedVarName, ITypeDescriptor typeOfDefinedVar);

	/**
	 * Determine the registered type of a variable
	 * 
	 * @param varName
	 *            name of variable
	 * @return registered type, or null if no type has been registered
	 */
	ITypeDescriptor getTypeOfDefinedVarNameOrNull(String varName);

	/**
	 * Finish code for a simulation method. If the argument is non-null, a
	 * return statement returning that value is generated.
	 * 
	 * @param returnedExprOrNull
	 *            if non-null, a return statement with this expression is
	 *            generated
	 * 
	 * @return selector of generated simulation method
	 * 
	 * @throws IOException
	 *             if creation of the method text fails
	 */
	IMethodSelector finish(String returnedExprOrNull) throws IOException;

	/**
	 * Create an as-yet unused variable name.
	 * 
	 * @return the new variable name
	 */
	String mkNewVariableName();

	/**
	 * Create Java code that allows to instantiate an abstract class or an
	 * interface
	 * 
	 * @param classToBeInstantiated
	 *            might also be an abstract class or an interface
	 * @return Java code that instantiates the class
	 */
	String mkClassBodyForMakingClassInstantiationConcreteOrNull(IClass classToBeInstantiated);

	/**
	 * Register the given type as to be patched when compiling simulation code
	 * 
	 * In patched code, access to non-public methods or fields is possible from
	 * outside. For example, when the generated simulation code injects values
	 * into a private field, this private field would normally not be accessible
	 * from the simulation code, and thus, a compilation error would occur.
	 * 
	 * Xanitizer solves this problem by providing patched versions of classes to
	 * the compiler during framework simulation compilation. This method
	 * registers some time as needing to be used in a patched form during
	 * compilation.
	 * 
	 * @param classTD
	 *            a class to be patched during compilation
	 */
	void registerAsToBePatched(ITypeDescriptor classTD);

	/**
	 * If possible, create a string of Java text representing parameters for a
	 * method invocation.
	 * 
	 * If the string construction fails for some reason, null is returned
	 * 
	 * @param argumentsOrNull
	 *            if null, standard values (0, 0.0, null etc) are used for the
	 *            arguments; if not null, the array length must be equal to the
	 *            number of arguments, and the strings in the array must either
	 *            be (a) variable names, or (b) the literal Java text to be used
	 *            at the position, prefixed with '@'
	 * @param md
	 *            the method descriptor to be called
	 * @param methodOrNull
	 *            the method to be called, if it already exists
	 * @param shouldCheckForGenericity
	 *            flag telling if the method arguments should be checked for
	 *            genericity; if this flag is true and any argument has a
	 *            generic type variable argument, the return value will be null,
	 *            because Xanitizer is not able to determine the proper type;
	 *            note that is check is only possible for pre-existing methods,
	 *            i.e., when <code>methodOrNull</code> is not null
	 * @return null on failure, otherwise Java code for the parameters of the
	 *         method invocation
	 */
	String mkParametersOrNull(String[] argumentsOrNull, IMethodDescriptor md, IMethod methodOrNull,
			boolean shouldCheckForGenericity);

	/**
	 * The current framework simulation context.
	 * 
	 * @return the current framework simulation context
	 */
	IFrameworkSimulationContext getContext();

	/**
	 * Add a call to the method, returning if code generation succeeded
	 *
	 * @param receiverVarOrNull
	 *            variable name for instance to call on for instance methods,
	 *            and null for constructors or static methods
	 * @param calledMethod
	 *            description of the method to be invoked
	 * @param argumentsOrNull
	 *            null (in which case default arguments are generated, i.e. 0,
	 *            null, 0.0 etc) or an array of strings with an entry for each
	 *            parameter; these are either variable names, or literal Java
	 *            expressions prefixed with '@'
	 * @param returnVarOrEmpty
	 *            an empty string, or the name of an already declared variable
	 *            to which the method call's result is to be assigned.
	 * @param returnVarTDOrNull
	 *            non-null type of the return variable, or null if the return
	 *            variable name is empty
	 * @param shouldCheckForGenericity
	 *            flag telling if the method arguments should be checked for
	 *            genericity; if this flag is true and any argument has a
	 *            generic type variable argument, the return value will be
	 *            false, because Xanitizer is not able to determine the proper
	 *            type; note that is check is only possible for pre-existing
	 *            methods in <code>calledMethod</code>
	 * @return if code generation succeeded
	 */
	boolean addCall(String receiverVarOrNull, IMethodToBeInvokedInfo calledMethod,
			String[] argumentsOrNull, String returnVarOrEmpty, ITypeDescriptor returnVarTDOrNull,
			boolean shouldCheckForGenericity, boolean returnVarAlreadyExists);

}
