/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 12, 2016
 *
 */
package com.rigsit.xanitizer.pub.codegeneration;

import com.rigsit.xanitizer.pub.languageelements.IFieldDescriptor;
import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;
import com.rigsit.xanitizer.pub.languageelements.ITypeDescriptor;

/**
 * Supports the simulation of a simple kind of injection, which might be
 * adequate for typical situations.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface ISimpleInjectionInfo {

	/**
	 * Checks if the type has a field to be injected.
	 * 
	 * @param td
	 *            the type to be checked
	 * 
	 * @return if the type has an injected field
	 */
	boolean hasInjectedField(ITypeDescriptor td);

	/**
	 * Checks if the type has a setter that can be used for injection.
	 * 
	 * @param td
	 *            the type to be checked
	 * 
	 * @return if the type has a setter for an injected object
	 */
	boolean hasSetterForInjectedObject(ITypeDescriptor td);

	/**
	 * Checks if the method is a setter that can be used for injection.
	 * 
	 * @param md
	 *            the method to be checked
	 * 
	 * @return if the method is a setter for an injected object
	 */
	boolean isSetterForInjectedObject(IMethodDescriptor md);

	/**
	 * Determines the type being injected by the given setter, or null.
	 * 
	 * @param setter
	 *            the method to be checked
	 * 
	 * @return the type being injected by the setter, or null
	 */
	ITypeDescriptor getTypeToInjectInSetterOrNull(IMethodDescriptor setter);

	/**
	 * Checks if the field is injected.
	 * 
	 * @param fieldDescriptor
	 *            the field to be checked
	 * 
	 * @return if the field is injected
	 */
	boolean isInjected(IFieldDescriptor fieldDescriptor);
}
