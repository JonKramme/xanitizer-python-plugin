/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on 16.02.2017
 *
 */
package com.rigsit.xanitizer.pub.configitems;

import java.util.LinkedHashMap;

/**
 * GUI description for the corresponding configuration item.
 *
 */
public interface IConfigurationItemGUI {

	/**
	 * The available types of GUI elements to be used for the configuration
	 * items.
	 *
	 */
	enum GUIElement {
		WORKSPACE_PATTERN, SPINNER, TEXT_FIELD, FILE_FIELD, COMBO_BOX, DEFAULT;
	}

	static final IConfigurationItemGUI DEFAULT = new IConfigurationItemGUI() {

	};

	/**
	 * The type of GUI element to be used for the configuration item.
	 * 
	 * @return the kind of GUI element to use
	 */
	default GUIElement getGUIElement() {
		return GUIElement.DEFAULT;
	}

	/**
	 * Only relevant for spinners: the minimum value.
	 * 
	 * @return the minimum value of the range of the spinner
	 */
	default int getMinimumValueForSpinner() {
		return 0;
	}

	/**
	 * Only relevant for spinners: the maximum value.
	 * 
	 * @return the maximum value of the range of the spinner
	 */
	default int getMaximumValueForSpinner() {
		return 100;
	}

	/**
	 * Only relevant for spinners: the step size.
	 * 
	 * @return the step size of the spinner
	 */
	default int getIncrementForSpinner() {
		return 1;
	}

	/**
	 * Validates the current value; returns null if okay and a short error
	 * message otherwise.
	 * 
	 * @param currentValue
	 *            the text to be validated
	 * @return an error message or null
	 */
	default String validate(final Object currentValue) {
		return null;
	}

	default String[] getFileFilterForFileFields() {
		return new String[] {};
	}

	/**
	 * Only relevant for combo boxes: map from the alternatives to be displayed
	 * to their corresponding values.
	 * 
	 * @return the items to be displayed in the combo box, with their associated
	 *         values
	 */
	default LinkedHashMap<String, Object> getItemsForComboBox() {
		return EMPTY;
	}

	public static LinkedHashMap<String, Object> EMPTY = new LinkedHashMap<>();
}
