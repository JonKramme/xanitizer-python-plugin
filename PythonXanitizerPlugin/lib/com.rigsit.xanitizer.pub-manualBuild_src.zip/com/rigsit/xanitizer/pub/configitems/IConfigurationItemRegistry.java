/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 14, 2016
 *
 */
package com.rigsit.xanitizer.pub.configitems;

/**
 * Registry for problem types.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IConfigurationItemRegistry {

	/**
	 * Register a configuration item.
	 * 
	 * @param defaultValue
	 *            default value for this configuration item; must not be null
	 * @param configurationElementTagName
	 *            the XML element tag name to use; note that this is not checked
	 *            for admissibility - providing an invalid element name will
	 *            lead to the generated Xanitizer configuration files being
	 *            unreadable by Xanitizer.
	 * @param presentationName
	 *            short (one-line) description text for the configuration item
	 * @param description
	 *            longer (multi-line) description text for the configuration
	 *            item
	 * @param persistenceParser
	 *            parse support for turning strings read from persistence into
	 *            values and vice versa
	 * @param guiDescriptionOrNull
	 *            a GUI description for the configuration item in the
	 *            configuration editor, or null if the item should not be
	 *            figured in the GUI. To use the default GUI element determined
	 *            from the default value, you can use
	 *            <code>IConfigurationItemGUI.DEFAULT</code>.
	 * 
	 * @return if registration was successful
	 */
	<T> boolean registerConfigurationItem(T defaultValue, String configurationElementTagName,
			String presentationName, String description, IPersistenceParser<T> persistenceParser,
			IConfigurationItemGUI guiDescriptionOrNull);
}
