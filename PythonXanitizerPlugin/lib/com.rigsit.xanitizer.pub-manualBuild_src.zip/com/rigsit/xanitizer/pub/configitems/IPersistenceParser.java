/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Feb 10, 2017
 *
 */
package com.rigsit.xanitizer.pub.configitems;

/**
 * Transforms objects to strings and vice versa.
 * 
 * Mainly for use in persistence.
 *
 */
public interface IPersistenceParser<TYPE> {

	static final IPersistenceParser<Boolean> BOOLEAN = new IPersistenceParser<>() {

		@Override
		public Boolean mkValueOf(final String s) {
			return Boolean.parseBoolean(s);
		}

		@Override
		public String mkString(final Boolean val) {
			return val.toString();
		}
	};

	static final IPersistenceParser<String> STRING = new IPersistenceParser<>() {

		@Override
		public String mkValueOf(final String s) {
			return s;
		}

		@Override
		public String mkString(final String val) {
			return val.toString();
		}
	};

	static final IPersistenceParser<Integer> INTEGER = new IPersistenceParser<>() {

		@Override
		public Integer mkValueOf(final String s) {
			try {
				return Integer.parseInt(s);
			} catch (NumberFormatException e) {
				return -1;
			}
		}

		@Override
		public String mkString(final Integer val) {
			return val.toString();
		}
	};

	/**
	 * Create an object from a string representation.
	 * 
	 * @param s
	 *            the string to be parsed
	 * @return parse result
	 */
	TYPE mkValueOf(String s);

	/**
	 * Create a string representing an object.
	 * 
	 * @param val
	 *            value to be serialized to a string
	 * @return serialized form of argument
	 */
	String mkString(TYPE val);

}
