/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 16, 2016
 *
 */
package com.rigsit.xanitizer.pub.factory;

import com.rigsit.xanitizer.pub.languageelements.IClass;
import com.rigsit.xanitizer.pub.languageelements.IFieldDescriptor;
import com.rigsit.xanitizer.pub.languageelements.IMethod;
import com.rigsit.xanitizer.pub.languageelements.IMethodArgumentsAndReturnTypeDescriptor;
import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;
import com.rigsit.xanitizer.pub.languageelements.IMethodSelector;
import com.rigsit.xanitizer.pub.languageelements.IMethodToBeInvokedInfo;
import com.rigsit.xanitizer.pub.languageelements.ITypeDescriptor;

/**
 * A factory that produces Xanitizer-internal objects, wrapped appropriately so
 * that they can be used in the plugin code.
 *
 * Do not use this interface directly - rather, use the static wrapper methods
 * in class <code>StaticFactory</code>.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IStaticFactory {

	/**
	 * Create a type descriptor from a string representation, like
	 * "java.lang.String"
	 * 
	 * @param javaClassFQN
	 *            Java class FQN, with the special syntax that where inner
	 *            classes are separated with $ instead of with a dot; note that
	 *            generic types or primitive types are not supported, just fully
	 *            qualified class names in Java syntax
	 * 
	 * @return the type descriptor for the given string representation
	 */
	ITypeDescriptor mkTypeDescriptor(String javaClassFQN);

	/**
	 * Create a type descriptor from a string representation in internal form,
	 * like "Ljava/lang/String"
	 * 
	 * @param javaClassFQN
	 *            Java class FQN, with the special syntax that where inner
	 *            classes are separated with $ instead of with a dot
	 * 
	 * @return the type descriptor for the given string representation
	 */
	ITypeDescriptor mkTypeDescriptorFromInternalRepresentation(String javaClassFQN);

	/**
	 * Create a descriptor for the argument list and the return type or a method
	 * from a string representation.
	 * 
	 * The string representation is in the form
	 * "(Ljava/lang/String;)Ljava/lang/String;" for a method that has a string
	 * argument and returns a string.
	 * 
	 * @param stringRep
	 *            string representation of the argument list and return type
	 * @return the method arguments descriptor for the given string
	 */
	IMethodArgumentsAndReturnTypeDescriptor mkMethodArgumentsAndReturnTypeDescriptor(
			String stringRep);

	/**
	 * Create a method selector, consisting of a method name and a method
	 * arguments descriptor, from its the string representation.
	 * 
	 * The latter is in the form "toUpper(Ljava/lang/String;)Ljava/lang/String;"
	 * for a method named "toUpper" that has a string argument and returns a
	 * string.
	 * 
	 * @param stringRep
	 *            string representation of the method selector
	 * @return the method selector
	 */
	IMethodSelector mkMethodSelector(String stringRep, boolean isStatic);

	/**
	 * Create a method reference from a type descriptor and a method selector.
	 * 
	 * @param typeDescriptor
	 *            the class via which the method is being referenced
	 * @param methodSelector
	 *            name, argument type list, and return type of the method being
	 *            referenced
	 * @return the resulting method descriptor
	 */
	IMethodDescriptor mkMethodDescriptor(ITypeDescriptor typeDescriptor,
			IMethodSelector methodSelector);

	/**
	 * Create a field descriptor from a type descriptor, a field name, and a
	 * descriptor of the field's type
	 * 
	 * @param typeDescriptor
	 *            the class via which the field is being referenced
	 * @param fieldName
	 *            field name
	 * @param fieldTypeDescriptor
	 *            the type if the field
	 * @return the resulting
	 */
	IFieldDescriptor mkFieldDescriptor(ITypeDescriptor typeDescriptor, String fieldName,
			ITypeDescriptor fieldTypeDescriptor);

	/**
	 * Create a method-to-be-invoked info object from a method to be invoked,
	 * and the class via which it should be invoked.
	 * 
	 * @param methodToBeInvoked
	 *            the method to be invoked
	 * @param clazz
	 *            the class via which the method should be invoked
	 * @return the method
	 */
	IMethodToBeInvokedInfo mkMethodToBeInvokedInfo(IMethod methodToBeInvoked, IClass clazz);

	/**
	 * Create a method-to-be-invoked info object from a method to be invoked,
	 * and the class via which it should be invoked.
	 * 
	 * @param methodToBeInvoked
	 *            the method to be invoked
	 * @param access
	 *            the access code of the method to be invoked
	 * @param clazz
	 *            the class via which the method should be invoked
	 * @return the method
	 */
	IMethodToBeInvokedInfo mkMethodToBeInvokedInfo(IMethodSelector methodToBeInvoked, int access,
			ITypeDescriptor clazz);

	/**
	 * The package root for JSP-generated Java files, without a trailing dot.
	 * 
	 * @return the package root for JSP files
	 */
	String mkPkgRoot_JSP();

	/**
	 * The Java class name of the class generated for the given JSP template
	 * name.
	 * 
	 * @param jspTemplateName
	 *            the JSP template name for which to guess a Java class name
	 * 
	 * @return the Java class name that Xanitizer expects for a JSP template
	 *         name
	 */
	String guessJavaClassFQNForJSPTemplateName(String jspTemplateName);

	/**
	 * The standard kind id for taint sources in framework simulation code.
	 * 
	 * @return identifier for kind of taint sources for normal servlet requests
	 */
	String getTaintSourceKind_FrameworkSimulationServletRequest();

	/**
	 * The standard kind id for taint sinks in framework simulation code for
	 * servlet responses.
	 * 
	 * @return identifier for kind of taint sinks for normal servlet responses
	 */
	String getTaintSinkKind_FrameworkSimulationServletResponse();

	/**
	 * The standard kind id for taint sinks in framework simulation code for
	 * output that is not rendered, e.g., JSON strings.
	 * 
	 * @return identifier for kind of taint sinks for unrendered servlet
	 *         responses
	 */
	String getTaintSinkKind_FrameworkSimulationUnrenderedServletResponse();

	/**
	 * The standard kind id for XSS sanitizers.
	 * 
	 * @return identifier for kind of XSS sanitizers
	 */
	String getTaintSanitizerKind_XSSXanitizer();

	/**
	 * The only kind of intercepted method currently supported.
	 * 
	 * @return identifier for the kind of intercepted methods for servlet
	 *         dispatch
	 */
	String getInterceptedMethodKind_ServletDispatch();
}
