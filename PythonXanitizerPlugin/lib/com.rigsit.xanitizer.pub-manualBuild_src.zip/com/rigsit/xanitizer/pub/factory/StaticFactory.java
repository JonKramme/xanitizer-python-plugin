/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Oct 28, 2016
 *
 */
package com.rigsit.xanitizer.pub.factory;

import com.rigsit.xanitizer.pub.languageelements.IClass;
import com.rigsit.xanitizer.pub.languageelements.IFieldDescriptor;
import com.rigsit.xanitizer.pub.languageelements.IMethod;
import com.rigsit.xanitizer.pub.languageelements.IMethodArgumentsAndReturnTypeDescriptor;
import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;
import com.rigsit.xanitizer.pub.languageelements.IMethodSelector;
import com.rigsit.xanitizer.pub.languageelements.IMethodToBeInvokedInfo;
import com.rigsit.xanitizer.pub.languageelements.ITypeDescriptor;

public class StaticFactory {

	/**
	 * This is supplied by Xanitizer during run-time when the time has come.
	 * 
	 * Note that timing is critical: Methods in this class are using when
	 * initializing plugin classes, i.e., the initialization of this field must
	 * have happened before any plugin classes are loaded.
	 */
	private static IStaticFactory s_StaticFactory;

	public static void setStaticFactory(final IStaticFactory staticFactory) {
		s_StaticFactory = staticFactory;
	}

	public static IMethodSelector mkMethodSelector(final String stringRep, final boolean isStatic) {
		return s_StaticFactory.mkMethodSelector(stringRep, isStatic);
	}

	public static ITypeDescriptor mkTypeDescriptor(final String javaClassFQN) {
		return s_StaticFactory.mkTypeDescriptor(javaClassFQN);
	}

	public static ITypeDescriptor mkTypeDescriptorFromInternalRepresentation(
			final String internalTypeRepresentation) {
		return s_StaticFactory
				.mkTypeDescriptorFromInternalRepresentation(internalTypeRepresentation);
	}

	public static IMethodDescriptor mkMethodDescriptor(final ITypeDescriptor typeDescriptor,
			final IMethodSelector methodSelector) {
		return s_StaticFactory.mkMethodDescriptor(typeDescriptor, methodSelector);
	}

	public static IMethodArgumentsAndReturnTypeDescriptor mkMethodArgumentsAndReturnTypeDescriptor(
			final String stringRep) {
		return s_StaticFactory.mkMethodArgumentsAndReturnTypeDescriptor(stringRep);
	}

	public static IFieldDescriptor mkFieldDescriptor(final ITypeDescriptor typeDescriptor,
			final String fieldName, final ITypeDescriptor fieldTypeDescriptor) {
		return s_StaticFactory.mkFieldDescriptor(typeDescriptor, fieldName, fieldTypeDescriptor);
	}

	public static IMethodToBeInvokedInfo mkMethodToBeInvokedInfo(
			final IMethodSelector methodSelector, final int access, final ITypeDescriptor classTD) {
		return s_StaticFactory.mkMethodToBeInvokedInfo(methodSelector, access, classTD);
	}

	public static IMethodToBeInvokedInfo mkMethodToBeInvokedInfo(final IMethod method,
			final IClass calledClass) {
		return s_StaticFactory.mkMethodToBeInvokedInfo(method, calledClass);
	}

	public static String mkPkgRoot_JSP() {
		return s_StaticFactory.mkPkgRoot_JSP();
	}

	public static String guessJavaClassFQNForJSPTemplateName(final String jspTemplatName) {
		return s_StaticFactory.guessJavaClassFQNForJSPTemplateName(jspTemplatName);
	}

	public static String getTaintSourceKind_FrameworkSimulationServletRequest() {
		return s_StaticFactory.getTaintSourceKind_FrameworkSimulationServletRequest();
	}

	public static String getTaintSinkKind_FrameworkSimulationServletResponse() {
		return s_StaticFactory.getTaintSinkKind_FrameworkSimulationServletResponse();
	}

	public static String getTaintSinkKind_FrameworkSimulationUnrenderedServletResponse() {
		return s_StaticFactory.getTaintSinkKind_FrameworkSimulationUnrenderedServletResponse();
	}

	public static String getTaintSanitizerKind_XSSXanitizer() {
		return s_StaticFactory.getTaintSanitizerKind_XSSXanitizer();
	}

	public static String getInterceptedMethodKind_ServletDispatch() {
		return s_StaticFactory.getInterceptedMethodKind_ServletDispatch();
	}

}
