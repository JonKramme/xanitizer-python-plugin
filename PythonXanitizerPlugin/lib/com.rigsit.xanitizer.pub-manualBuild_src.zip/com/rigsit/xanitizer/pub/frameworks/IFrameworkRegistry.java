/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on 07.04.2020
 *
 */
package com.rigsit.xanitizer.pub.frameworks;

import com.rigsit.xanitizer.pub.plugin.PluginID;

/**
 * @author norma
 *
 */
public interface IFrameworkRegistry {
	/**
	 * Register that a framework exists in the plugin that might be switched on
	 * or off.
	 */
	void registerExistingFramework(PluginID pluginID, IFrameworkSpec frameworkSpec);
}
