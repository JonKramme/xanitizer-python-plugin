/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Apr 6, 2020
 *
 */
package com.rigsit.xanitizer.pub.frameworks;

/**
 * @author rust
 *
 */
public interface IFrameworkSpec {
	String getId();

	String getPresentationName();

	String getDescription();
}
