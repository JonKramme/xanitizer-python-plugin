/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 29, 2016
 *
 */
package com.rigsit.xanitizer.pub.instructions;

/**
 * Represents an instruction.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface IInstruction {
	/**
	 * The number of usage positions of this instruction
	 * 
	 * @return number of used register positions of this instruction
	 */
	int getNumberOfUses();

	/**
	 * The register for the given usage position.
	 * 
	 * @param useNo
	 *            usage position to be checked
	 * 
	 * @return register used in the given usage position
	 */
	int getUse(int useNo);
}
