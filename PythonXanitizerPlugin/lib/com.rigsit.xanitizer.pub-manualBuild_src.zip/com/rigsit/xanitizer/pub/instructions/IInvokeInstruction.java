/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 29, 2016
 *
 */
package com.rigsit.xanitizer.pub.instructions;

import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;

/**
 * Represents an invoke instruction.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface IInvokeInstruction extends IInstruction {

	/**
	 * Returns if this is a static invoke instruction or not
	 * 
	 * @return if the invoke instruction is static
	 */
	boolean isStatic();

	/**
	 * Returns if this is a special invoke instruction or not, i.e., a
	 * constructor call
	 * 
	 * @return if the invoke instruction is special
	 */
	boolean isSpecial();

	/**
	 * Register number of the receiver in this invoke instruction. If there is
	 * no receiver, -1.
	 * 
	 * @return receiver register, or -1
	 */
	int getReceiver();

	/**
	 * The method called in this instruction.
	 * 
	 * @return called method
	 */
	IMethodDescriptor getDeclaredTarget();

}
