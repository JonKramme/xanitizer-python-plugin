/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 29, 2016
 *
 */
package com.rigsit.xanitizer.pub.instructions;

import com.rigsit.xanitizer.pub.languageelements.ITypeDescriptor;

/**
 * A wrapper for a 'new' instruction that allocates memory for a new instance of
 * an object.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface INewInstruction extends IInstruction {

	/**
	 * Return the type of the instance being allocated.
	 * 
	 * @return the type being created
	 */
	ITypeDescriptor getConcreteType();

}
