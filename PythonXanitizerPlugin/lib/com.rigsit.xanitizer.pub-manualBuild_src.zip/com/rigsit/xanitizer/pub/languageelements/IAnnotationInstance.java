/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 16, 2016
 *
 */
package com.rigsit.xanitizer.pub.languageelements;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Represents a Java annotation.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IAnnotationInstance {

	/**
	 * The type descriptor of this annotation's type.
	 * 
	 * @return this annotation's type
	 */
	ITypeDescriptor getTypeDescriptor();

	/**
	 * The named arguments of this annotation.
	 * 
	 * @return named arguments of this annotation
	 */
	Map<String, IAnnotationValue> getNamedArguments();

	/**
	 * The unnamed arguments of this annotation, in the order specified. The
	 * arguments are all given as strings.
	 * 
	 * @return unnamed arguments of this annotation
	 */
	LinkedHashMap<ITypeDescriptor, String> getUnnamedArguments();
}
