/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 21, 2016
 *
 */
package com.rigsit.xanitizer.pub.languageelements;

import java.util.Map;

/**
 * A value used in a Java annotation.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IAnnotationValue {

	/**
	 * Tells if the annotation value is an array.
	 * 
	 * @return if this is an array
	 */
	boolean isArray();

	/**
	 * If the annotation value is an array, returns the content of the array;
	 * otherwise returns null.
	 * 
	 * @return content of array, for array annotation values; otherwise null
	 */
	IAnnotationValue[] mkArrayContentOrNull();

	/**
	 * Tells if the annotation value is a constant value.
	 * 
	 * @return if this is a constant value
	 */
	boolean isConstant();

	/**
	 * If the annotation value is a constant value, returns that value;
	 * otherwise returns null.
	 * 
	 * @return the constant value in case of a constant; null otherwise
	 */
	Object getConstantOrNull();

	/**
	 * Tells if the annotation value is an enum value.
	 * 
	 * @return if this in an enum value
	 */
	boolean isEnumValue();

	/**
	 * If the annotation value is an enum value, returns a string representation
	 * of the value's type; otherwise returns null.
	 * 
	 * @return the type of enum, if this is an enum value: otherwise null
	 */
	String getEnumTypeOrNull();

	/**
	 * If the annotation value is an enum value, returns a string representation
	 * of the value; otherwise returns null.
	 * 
	 * @return the enum value, if this is an enum value; otherwise null
	 */
	String getEnumValOrNull();

	/**
	 * Tells if the annotation value is itself an annotation.
	 * 
	 * @return if this is an annotation
	 */
	boolean isAnnotation();

	/**
	 * If the annotation value is an annotation, returns the type of the
	 * annotation; otherwise, returns null.
	 * 
	 * @return the annotation type, if this is an annotation; or null
	 */
	String getAnnotationTypeOrNull();

	/**
	 * If the annotation value is an annotation, returns the named arguments of
	 * the annotation; otherwise, returns null.
	 * 
	 * @return the named annotation arguments, or null
	 */
	Map<String, IAnnotationValue> mkNamedAnnotationArgumentsOrNull();
}
