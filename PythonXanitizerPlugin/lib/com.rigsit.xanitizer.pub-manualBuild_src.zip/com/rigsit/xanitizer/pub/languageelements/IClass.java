/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 16, 2016
 *
 */
package com.rigsit.xanitizer.pub.languageelements;

import java.util.List;

/**
 * A Java class, understood in the general sense, i.e., it also might be an
 * interface, enum, annotation, or array type.
 * 
 * Primitive types are not included.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IClass {

	/**
	 * Tells if this class object is in fact an interface
	 * 
	 * @return if the class is an interface
	 */
	boolean isInterface();

	/**
	 * Tells if this class is abstract
	 * 
	 * @return if the class is abstract
	 */
	boolean isAbstract();

	/**
	 * Tells if this class is declared as public
	 * 
	 * @return if the class is public
	 */
	boolean isPublic();

	/**
	 * Tells if this class is declared as private
	 * 
	 * @return if the class is private
	 */
	boolean isPrivate();

	/**
	 * Tells if this class is declared as final
	 * 
	 * @return if the class is final
	 */
	boolean isFinal();

	/**
	 * Tells if this is an inner class
	 * 
	 * @return if the class is an inner class
	 */
	boolean isInnerClass();

	/**
	 * Tells if this is a static inner class
	 * 
	 * @return if the class is a static inner class
	 */
	boolean isStaticInnerClass();

	/**
	 * Tells if this is an array type
	 * 
	 * @return if the class is an array class
	 */
	boolean isArrayClass();

	/**
	 * Tells if this is an enum class.
	 * 
	 * @return if the class is an enum class.
	 */
	boolean isEnumClass();

	/**
	 * Determine the superclass; returns null for java.lang.Object.
	 * 
	 * @return the superclass of this class
	 */
	IClass getSuperclassOrNull();

	/**
	 * Determine the directly implemented interfaces.
	 * 
	 * @return the list of directly implemented interfaces
	 */
	List<IClass> getDirectlyImplementedInterfaces();

	/**
	 * The type descriptor of this class.
	 * 
	 * @return the type descriptor of this class
	 */
	ITypeDescriptor getTypeDescriptor();

	/**
	 * All the method declared in this class.
	 * 
	 * @return the list of methods declared in this class
	 */
	List<IMethod> getDeclaredMethods();

	/**
	 * The fields declared in this class.
	 * 
	 * @param staticRatherThanInstance
	 *            if true, static fields are returned; if false, non-static
	 *            fields
	 * @return the list of fields declared in this class, either static or
	 *         instance fields, according to argument
	 */
	List<IField> getDeclaredFields(boolean staticRatherThanInstance);

	/**
	 * Determine the annotations of this class.
	 * 
	 * @return the annotations of the class; never null, might be empty.
	 */
	List<IAnnotationInstance> getAnnotations();

	/**
	 * The fully qualified name in internal syntax.
	 * 
	 * @return the fully qualified name of this class in internal syntax
	 */
	String getInternalFQName();

	/**
	 * Both the directly declared methods of this class, and those of all
	 * superclasses.
	 * 
	 * @return the list of all methods of this class, both directly declared and
	 *         inherited
	 */
	List<IMethod> getAllMethods();

	/**
	 * Both the directly declared fields of this class, and those of all
	 * superclasses.
	 * 
	 * @return the list of all fields of this class, both directly declared and
	 *         inherited
	 */
	List<IField> getAllFields();

	/**
	 * The class hierarchy this class belongs to.
	 * 
	 * @return the class hierarchy to which this class belongs
	 */
	IClassHierarchy getClassHierarchy();

	/**
	 * Resolve the given method selector in this class; if non-resolvable,
	 * returns null.
	 * 
	 * @param methodSelector
	 *            the method selector to be resolved
	 * 
	 * @return the method for the given selector, or null if not found
	 */
	IMethod getMethodOrNull(IMethodSelector methodSelector);

	/**
	 * Resolve the given field name selector in this class; if non-resolvable,
	 * returns null.
	 * 
	 * @param fieldName
	 *            the field to be resolved
	 * 
	 * @return the field of the given name, or null if not found
	 */
	IField getFieldOrNull(String fieldName);

	/**
	 * For inner classes, return the inner access flags; otherwise, return -1.
	 * 
	 * @return the inner access flags for inner classes; otherwise -1
	 */
	int getInnerClassAccessFlagsOrMinus1();

	/**
	 * @return the outer class, if this is an inner class, otherwise null
	 */
	IClass getOuterClassOrNull();
}
