/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 16, 2016
 *
 */
package com.rigsit.xanitizer.pub.languageelements;

import java.util.List;

/**
 * A class hierarchy is a collection of classes together with inheritance and
 * implementation information.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IClassHierarchy extends Iterable<IClass> {
	/**
	 * Look up the class for a type descriptor; if not found, return null
	 * 
	 * @param typeDescriptor
	 *            the descriptor of the class to look up
	 * @return the found class, or null if none has been found
	 */
	IClass lookupClassOrNull(ITypeDescriptor typeDescriptor);

	/**
	 * The number of classes in this class hierarchy
	 * 
	 * @return the number of classes in the class hierarchy
	 */
	int getNumberOfClasses();

	/**
	 * The immediate subclasses of a given class
	 * 
	 * @param clazz
	 *            the class for which to determine immediate subclasses
	 * @return the list of immediate subclasses; might be empty, never null
	 */
	List<IClass> getImmediateSubclasses(IClass clazz);

	/**
	 * The implementors of a given interface
	 * 
	 * @param intf
	 *            the interface for which to determine the implementors
	 * @return the list of implementing classes; might be empty, never null
	 */
	List<IClass> getImplementors(IClass intf);

	/**
	 * Check if two classes are assignment compatible
	 * 
	 * @param clazz1
	 *            left-hand side type
	 * @param clazz2
	 *            right-hand side type
	 * @return if instances of the right-hand side type are assignable to
	 *         variables of the left-hand side type
	 */
	boolean isAssignableFrom(IClass clazz1, IClass clazz2);

	/**
	 * Check if one class is a subclass of another, also indirectly
	 * 
	 * @param clazz1
	 *            potential subclass
	 * @param clazz2
	 *            potential superclass
	 * @return if clazz1 is a subclass of clazz2
	 */
	boolean isSubclassOf(IClass clazz1, IClass clazz2);

	/**
	 * Check if some class implements some interface, also indirectly
	 * 
	 * @param clazz
	 *            potential implementing class
	 * @param intf
	 *            potential implemented interfaces
	 * @return if clazz implements intf, perhaps indirectly
	 */
	boolean implementsInterface(IClass clazz, IClass intf);

	/**
	 * Resolve a method, using supertypes when needed
	 * 
	 * @param candidate
	 *            the method descriptor to resolve
	 * @return the resolved method, or null if resolution failed
	 */
	IMethod resolveMethodOrNull(IMethodDescriptor candidate);

	/**
	 * Resolve a field, using supertypes when needed
	 * 
	 * @param candidate
	 *            the field descriptor to resolve
	 * @return the resolved field, or null if resolution failed
	 */
	IField resolveFieldOrNull(IFieldDescriptor candidate);

	/**
	 * Direct and indirect subclasses of some class
	 * 
	 * @param clazz
	 *            the class of which to determine subclasses
	 * @return the subclasses
	 */
	List<IClass> mkSubClasses(IClass clazz);
}
