/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 16, 2016
 *
 */
package com.rigsit.xanitizer.pub.languageelements;

import java.util.Collection;

/**
 * A field in a java class.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IField {
	/**
	 * The class in which the field resides.
	 * 
	 * @return the field's declaring class
	 */
	IClass getDeclaringClass();

	/**
	 * The field name.
	 * 
	 * @return the field name
	 */
	String getName();

	/**
	 * Tells if the field is static
	 * 
	 * @return if the field is static
	 */
	boolean isStatic();

	/**
	 * The field's annotations.
	 * 
	 * @return the collection of annotations of the field
	 */
	Collection<IAnnotationInstance> getAnnotations();

	/**
	 * The field's type.
	 * 
	 * @return field type
	 */
	ITypeDescriptor getFieldTypeDescriptor();

	/**
	 * Tells if the field is final
	 * 
	 * @return if the field is final
	 */
	boolean isFinal();

	/**
	 * Tells if the field is private
	 * 
	 * @return if the field is private
	 */
	boolean isPrivate();

	/**
	 * Tells if the field is protected
	 * 
	 * @return if the field is protected
	 */
	boolean isProtected();

	/**
	 * Tells if the field is public
	 * 
	 * @return if the field is public
	 */
	boolean isPublic();

	/**
	 * Tells if the field is volatile
	 * 
	 * @return if the field is volatile
	 */
	boolean isVolatile();

	/**
	 * A reference to this field, i.e., the name, reference to the field's type,
	 * and reference to the containing class.
	 * 
	 * @return the field's field descriptor
	 */
	IFieldDescriptor getFieldDescriptor();
}
