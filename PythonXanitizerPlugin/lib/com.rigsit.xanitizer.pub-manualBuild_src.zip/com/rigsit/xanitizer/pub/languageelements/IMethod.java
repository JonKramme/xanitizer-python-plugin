/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 16, 2016
 *
 */
package com.rigsit.xanitizer.pub.languageelements;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.rigsit.xanitizer.pub.signatures.IMethodTypeSignature;

/**
 * A Java method.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IMethod {

	/**
	 * The class in which the method resides.
	 * 
	 * @return the class declaring this method
	 */
	IClass getDeclaringClass();

	/**
	 * The method's name.
	 * 
	 * @return the method's name
	 */
	String getName();

	/**
	 * Tells if the method is static
	 * 
	 * @return if the method is static
	 */
	boolean isStatic();

	/**
	 * The method's annotations. Never null, might be empty.
	 * 
	 * @return the collection of annotations of this method
	 */
	Collection<IAnnotationInstance> getAnnotations();

	/**
	 * Tells if the method is synchronized
	 * 
	 * @return if the method is synchronized
	 */
	boolean isSynchronized();

	/**
	 * Tells if this is a class initialization method
	 * 
	 * @return if the method is the class initialization method
	 */
	boolean isClinit();

	/**
	 * Tells if this is a constructor
	 * 
	 * @return if the method is a constructor
	 */
	boolean isInit();

	/**
	 * Tells if this method is native
	 * 
	 * @return if the method is native
	 */
	boolean isNative();

	/**
	 * Tells if this method is synthetic
	 * 
	 * @return if the method is synthetic
	 */
	boolean isSynthetic();

	/**
	 * Tells if this method is abstract
	 * 
	 * @return if the method is abstract
	 */
	boolean isAbstract();

	/**
	 * Tells if this method is private
	 * 
	 * @return if the method is private
	 */
	boolean isPrivate();

	/**
	 * Tells if this method is protected
	 * 
	 * @return if the method is protected
	 */
	boolean isProtected();

	/**
	 * Tells if this method is public
	 * 
	 * @return if the method is public
	 */
	boolean isPublic();

	/**
	 * Tells if this method is final
	 * 
	 * @return if the method is final
	 */
	boolean isFinal();

	/**
	 * Tells if this method is a bridge method
	 * 
	 * @return if the method is a bridge method
	 */
	boolean isBridge();

	/**
	 * The method's return type.
	 * 
	 * @return the method's return type
	 */
	ITypeDescriptor getReturnType();

	/**
	 * This method's number of parameters. This contains the implicit 'this'
	 * parameter, when applicable.
	 * 
	 * @return the number of parameters
	 */
	int getNumberOfParameters();

	/**
	 * The type of some method parameter.
	 * 
	 * @param paramNum
	 *            the number of the parameter
	 * @return the parameter's type
	 */
	ITypeDescriptor getParameterType(int paramNum);

	/**
	 * The method's method selector.
	 * 
	 * @return the method's method selector
	 */
	IMethodSelector getMethodSelector();

	/**
	 * The list of exceptions declared at this method.
	 * 
	 * @return the declared exception types, or null of they could not be
	 *         determined
	 */
	List<ITypeDescriptor> getDeclaredExceptionsOrNull();

	/**
	 * The method descriptor.
	 * 
	 * @return this method's method descriptor
	 */
	IMethodDescriptor getMethodDescriptor();

	/**
	 * The access flags.
	 * 
	 * @return the method's access flags
	 */
	int getAccessFlags();

	/**
	 * The method type signature, if there is one; otherwise null.
	 * 
	 * @return the method type signature, if there is one; otherwise null.
	 */
	IMethodTypeSignature getMethodTypeSignatureOrNull();

	/**
	 * Method references for all calls in the method body.
	 * 
	 * @return set of method references for which there are calls in the method
	 *         body
	 */
	Set<IMethodDescriptor> getAllCalledMethodRefs();
}
