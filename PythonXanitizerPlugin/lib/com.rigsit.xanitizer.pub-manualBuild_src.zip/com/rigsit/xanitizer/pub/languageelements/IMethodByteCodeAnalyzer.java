/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 29, 2016
 *
 */
package com.rigsit.xanitizer.pub.languageelements;

import java.util.Collection;

import com.rigsit.xanitizer.pub.callgraph.ICallSiteReference;
import com.rigsit.xanitizer.pub.instructions.IInstruction;
import com.rigsit.xanitizer.pub.instructions.IInvokeInstruction;

/**
 * An object allowing to analyze a method's byte code.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface IMethodByteCodeAnalyzer {

	/**
	 * All the call sites of the method.
	 * 
	 * @return collection of call site in this method's byte code
	 */
	Collection<ICallSiteReference> mkCallSites();

	/**
	 * The method that is being analyzed.
	 * 
	 * @return the method being analyzed
	 */
	IMethod getMethod();

	/**
	 * Determine the string value of the register, if possible. If not, return
	 * null.
	 * 
	 * @param registerNumber
	 *            register to look at
	 * 
	 * @return if the register is associated with a string value, that value;
	 *         otherwise null
	 */
	String mkStringValueOrNull(int registerNumber);

	/**
	 * Determine the boolean value of the register, if possible. If not, return
	 * the given default value.
	 * 
	 * @param registerNumber
	 *            register for which to determine the boolean value
	 * 
	 * @param dflt
	 *            value to be returned if no value can be determined for the
	 *            register
	 * 
	 * @return the boolean constant represented by the register, if it can be
	 *         determined; otherwise, the default value
	 */
	boolean mkBooleanValue(int registerNumber, boolean dflt);

	/**
	 * Determine the invocation instruction for some call site reference.
	 * 
	 * @param csr
	 *            the call site reference for which to determined the invoke
	 *            instruction
	 * 
	 * @return the instruction all the given call site
	 */
	IInvokeInstruction getInvokeInstruction(ICallSiteReference csr);

	/**
	 * Tells if the register represent a constant value in this method
	 * 
	 * @param registerNumber
	 *            the register to be checked
	 * 
	 * @return if the register has a constant value
	 */
	boolean isConstant(int registerNumber);

	/**
	 * Determine the constant value of the register, if there is one, or return
	 * null.
	 * 
	 * @param expressionArgValNo
	 *            the register to be looked at
	 * 
	 * @return the constant value of the register, or null if there is none
	 */
	Object getConstantValueOrNull(int expressionArgValNo);

	/**
	 * Determine the use instructions for the register.
	 * 
	 * @param registerNumber
	 *            the register to be looked at
	 * 
	 * @return the instructions using the register
	 */
	Collection<IInstruction> mkUseInstructions(int registerNumber);

	/**
	 * Determine the instruction in which a register is being defined.
	 * 
	 * @param registerNumber
	 *            the register to be checked
	 * 
	 * @return the instruction defining the register, or null
	 */
	IInstruction getDefinigInstructionOrNull(int registerNumber);
}
