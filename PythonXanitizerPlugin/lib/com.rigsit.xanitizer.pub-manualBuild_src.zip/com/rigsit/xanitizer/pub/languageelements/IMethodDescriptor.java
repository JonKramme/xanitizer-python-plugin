/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 6, 2016
 *
 */
package com.rigsit.xanitizer.pub.languageelements;

/**
 * The method's descriptor; basically, this is the method selector and the
 * declaring class.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IMethodDescriptor {

	/**
	 * The method selector.
	 * 
	 * @return the method selector
	 */
	IMethodSelector getMethodSelector();

	/**
	 * The class in which the method resides.
	 * 
	 * @return the declaring class of the method
	 */
	ITypeDescriptor getDeclaringClass();

	/**
	 * The method's signature, containing information about generic types.
	 * 
	 * @return the method's signature
	 */
	String getSignature();

	/**
	 * Human-readable string describing the method.
	 * 
	 * @return a human-readable representation of the method
	 */
	String getPresentationString();

	/**
	 * Tells if the method is the <code>&lt;init&gt;</code> method, i.e., the
	 * constructor.
	 * 
	 * @return if this is a constructor
	 */
	boolean isInit();

	/**
	 * Tells if the method is static.
	 * 
	 * @return if the method is static
	 */
	boolean isStatic();
}
