/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 16, 2016
 *
 */
package com.rigsit.xanitizer.pub.languageelements;

/**
 * A method selector, consisting of a method name, the return type, and the
 * parameter types.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IMethodSelector {

	/**
	 * The method name.
	 * 
	 * @return method name
	 */
	String getName();

	/**
	 * The method's return type.
	 * 
	 * @return return type
	 */
	ITypeDescriptor getReturnType();

	/**
	 * The method's number of parameters.
	 * 
	 * @return number of parameters
	 */
	int getNumberOfParameters();

	/**
	 * The type of a method parameter.
	 * 
	 * @param paramNum
	 *            the number of the parameter for which to determine the type
	 * @return the type of the parameter
	 */
	ITypeDescriptor getParameterType(int paramNum);

	/**
	 * The method arguments' descriptor object for this method selector.
	 * 
	 * @return descriptor for arguments and return type
	 */
	IMethodArgumentsAndReturnTypeDescriptor getMethodArgumentsAndReturnTypeDescriptor();

	/**
	 * Is the method static?
	 * 
	 * @return if the method is static
	 */
	boolean isStatic();
}
