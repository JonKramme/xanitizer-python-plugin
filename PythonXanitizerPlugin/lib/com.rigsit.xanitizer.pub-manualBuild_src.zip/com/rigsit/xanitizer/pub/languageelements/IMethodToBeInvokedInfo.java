/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 12, 2016
 *
 */
package com.rigsit.xanitizer.pub.languageelements;

/**
 * Represents a method that is to be invoked from the simulation code. Note that
 * this method possibly does not exist in the workspace but is currently being
 * generated.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IMethodToBeInvokedInfo {

	/**
	 * The method's descriptor.
	 * 
	 * @return the descriptor of the method to be invoked
	 */
	IMethodDescriptor getMethodDescriptor();

	/**
	 * Access flags. Can be analyzed with the constants in
	 * <code>com.lang.reflect.Modifier</code>.
	 * 
	 * @return access flags of the method to be invoked
	 */
	int getAccessFlags();

}
