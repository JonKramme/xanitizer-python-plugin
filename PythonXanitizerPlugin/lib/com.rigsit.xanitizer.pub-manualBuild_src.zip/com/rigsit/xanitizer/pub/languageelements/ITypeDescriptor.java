/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 12, 2016
 *
 */
package com.rigsit.xanitizer.pub.languageelements;

/**
 * Describes a Java type.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface ITypeDescriptor {

	/**
	 * The Java-language type name corresponding to this type descriptor.
	 * 
	 * @return the Java-language type name
	 */
	String mkJavaTypeName();

	/**
	 * The Java-language type name corresponding to this type descriptor, where
	 * $ and . are treated more like in the language definition, not as in the
	 * bytecode.
	 * 
	 * @return the Java-language type name
	 */
	String mkProperJavaTypeName();

	/**
	 * The class name of this type descriptor
	 * 
	 * @return the class name, w/o the package
	 */
	String getClassName();

	/**
	 * The Java package of this type descriptor
	 * 
	 * @return package in Java syntax
	 */
	String getJavaPackageOrEmpty();

	/**
	 * The (internal) string representation for this type descriptor.
	 * 
	 * @return internal string representation of this type descriptor
	 */
	String mkInternalStringRepresentation();

	/**
	 * Tells if this is a primitive type
	 * 
	 * @return if this represents a primitive type
	 */
	boolean isPrimitiveType();

	/**
	 * Tells if this is a class type
	 * 
	 * @return if this represents a class type
	 */
	boolean isClassType();

	/**
	 * Tells if this is an array type
	 * 
	 * @return if this is an array type
	 */
	boolean isArrayType();

	/**
	 * The innermost type for arrays.
	 * 
	 * @return for array types, the innermost element type
	 */
	ITypeDescriptor getInnermostElementType();

	/**
	 * Creates an array type of this type descriptor. If the type descriptor
	 * already represents an array, its dimension is incremented.
	 * 
	 * @return an array type this element type
	 */
	ITypeDescriptor mkArrayTypeForElementType();

	/**
	 * Returns the array dimension of this type descriptor if it represents an
	 * array; otherwise returns -1
	 * 
	 * @return for arrays, the dimensionality; otherwise -1
	 */
	int getDimensionalityOfArrayOrMinusOne();
}
