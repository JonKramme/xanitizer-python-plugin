/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Jul 21, 2016
 */
package com.rigsit.xanitizer.pub.plugin;

import java.io.IOException;
import java.util.Collection;
import java.util.logging.Logger;

import com.rigsit.xanitizer.pub.callgraph.ICallGraphProcessor;
import com.rigsit.xanitizer.pub.callgraph.ICallerSpec;
import com.rigsit.xanitizer.pub.configitems.IConfigurationItemRegistry;
import com.rigsit.xanitizer.pub.languageelements.IClass;
import com.rigsit.xanitizer.pub.languageelements.IMethod;
import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;
import com.rigsit.xanitizer.pub.languageelements.ITypeDescriptor;
import com.rigsit.xanitizer.pub.problemtypes.IProblemTypeRegistry;
import com.rigsit.xanitizer.pub.util.IDOMProcessor;

/**
 * To be implemented by the simulation code. The implementing class is the main
 * entry point into the simulation code.
 */
public abstract class AbstractFrameworkSimulationPlugin extends AbstractPlugin
		implements IFrameworkSimulationPlugin {
	private static final Logger LOG = Logger
			.getLogger(AbstractFrameworkSimulationPlugin.class.getName());

	protected AbstractFrameworkSimulationPlugin() {
	}

	@Override
	public void registerAdditionalProblemTypes(final IProblemTypeRegistry problemTypeRegistry) {
	}

	@Override
	public void registerAdditionalConfigurationItems(
			final IConfigurationItemRegistry configurationItemRegistry) {
	}

	@Override
	public IDOMProcessor mkDOMProcessorOrNull(IFrameworkSimulationContext context) {
		// Default implementation.
		return null;
	}

	@Override
	public void processClassHierarchy(IFrameworkSimulationContext context) {
		// Default implementation.
	}

	@Override
	public void generateFrameworkSimulationCode(final IFrameworkSimulationContext context)
			throws IOException {
		// Default implementation.
	}

	@Override
	public Collection<ITypeDescriptor> getAdditionalClassesToBeAnalyzedOrNull(
			final IFrameworkSimulationContext context) {
		// Default implementation.
		return null;
	}

	@Override
	public IMethod mkCalleeTargetOrNull(final ICallerSpec callerSpec, final IClass receiver,
			final IFrameworkSimulationContext context) {
		// Default implementation.
		return null;
	}

	@Override
	public boolean isFrameworkAnalysisRelevantForMethodAndShouldCallsInMethodBeExtendedForNonTrivialInstanceSetsDuringCallGraphConstruction(
			final IMethodDescriptor methodDescriptor, final IFrameworkSimulationContext context) {
		// Default implementation.
		return false;
	}

	@Override
	public ICallGraphProcessor mkCallGraphProcessorOrNull(
			final IFrameworkSimulationContext context) {
		// Default implementation.
		return null;
	}

	@Override
	public void registerFrameworkFindings(final IFrameworkSimulationContext context) {
		// Default implementation.
	}

	protected final int getCompilationOrderNumber(final IFrameworkSimulationContext context) {
		final IFrameworkAnalysis fwa = context.getFrameworkAnalysisForPluginIDOrNull(getPluginID());
		assert fwa != null;
		if (fwa == null) {
			LOG.warning(
					"Determining compilation order number: No IFrameworkAnalysis object has been found for id "
							+ getPluginID());
			return -1;
		}
		return fwa.getCompilationOrderNumber();
	}
}
