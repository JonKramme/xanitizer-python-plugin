/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Dec 13, 2019
 *
 */
package com.rigsit.xanitizer.pub.plugin;

import com.rigsit.xanitizer.pub.configitems.IConfigurationItemRegistry;

/**
 * @author rust
 *
 */
public interface IConfigurationItemSupplier extends IXanitizerPlugin {
	/**
	 * Register the additional configuration items for which this plugin can
	 * store values in the config file.
	 * 
	 * This is called once, but the order with respect to other methods is not
	 * fixed.
	 * 
	 * @param configurationItemRegistry
	 *            the configuration item registraty to use for registering new
	 *            config items
	 */
	void registerAdditionalConfigurationItems(IConfigurationItemRegistry configurationItemRegistry);
}
