/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Dec 20, 2016
 *
 */
package com.rigsit.xanitizer.pub.plugin;

/**
 * Represents a framework analysis.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface IFrameworkAnalysis {

	/**
	 * The framework analysis plugin's ID.
	 * 
	 * @return the plugin ID
	 */
	PluginID getPluginID();

	/**
	 * The plugin on which this analysis is based.
	 * 
	 * @return the plugin
	 */
	IFrameworkSimulationPlugin getPlugin();

	/**
	 * This analysis' compilation order number.
	 * 
	 * @return the compilation order number
	 */
	int getCompilationOrderNumber();
}
