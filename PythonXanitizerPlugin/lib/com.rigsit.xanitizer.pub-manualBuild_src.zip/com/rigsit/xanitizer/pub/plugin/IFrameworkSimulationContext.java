/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 12, 2016
 *
 */
package com.rigsit.xanitizer.pub.plugin;

import java.io.File;
import java.net.URL;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.rigsit.xanitizer.pub.callgraph.ICallerOfInterceptedMethodMethodPattern;
import com.rigsit.xanitizer.pub.codegeneration.IFrameworkSimulationCodeGenerator;
import com.rigsit.xanitizer.pub.codegeneration.ISimpleInjectionInfo;
import com.rigsit.xanitizer.pub.languageelements.IAnnotationInstance;
import com.rigsit.xanitizer.pub.languageelements.IClass;
import com.rigsit.xanitizer.pub.languageelements.IClassHierarchy;
import com.rigsit.xanitizer.pub.languageelements.IMethod;
import com.rigsit.xanitizer.pub.languageelements.IMethodByteCodeAnalyzer;
import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;
import com.rigsit.xanitizer.pub.languageelements.ITypeDescriptor;
import com.rigsit.xanitizer.pub.problemtypes.IProblemType;
import com.rigsit.xanitizer.pub.springmvc.ISpringMVCFrameworkSimulationHelper;
import com.rigsit.xanitizer.pub.util.IExtraFrameworkParameters;
import com.rigsit.xanitizer.pub.util.IIssueCategory;
import com.rigsit.xanitizer.pub.util.IJSPInfo;
import com.rigsit.xanitizer.pub.util.IMethodMatcher;
import com.rigsit.xanitizer.pub.util.IMethodPattern;
import com.rigsit.xanitizer.pub.util.IPatternKind;
import com.rigsit.xanitizer.pub.util.IProgressMonitor;
import com.rigsit.xanitizer.pub.util.ISourceLineData;
import com.rigsit.xanitizer.pub.util.IXFile;
import com.rigsit.xanitizer.pub.util.IXFileContext;
import com.rigsit.xanitizer.pub.util.SearchPathKind;

/**
 * Runtime context for framework simulation plugins.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IFrameworkSimulationContext {

	public interface IFactory {
		/**
		 * Create an IXFile instance from a relative path.
		 * 
		 * @param relativePath
		 *            the relative path to be used for constructing the IXFile
		 * @param pathVariableOrNull
		 *            null, or a path variable, if the result should be based on
		 *            one
		 * @return the resulting IXFile
		 */
		IXFile mkXFileFromRelativePath(String relativePath, String pathVariableOrNull);

		/**
		 * Create an IXFile from an absolute path.
		 * 
		 * @param absolutePathPerhapsWithBangs
		 *            the absolute path to be used for constructing the IXFile;
		 *            is allowed to contain !/ components, notating ZIP members
		 * @return the resulting IXFile
		 */
		IXFile mkXFileFromAbsoluteFile(String absolutePathPerhapsWithBangs);

		/**
		 * Create an IXFile from an URL.
		 * 
		 * @param url
		 *            URL to create an XFile for
		 * @return the XFile corresponding to the argument
		 */
		IXFile mkXFileFromUrl(URL url);

		/**
		 * Determine the files corresponding to some search path kinds.
		 * 
		 * @param searchPathKinds
		 *            kinds of search paths to look for
		 * @return collection of all files for search paths of the given kinds
		 */
		Collection<File> mkSearchPathFilesWOUnreadableZipArchives(
				SearchPathKind... searchPathKinds);

		/**
		 * Create an object that can be used to analyze the byte code of the
		 * given method.
		 * 
		 * @param m
		 *            method to be analyzed
		 * @return a byte code analyzer for the given method
		 */
		IMethodByteCodeAnalyzer mkMethodByteCodeAnalyzerOrNull(IMethod m);

		/**
		 * Create a method matcher that can contain several method patterns.
		 * 
		 * @return the (for now) empty method matcher
		 */
		IMethodMatcher mkMethodMatcher();

		/**
		 * Create a source line data object.
		 * 
		 * @param xFile
		 *            the resource
		 * @param lineNoOrMinus1
		 *            minus 1, or the line number in the resource
		 * @param veryShortDescOrNull
		 *            a very short description
		 * @param generateMarker
		 *            should Xanitizer generate a marker in the source code
		 *            viewer for thus location
		 * @return the constructed object
		 */
		ISourceLineData mkSourceLineData(IXFile xFile, int lineNoOrMinus1,
				String veryShortDescOrNull, boolean generateMarker);
	}

	/**
	 * The current class hierarchy
	 * 
	 * @return the class hierarchy
	 */
	IClassHierarchy getClassHierarchy();

	/**
	 * The current progress monitor
	 * 
	 * @return the progress monitor
	 */
	IProgressMonitor getProgressMonitor();

	/**
	 * The current framework simulation code generator
	 * 
	 * @return the framework simulation code generator
	 */
	IFrameworkSimulationCodeGenerator getFrameworkSimulationCodeGenerator();

	/**
	 * Add an informational message to the analysis result
	 * 
	 * An informational message can have a hierarchical structure, with a detail
	 * string, a detail for the detail, and so on. It will be displayed in a
	 * tree structure.
	 * 
	 * @param pluginID
	 *            the plugin ID for which the warning is added
	 * @param info
	 *            the main message
	 * @param detailStrings
	 *            some details strings, with the meaning that each detail string
	 *            supplies information for the main informational message
	 */
	void addInformation(PluginID pluginID, String info, String... detailStrings);

	/**
	 * Add a warning message to the analysis result
	 * 
	 * A warning can have a hierarchical structure, with a detail string, a
	 * detail for the detail, and so on. It will be displayed in a tree
	 * structure.
	 * 
	 * @param pluginID
	 *            the plugin ID for which the warning is added
	 * @param warning
	 *            the main warning message
	 * @param detailStrings
	 *            some details strings, with the meaning that each detail string
	 *            supplies information for the warning
	 */
	void addWarning(PluginID pluginID, String warning, String... detailStrings);

	/**
	 * Add an error message to the analysis result
	 * 
	 * An error can have a hierarchical structure, with a detail string, a
	 * detail for the detail, and so on. It will be displayed in a tree
	 * structure.
	 * 
	 * @param pluginID
	 *            the plugin ID for which the warning is added
	 * @param error
	 *            error the main error message
	 * @param detailStrings
	 *            some details strings, with the meaning that each detail string
	 *            supplies information for the error
	 */
	void addError(PluginID pluginID, String error, String... detailStrings);

	/**
	 * Add information about the existence of a service class to the analysis
	 * result
	 * 
	 * @param pluginID
	 *            the plugin ID for which the registration occurs
	 * @param serviceClassPresentationNameOrNull
	 *            if given, describes the type of service class, i.e. "Action
	 *            Class"
	 * @param td
	 *            the class
	 * @param reasonOrNull
	 *            optional reason why this class is a service class
	 */
	void registerServiceClassInfo(PluginID pluginID, String serviceClassPresentationNameOrNull,
			ITypeDescriptor td, String reasonOrNull);

	/**
	 * Add information about the existence of a service method to the analysis
	 * result
	 * 
	 * @param pluginID
	 *            the plugin ID for which the registration occurs
	 * @param method
	 *            method for which to write information
	 * @param accessFlags
	 *            method flags
	 * @param kindMessage
	 *            additional informational text describing what kind of service
	 *            method this is
	 */
	void registerServiceMethodInfo(PluginID pluginID, IMethodDescriptor method, int accessFlags,
			String kindMessage);

	/**
	 * Add information about the existence of a taint source method to the
	 * analysis result
	 * 
	 * @param pluginID
	 *            the plugin ID for which the registration occurs
	 * @param method
	 *            method for which to write information
	 * @param accessFlags
	 *            method flags
	 * @param kindMessage
	 *            additional informational text describing what kind of taint
	 *            source method this is
	 */
	void registerTaintSourceMethodInfo(PluginID pluginID, IMethodDescriptor method, int accessFlags,
			String kindMessage);

	/**
	 * Add information about the existence of a taint sink method to the
	 * analysis result
	 * 
	 * @param pluginID
	 *            the plugin ID for which the registration occurs
	 * @param method
	 *            method for which to write information
	 * @param accessFlags
	 *            method flags
	 * @param kindMessage
	 *            additional informational text describing what kind of taint
	 *            sink method this is
	 */
	void registerTaintSinkMethodInfo(PluginID pluginID, IMethodDescriptor method, int accessFlags,
			String kindMessage);

	/**
	 * Add information about the existence of a bean that has been found.
	 * 
	 * @param pluginID
	 *            the plugin ID for which to register the information
	 * @param beanKind
	 *            description of the kind of bean
	 * @param beanDescription
	 *            the bean itself, typically as a fully qualified class name
	 * @param xmlFileInfo
	 *            description of the XML file where the bean definition has been
	 *            found
	 */
	void registerXMLDefinedBeanInfo(PluginID pluginID, String beanKind, String beanDescription,
			String xmlFileInfo);

	/**
	 * Register informational text about some framework relevant code that will
	 * not be handled because of missing types.
	 * 
	 * @param msg
	 *            message text to be registered
	 */
	void registerMissingFrameworkClassInfo(String typeString, String msg);

	/**
	 * Does some type belong to the workspace.
	 * 
	 * @param typeDescriptor
	 *            the type to check
	 * 
	 * @return if the type belongs to the current workspace
	 */
	boolean isInWorkspace(ITypeDescriptor typeDescriptor);

	/**
	 * Register a taint source.
	 * 
	 * @param pluginID
	 *            identifier of the plugin for which the registration occurs
	 * @param sourceKindId
	 *            identifier of the source kind to be registered; must start
	 *            with "TaintSource:"
	 * @param method
	 *            the method descriptor of the taint source being registered
	 * @param taintOut
	 *            comma-separated list of parameter positions of the taint
	 *            source; -1 is the return value, 0 the receiver, values from 1
	 *            the method argument positions
	 * @param simulationClassTDOrNull
	 *            null, or a class type descriptor; if non-null, only calls
	 *            originating in code belonging to package of this class are
	 *            used as taint sources
	 * 
	 * @return the method pattern generated from the arguments
	 */
	IMethodPattern registerTaintSourceAndReturnPatternOrNull(PluginID pluginID, String sourceKindId,
			IMethodDescriptor method, String taintOut, ITypeDescriptor simulationClassTDOrNull);

	/**
	 * Register a taint sink.
	 * 
	 * @param pluginID
	 *            identifier of the plugin for which the registration occurs
	 * @param sinkKindId
	 *            identifier of the sink kind to be registered; must start with
	 *            "TaintSink:"
	 * @param methodDescriptor
	 *            the method descriptor of the taint sink being registered
	 * @param taintIn
	 *            comma-separated list of parameter positions of the taint sink;
	 *            0 is the receiver, values from 1 the method argument positions
	 * @param simulationClassTDOrNull
	 *            null, or a class type descriptor; if non-null, only calls
	 *            originating in code belonging to package of this class are
	 *            used as taint sinks
	 * 
	 * @return the method pattern generated from the arguments
	 */
	IMethodPattern registerTaintSinkAndReturnPatternOrNull(PluginID pluginID, String sinkKindId,
			IMethodDescriptor methodDescriptor, String taintIn,
			ITypeDescriptor simulationClassTDOrNull);

	/**
	 * Register a taint sanitizer.
	 * 
	 * @param pluginID
	 *            identifier of the plugin for which the registration occurs
	 * @param sanitizerKindId
	 *            identifier of the sanitizer kind to be registered; must start
	 *            with "TaintSanitizer:"
	 * @param methodDescriptor
	 *            the method descriptor of the taint sanitizer being registered
	 * @param taintIn
	 *            semicolon-separated list of parameter positions where taint
	 *            might flow into the taint sanitizer; 0 is the receiver, values
	 *            from 1 the method argument positions
	 * @param taintOut
	 *            semicolon-separated list of comma-separated lists of parameter
	 *            positions where taint might flow out of the method when, at
	 *            the corresponding parameter position of taintIn, some taint
	 *            flows into the method call; -1 is the return value, 0 is the
	 *            receiver, and values from 1 represent the corresponding method
	 *            argument positions
	 * 
	 * @return the method pattern generated from the arguments
	 */
	IMethodPattern registerTaintSanitizerAndReturnPatternOrNull(PluginID pluginID,
			String sanitizerKindId, IMethodDescriptor methodDescriptor, String taintIn,
			String taintOut);

	/**
	 * Register a taint transformer.
	 * 
	 * @param pluginID
	 *            identifier of the plugin for which the registration occurs
	 * @param methodDescriptor
	 *            the method descriptor of the taint transformer being
	 *            registered
	 * @param taintIn
	 *            semicolon-separated list of parameter positions where taint
	 *            might flow into the taint transformer; 0 is the receiver,
	 *            values from 1 the method argument positions
	 * @param taintOut
	 *            semicolon-separated list of comma-separated lists of parameter
	 *            positions where taint might flow out of the method when, at
	 *            the corresponding parameter position of taintIn, some taint
	 *            flows into the method call; -1 is the return value, 0 is the
	 *            receiver, and values from 1 represent the corresponding method
	 *            argument positions
	 * 
	 * @return the method pattern generated from the arguments
	 */
	IMethodPattern registerTaintTransformerAndReturnPatternOrNull(PluginID pluginID,
			IMethodDescriptor methodDescriptor, String taintIn, String taintOut);

	/**
	 * Register a taint flow suppressor.
	 * 
	 * @param methodDescriptor
	 *            the method that suppresses taint flow
	 * @param constraintValueForFirstArg
	 *            the suppressor only matches method invocation where the first
	 *            argument equals this
	 */
	void registerTaintFlowSuppressor(IMethodDescriptor methodDescriptor,
			String constraintValueForFirstArg);

	/**
	 * Register a start method for call graph construction.
	 * 
	 * @param pluginID
	 *            identifier of the plugin for which the registration occurs
	 * @param methodDescriptor
	 *            the method descriptor of the taint transformer being
	 *            registered
	 */
	IMethodPattern registerStartMethodAndReturnPatternOrNull(PluginID pluginID,
			IMethodDescriptor methodDescriptor);

	/**
	 * Functionality for simple injection support.
	 * 
	 * @return the functionality for simple injection support
	 */
	ISimpleInjectionInfo getSimpleInjectionInfoRef();

	/**
	 * Determine the active problem type for the given problem type identifier
	 * 
	 * @param problemTypeID
	 *            the problem type identifier of the problem type to look for
	 * @return null if there is no active problem type for the given identifier,
	 *         otherwise the problem type
	 */
	IProblemType getActiveProblemTypeForIDOrNull(String problemTypeID);

	/**
	 * Register a finding for some method and problem type.
	 * 
	 * @param problemType
	 *            the problem type for which to register the finding
	 * @param method
	 *            the method for which to register the finding
	 * @param message
	 *            an explanatory message for the finding
	 */
	void registerFinding(IProblemType problemType, IMethodDescriptor method, String message);

	/**
	 * Register a finding for some locations and problem type.
	 * 
	 * @param problemType
	 *            the problem type for which to register the finding
	 * @param xFile
	 *            resource of main location
	 * @param lineNoOrMinus1
	 *            line number of main locations, or -1
	 * @param veryShortDescription
	 *            very short description of the finding
	 * @param sourceLineData
	 *            non-null list of source line data of additional locations of
	 *            the finding
	 */
	void registerFinding(IProblemType problemType, IXFile xFile, int lineNoOrMinus1,
			String veryShortDescription, List<ISourceLineData> sourceLineData);

	/**
	 * If possible produce the byte code for the given class
	 * 
	 * @param clazz
	 *            class for which to determine the byte code
	 * @return null, or the byte code of the class
	 */
	byte[] mkByteCodeOrNull(IClass clazz);

	/**
	 * Map that maps for each type to the root path through which its byte code
	 * is found, i.e., a ZIP or class directory.
	 * 
	 * @return map from types to the files in which they are defined
	 */
	Map<ITypeDescriptor, File> getJavaClassFQNToRootPath();

	/**
	 * Register a resource that should be listed in Xanitizer's workspace.
	 * 
	 * Note that byte code, source code, XML and JSP files are automatically
	 * picked up and need not be specified explicitly.
	 * 
	 * @param pluginID
	 *            identifier of the plugin for which the registration occurs
	 * @param uri
	 *            the resource as a URI string
	 * 
	 */
	void registerExtraResource(PluginID pluginID, String uri);

	/**
	 * Register a resource that should be listed in Xanitizer's workspace.
	 * 
	 * Note that byte code, source code, XML and JSP files are automatically
	 * picked up and need not be specified explicitly.
	 * 
	 * @param pluginID
	 *            identifier of the plugin for which the registration occurs
	 * @param ixFile
	 *            the resource as an file
	 * 
	 */
	void registerExtraResource(PluginID pluginID, IXFile ixFile);

	/**
	 * Register that during framework simulation code compilation, the given
	 * type must be public
	 * 
	 * @param neededType
	 *            type that is needed
	 * @return if the type exists in the workspace
	 */
	boolean registerTypeAsNeeded(ITypeDescriptor neededType);

	/**
	 * Register that during compilation, the given type must have been patched
	 * so that it is publicly accessible.
	 * 
	 * @param typeDescriptor
	 *            of the type to be patched
	 */
	void registerTypeAsToBePatched(ITypeDescriptor toBePatchedType);

	/**
	 * Get the framework analysis for a given plugin identifier, or null if it
	 * does not exist.
	 * 
	 * @param pluginID
	 *            the plugin's identifier
	 * @return null, or the analysis object with the identifier
	 */
	IFrameworkAnalysis getFrameworkAnalysisForPluginIDOrNull(PluginID pluginID);

	/**
	 * Register that treatment of some application class should be skipped by
	 * some (other) framework.
	 * 
	 * This might be used by some framework simulation A to tell some other
	 * framework simulation B that dealing with the class is A' job, not B's
	 * 
	 * @param pluginID
	 *            identifier of the framework simulation that should not deal
	 *            with the given class
	 * @param clazz
	 *            the class that should not be treated
	 */
	void registerFrameworkClassToSkip(PluginID pluginID, ITypeDescriptor clazz);

	/**
	 * Check if some application class has been registered to be skipped by the
	 * given framework simulation,
	 * 
	 * @param pluginID
	 *            identifier of the framework simulation that possibly should
	 *            not deal with the given class
	 * @param clazz
	 *            the class that should possibly not be treated
	 * @return if the treatment of the class should be skipped by the framework
	 *         simulation
	 */
	boolean isClassSkippedForFramework(PluginID pluginID, ITypeDescriptor clazz);

	/**
	 * Collect the fully qualified Java-syntax class names of classes
	 * corresponding to a given location of a JSP file.
	 * 
	 * @param potentialJspLocation
	 *            potential Jsp location to be checked
	 * @param jspJavaClassFQNs
	 *            accu that will receive the FQNs
	 */
	void collectJSPClassesForPotentialJSPLocation(String potentialJspLocation,
			Set<String> jspJavaClassFQNs);

	/**
	 * Check if a value of the given type can carry taint
	 * 
	 * @param type
	 *            the type to be checked
	 * @param numbersCanCarryTaint
	 *            flag telling if numbers should be considered to be able to
	 *            carry taint
	 * @return if values of the given type can carry taint
	 */
	boolean canCarryTaint(ITypeDescriptor type, boolean numbersCanCarryTaint);

	/**
	 * Determine the list of resources handled by the given servlet class
	 * 
	 * @param javaClassFQN
	 *            Java syntax fully qualified class name of servlet class
	 * @return null, or the resource files handled by the given servlet class
	 */
	List<File> getFilesHandledByServletClassOrNull(String javaClassFQN);

	/**
	 * Determine the list of resources handled by the servlet of the given name
	 * 
	 * @param servletName
	 *            name of servlet, like "jsp" for JSP processing servlet
	 * @return null, or the resource files handled by the servlet
	 */
	List<File> getFilesHandledByServletNameOrNull(String servletName);

	/**
	 * Look up an annotation argument, either as a named argument, or as the
	 * value of an unnamed one (defined via a method declaration in the
	 * annotation type's declaration).
	 * 
	 * @param argumentOrMethodName
	 *            name to use for look-up.
	 * @param annotation
	 *            the annotation on which to look
	 * @return null, or the annotation argument's value
	 */
	Object mkArgumentFromNameOrMethodOrNull(String argumentOrMethodName,
			IAnnotationInstance annotation);

	/**
	 * An object that provides non-generic internal Xanitizer functionality
	 * that, at the moment, cannot be performed by the generic functionality
	 * exposed up to now.
	 * 
	 * @param pluginID
	 *            the plugin ID to use
	 * @return the helper for Spring MVC framework simulation
	 */
	ISpringMVCFrameworkSimulationHelper getSpringMVCFrameworkSimulationHelper(PluginID pluginID);

	/**
	 * Does the path name end in some kind of extension that Xanitizer considers
	 * to be a JAR archive extension?
	 * 
	 * @param name
	 *            path name
	 * @return if the path name has a Jar archive extension
	 */
	boolean hasJarArchiveExtension(String name);

	/**
	 * The factory for project-dependent objects.
	 * 
	 * @return the factory for project-dependent objects
	 */
	IFactory getFactory();

	/**
	 * Check if the given IXFile is a resource needed in the project.
	 * 
	 * @param xFile
	 *            the file to be checked
	 * 
	 * @return if the file is to be used as a resource
	 */
	boolean isWantedResourceXFile(IXFile xFile);

	/**
	 * Register an issue of the given category.
	 * 
	 * @param issueCategory
	 *            the issue's category
	 * 
	 * @param fileOrNull
	 *            an optional file that is assigned to this issue
	 * 
	 * @param issueDescriptionHierarchy
	 *            the description, as a sequence of strings that provide more
	 *            and more detail
	 */
	void registerIssue(IIssueCategory issueCategory, IXFile fileOrNull,
			String... issueDescriptionHierarchy);

	/**
	 * Check if the method matches some of the given method patterns
	 * 
	 * @param methodDescriptor
	 *            the method to be matched
	 * @param patterns
	 *            the patterns in which to look
	 * @return if some match was found
	 */
	boolean someMethodPatternMatches(IMethodDescriptor methodDescriptor,
			Collection<IMethodPattern> patterns);

	/**
	 * Check if the method matches some of the given method patterns
	 * 
	 * @param methodDescriptor
	 *            the method to be matched
	 * @param method
	 *            matcher the method matcher in which to look
	 * @return if some match was found
	 */
	boolean someMethodPatternMatches(IMethodDescriptor methodDescriptor, IMethodMatcher matcher);

	/**
	 * Map from kind identifiers to the associated method patterns for
	 * specifying callers of intercepted methods.
	 * 
	 * @return map specifying callers of intercepted methods
	 */
	Map<String, LinkedHashSet<ICallerOfInterceptedMethodMethodPattern>> getCallersOfInterceptedMethodPatternsByKindId();

	/**
	 * Deliver the kind for the given id, or null if it does not exist.
	 * 
	 * @param kindId
	 *            the id of the pattern kind to get
	 * @return the pattern kind for the id, or null
	 */
	IPatternKind getPatternKindForIdOrNull(String kindId);

	/**
	 * Map from kind identifiers to the associated method patterns for the given
	 * kind of method patterns.
	 * 
	 * @param methodPatternKind
	 *            kind of method patterns
	 * @return map from pattern ids to associated patterns for the given pattern
	 *         kind
	 */
	Map<String, LinkedHashSet<IMethodPattern>> getMethodPatternsMapForMPKindOrNull(
			String methodPatternKind);

	/**
	 * Determine the input patterns that match the method descriptor
	 * 
	 * @param inputPatterns
	 *            the input patterns in which to look for matches
	 * @param md
	 *            the method descriptor to be matched
	 * @param needExclusionsInResult
	 *            if matching exclusion patterns should be included in the
	 *            result, if any
	 * @return the list of matching input patterns
	 */
	List<IMethodPattern> mkMethodPatternsMatchingSelectorAndDeclaringClass(
			Collection<IMethodPattern> inputPatterns, IMethodDescriptor md,
			boolean needExclusionsInResult);

	/**
	 * Check if the framework simulation with the given id is active.
	 * 
	 * @param pluginId
	 *            the plugin id to check
	 * @return if the plugin has been switched to active in the config file
	 */
	boolean isFrameworkSimulationActive(PluginID pluginId);

	/**
	 * Checks of the given type is a class with type parameters.
	 * 
	 * @param type
	 *            the type to be checked
	 * 
	 * @return if the type is a class with type parameters
	 */
	boolean isClassWithTypeParams(ITypeDescriptor type);

	/**
	 * Determine the names of servlets that deal with the given resource.
	 * 
	 * @param resource
	 *            resource to be checked
	 * 
	 * @return set of servlet names that can deal with the resource
	 */
	Set<String> determineServletNamesForResource(String resource);

	/**
	 * Determine the classes implementing the servlets that deal with the given
	 * resource.
	 * 
	 * @param resource
	 *            resource to be checked
	 * 
	 * @return set of servlet class names that can deal with the resource
	 */
	Set<String> determineServletClassesForResource(String resource);

	/**
	 * The JSP information collected for the current project.
	 * 
	 * @return Jsp information
	 */
	IJSPInfo getJspInfo();

	/**
	 * Provides extra framework parameters for some framework id, if any.
	 * 
	 * @param pluginID
	 *            the plugin to be checked
	 * 
	 * @return extra framework parameters for the plugin
	 */
	IExtraFrameworkParameters getExtraFrameworkParametersOrNull(PluginID pluginID);

	/**
	 * @param xmlElementNameOfXanitizerConfigurationValue
	 *            the name of the XML element used to store the configuration
	 *            value in the Xanitizer configuration file
	 * @param defaultValue
	 *            the default value to return in case of some problem
	 * @return the configuration value for the element name, or the default
	 *         value if there is none; guaranteed to be an instance of the
	 *         default value's class
	 */
	Object getPluginDefinedXanitizerConfigurationValue(
			String xmlElementNameOfXanitizerConfigurationValue, Object defaultValue);

	/**
	 * @param clazz
	 *            the class to be checked
	 * @return if the clazz is defined in a module, but is not generally
	 *         exported
	 */
	boolean isClassFromModuleAndNotExported(IClass clazz);

	/**
	 * 
	 * @return The file context of the current project.
	 */
	IXFileContext getFileContext();
}
