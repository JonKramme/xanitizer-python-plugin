/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on 17.01.2017
 *
 */
package com.rigsit.xanitizer.pub.plugin;

import java.io.File;
import java.io.IOException;
import java.util.Collection;

import com.rigsit.xanitizer.pub.callgraph.ICallGraphProcessor;
import com.rigsit.xanitizer.pub.callgraph.ICallerSpec;
import com.rigsit.xanitizer.pub.languageelements.IClass;
import com.rigsit.xanitizer.pub.languageelements.IMethod;
import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;
import com.rigsit.xanitizer.pub.languageelements.ITypeDescriptor;
import com.rigsit.xanitizer.pub.problemtypes.IProblemTypeRegistry;
import com.rigsit.xanitizer.pub.util.IDOMProcessor;

/**
 * The interface describes a framework simulation plugin.
 *
 * The methods with just one argument are invoked exactly once.
 * 
 * The methods with a single IFrameworkSimulationContext argument are invoked in
 * the order in which they are defined in this interface. These methods are
 * called life cycle methods.
 * 
 * Details are described in the documentation of the single methods.
 * 
 * @author nwe
 *
 */
public interface IFrameworkSimulationPlugin extends IConfigurationItemSupplier {

	/**
	 * Set up the internal state of this framework simulation plugin.
	 * 
	 * The first life cycle methods being invoked.
	 * 
	 * @param context
	 *            the framework simulation context to use
	 */
	void setUp(IFrameworkSimulationContext context);

	/**
	 * Deliver an optional DOM processor for processing the XML files in the
	 * projects workspace.
	 * 
	 * If the plugin wants to be told about XML files as DOMs, it has to return
	 * the DOM processor here. Each XML belonging to the projects workspace will
	 * be processed with this plugin. In XML files need not be analyzed, the
	 * plugin returns null.
	 * 
	 * A life cycle method.
	 * 
	 * @param context
	 *            the framework simulation context to use
	 * 
	 * @return null, or the DOM processor to use
	 */
	IDOMProcessor mkDOMProcessorOrNull(IFrameworkSimulationContext context);

	/**
	 * Called by the environment when the class hierarchy is to be processed.
	 * 
	 * A life cycle method.
	 * 
	 * @param context
	 *            the framework simulation context to use
	 */
	void processClassHierarchy(IFrameworkSimulationContext context);

	/**
	 * Called by the environment when the simulation code is to be generated.
	 * 
	 * When called, this method should generate all the simulation code needed
	 * for simulating the framework, using the context object.
	 * 
	 * A life cycle method.
	 * 
	 * @param context
	 *            the framework simulation context to use
	 * 
	 * @throws IOException
	 *             when the simulation code could not be written to disk
	 */
	void generateFrameworkSimulationCode(IFrameworkSimulationContext context) throws IOException;

	/**
	 * Return a collection of type descriptors of types that should be analyzed
	 * on the control-flow level in addition to workspace types, if there are
	 * any.
	 * 
	 * A life cycle method.
	 * 
	 * @param context
	 *            the framework simulation context to use
	 * @return null, or the types for which to investigate control flows in
	 *         addition to workspace types
	 */
	Collection<ITypeDescriptor> getAdditionalClassesToBeAnalyzedOrNull(
			IFrameworkSimulationContext context);

	/**
	 * During call graph construction, a plugin can specify to use another than
	 * the default target for a call by implementing this method.
	 * 
	 * Is invoked during call graph construction, possibly zero or several
	 * times.
	 * 
	 * @param callerSpec
	 *            describes the call location
	 * @param receiver
	 *            the class being called
	 * @param context
	 *            the framework simulation context
	 * @return null if no special method is provided instead of the default one,
	 *         or the method to be entered
	 */
	IMethod mkCalleeTargetOrNull(ICallerSpec callerSpec, IClass receiver,
			IFrameworkSimulationContext context);

	/**
	 * Check if (a) this framework simulation plugin is relevant for the given
	 * method, and (b) if calls in the framework simulation method represented
	 * by the method descriptor for which, during call graph construction, not
	 * exactly one instance is artificially generated (i.e., there is a
	 * non-trivial instance sets), should be extended artificially. Normally, we
	 * do not want such an extension.
	 * 
	 * Is invoked during call graph construction, possibly zero or several
	 * times.
	 * 
	 * @param methodDescriptor
	 *            descriptor of the method call inside which to check
	 * @param context
	 *            framework simulation context
	 * @return if both (a) this framework simulation plugin has something to say
	 *         about the method, and (b) calls in the method should be extended
	 *         even in case of non-trivial instance sets
	 */
	boolean isFrameworkAnalysisRelevantForMethodAndShouldCallsInMethodBeExtendedForNonTrivialInstanceSetsDuringCallGraphConstruction(
			IMethodDescriptor methodDescriptor, IFrameworkSimulationContext context);

	/**
	 * Return a processor for call graphs.
	 * 
	 * The environment calls this method when a call graph has been computed. If
	 * null is returned, the call graph will not be processed by this framework
	 * simulation plugin; otherwise, the call graph will be processed by this
	 * call graph processor.
	 * 
	 * A life cycle method.
	 * 
	 * @param context
	 *            the framework simulation context to use
	 * @return null, or the call graph processor to use on the call graphs
	 */
	ICallGraphProcessor mkCallGraphProcessorOrNull(IFrameworkSimulationContext context);

	/**
	 * Called by the environment when the framework findings are to be
	 * generated.
	 * 
	 * When called, this method should generate findings for the problems that
	 * this framework simulation plugin detects.
	 * 
	 * A life cycle method.
	 * 
	 * @param context
	 *            the framework simulation context to use
	 */
	void registerFrameworkFindings(IFrameworkSimulationContext context);

	/**
	 * Check if some directory might require analysis by this plugin.
	 * 
	 * @param dir
	 *            the directory to be checked
	 * @return if the directory (disregarding subdirectories) might be
	 *         interesting for this plugin.
	 */
	default boolean isInterestedInDirectory(File dir) {
		return false;
	}
	
	/**
	 * Register the additional problem types for which this plugin might
	 * generate findings.
	 * 
	 * This is called once, but the order with respect to other methods is not
	 * fixed.
	 * 
	 * @param problemTypeRegistry
	 *            the problem type registration to use for registering the
	 *            problem types findings for which might be generated
	 */
	void registerAdditionalProblemTypes(IProblemTypeRegistry problemTypeRegistry);
}
