/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Dec 12, 2019
 *
 */
package com.rigsit.xanitizer.pub.plugin;

import java.io.File;
import java.net.URL;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.rigsit.xanitizer.pub.problemtypes.IProblemType;
import com.rigsit.xanitizer.pub.util.IIssueCategory;
import com.rigsit.xanitizer.pub.util.IIssueInformation;
import com.rigsit.xanitizer.pub.util.ISearchPathKind;
import com.rigsit.xanitizer.pub.util.ISourceLineData;
import com.rigsit.xanitizer.pub.util.IXFile;
import com.rigsit.xanitizer.pub.util.IXFileContext;

/**
 * @author rust
 *
 */
public interface ILanguageContext extends ISystemContext {

	public interface IFactory {
		/**
		 * Create an IXFile instance from a relative path.
		 * 
		 * @param relativePath
		 *            the relative path to be used for constructing the IXFile
		 * @param pathVariableOrNull
		 *            null, or a path variable, if the result should be based on
		 *            one
		 * @return the resulting IXFile
		 */
		IXFile mkXFileFromRelativePath(String relativePath, String pathVariableOrNull);

		/**
		 * Create an IXFile from an absolute path.
		 * 
		 * @param absolutePathPerhapsWithBangs
		 *            the absolute path to be used for constructing the IXFile;
		 *            is allowed to contain !/ components, notating ZIP members
		 * @return the resulting IXFile
		 */
		IXFile mkXFileFromAbsoluteFile(String absolutePathPerhapsWithBangs);

		/**
		 * Create an IXFile from the fully qualified name of a Java class.
		 * 
		 * @param fqName
		 *            the fully qualified name of the class.
		 * @return the resulting IXFile
		 */
		IXFile mkXFileFromClassFQN(String fqName);

		/**
		 * Create an IXFile from an URL.
		 * 
		 * @param url
		 *            URL to create an XFile for
		 * @return the XFile corresponding to the argument
		 */
		IXFile mkXFileFromUrl(URL url);

		/**
		 * Create a source line data object.
		 * 
		 * @param xFile
		 *            the resource
		 * @param lineNoOrMinus1
		 *            minus 1, or the line number in the resource
		 * @param veryShortDescOrNull
		 *            a very short description
		 * @param generateMarker
		 *            should Xanitizer generate a marker in the source code
		 *            viewer for thus location
		 * @return the constructed object
		 */
		ISourceLineData mkSourceLineData(IXFile xFile, int lineNoOrMinus1,
				String veryShortDescOrNull, boolean generateMarker, int depth, String factOrNull);
	}

	/**
	 * Create a search path for the given kind and absolute file.
	 */
	ISearchPath mkSearchPath(ISearchPathKind searchPathKind, File absFileOrDir);

	IProblemType getActiveProblemTypeForIDOrNull(String problemTypeId);

	Collection<File> mkSearchPathFiles(ISearchPathKind searchPathKind);

	/**
	 * 
	 * @param problemType
	 *            the problem type
	 * @param xFile
	 *            the file in which the finding occurred
	 * @param lineNoOrMinus1
	 *            the line number in the file, or -1
	 * @param oneLineDescription
	 *            a one-line description of the problem
	 * @param sourceLineData
	 *            source line data, especially for paths
	 * @param categoryPresentationName
	 *            the presentation name of the problem category
	 * @param categoryDescription
	 *            a description of the problem category
	 * @param categoryHasPaths
	 *            if the problem category has data flow paths
	 * @param confidence
	 *            confidence; negative if not set, 10 for 'low', 20 for
	 *            'medium', 30 for 'high'
	 */
	void registerFinding(IProblemType problemType, IXFile xFile, int lineNoOrMinus1,
			String oneLineDescription, List<ISourceLineData> sourceLineData,
			String categoryPresentationName, String categoryDescription, boolean categoryHasPaths,
			int confidence);

	IFactory getFactory();

	/**
	 * @param xmlElementNameOfXanitizerConfigurationValue
	 *            the name of the XML element used to store the configuration
	 *            value in the Xanitizer configuration file
	 * @param defaultValue
	 *            the default value to return in case of some problem
	 * @return the configuration value for the element name, or the default
	 *         value if there is none; guaranteed to be an instance of the
	 *         default value's class
	 */
	<T> T getPluginDefinedXanitizerConfigurationValue(
			String xmlElementNameOfXanitizerConfigurationValue, T defaultValue);

	/**
	 * Record an analysis issue
	 * 
	 * @param issueCategory
	 * @param args
	 *            arguments for the issue category
	 */
	IIssueInformation registerIssue(IIssueCategory issueCategory, String... args);

	/**
	 * Determine the active problem type with ids that have the given prefix.
	 */
	Collection<String> getActiveProblemTypesWithIdPrefix(String idPrefix);

	/**
	 * Registers the specified file as workspace resource
	 * 
	 * @param category
	 *            The name of the resources root.
	 * @param file
	 *            The corresponding file of the resource.
	 * @param origPath
	 *            The original path in the user's file system.
	 */
	void registerWorkspaceResource(String category, IXFile file, URL origPath);

	/**
	 * Registers a metric.
	 * 
	 * @param metricId
	 *            the metric id
	 * @param presentationName
	 *            the metric's presentation name
	 */
	void registerMetric(String metricId, String presentationName);

	/**
	 * Registers a metric value under a name.
	 * 
	 * @param metricId
	 *            the metric id
	 * @param value
	 *            the metric value
	 */
	void registerMetricValueChange(String metricId, int value);

	/**
	 * Determine the project directory, typically in the $HOME/.Xanitizer
	 * directory.
	 * 
	 * @return the project directory
	 */
	File getProjectDirectory();

	/**
	 * @return a directory for temporary work data
	 */
	File getTmpWorkDirectory();

	/**
	 * Provide the framework ids that should be excluded from analysis for a
	 * plugin.
	 */
	Set<String> getExcludedFrameworkIds(PluginID pluginId);

	/**
	 * 
	 * @return The file context of the current project.
	 */
	IXFileContext getFileContext();

	/**
	 * Get the value of a property.
	 * 
	 * @param propertyName
	 * @return
	 */
	String getPropertyValue(String propertyName);

}
