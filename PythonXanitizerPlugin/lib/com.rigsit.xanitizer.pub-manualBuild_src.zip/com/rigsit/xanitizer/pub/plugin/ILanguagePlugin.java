/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Dec 12, 2019
 *
 */
package com.rigsit.xanitizer.pub.plugin;

import java.io.File;
import java.nio.file.Path;
import java.util.Collection;
import java.util.List;

import com.rigsit.xanitizer.pub.util.ICancelListener;
import com.rigsit.xanitizer.pub.util.ISearchPathKind;
import com.rigsit.xanitizer.pub.util.ProgrammingLanguage;

public interface ILanguagePlugin extends IConfigurationItemSupplier {

	/**
	 * Return the programming language that is analyzed by this plugin.
	 * 
	 * @return
	 */
	ProgrammingLanguage getProgrammingLanguage();

	/**
	 * Starting from the root, collect all paths that are relevant for this
	 * plugin.
	 */
	Collection<ISearchPath> collectSearchPaths(Path root, ILanguageContext ctxt,
			ICancelListener cancelListener);

	/**
	 * All search path kinds that this plugin knows about.
	 */
	Collection<ISearchPathKind> getSearchPathKinds();

	/**
	 * For registering findings.
	 */
	void registerFindings(ILanguageContext ctxt, ICancelListener cancelListener);

	/**
	 * For registering resources.
	 * 
	 * @param ctxt
	 * @param cancelListener
	 */
	void registerWorkspaceResources(ILanguageContext ctxt, ICancelListener cancelListener);

	/**
	 * The list of libraries (files or directories) relevant for this plugin.
	 */
	List<File> getLibraries(ILanguageContext ctxt, ICancelListener cancelListener);

	/**
	 * Register the additional problem types and frameworks for which this
	 * plugin might generate findings.
	 * 
	 * This is called once, but the order with respect to other methods is not
	 * fixed.
	 * 
	 * @param registry
	 */
	void registerAdditionalProblemTypesAndFrameworks(ILanguagePluginRegistry registry);

	/**
	 * 
	 * @return False if all required workspace data is present, false otherwise.
	 */
	boolean workspaceParsingNecessary(ILanguageContext ctxt);

	/**
	 * 
	 * @return A list of configuration option keys that have to be configured if
	 *         a new project is setup.
	 */
	Collection<String> getConfigurationOptionsForInitialSetup();

	void resetData();
}
