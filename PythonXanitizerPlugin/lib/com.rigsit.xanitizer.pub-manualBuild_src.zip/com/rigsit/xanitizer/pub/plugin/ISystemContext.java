/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Mar 18, 2020
 *
 */
package com.rigsit.xanitizer.pub.plugin;

import java.io.File;
import java.io.InputStream;

/**
 * @author rust
 *
 */
public interface ISystemContext {
	/**
	 * 
	 * @return the plugin directory in the Xanitizer installation
	 */
	File getPluginDirectory();

	/**
	 * 
	 * @return the executable of the JRE bundled with the Xanitizer installation
	 */
	File getJREExecutable();

	/**
	 * Installation directory.
	 */
	File getInstallDirectory();
	
	/**
	 * 
	 * @return True if the current OS is Windows.
	 */
	boolean isWindows();
	
	/**
	 * Return the decrypted version of an encrypted stream
	 * 
	 * @param encrypted
	 *            the encrypted stream
	 * @return the decrypted stream
	 */
	InputStream decrypt(InputStream encrypted);
}
