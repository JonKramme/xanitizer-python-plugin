/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Jul 21, 2016
 *
 */
package com.rigsit.xanitizer.pub.plugin;

/**
 * Interface for Xanitizer plugins.
 * 
 * This has to be implemented by each plugin.
 */
public interface IXanitizerPlugin {

	/**
	 * Is this plugin active?
	 */
	default boolean isActive() {
		return true;
	}

	/**
	 * Return the plugin ID. This must be unique, and may not change over time
	 * for different versions of the plugin.
	 * 
	 * It is a good idea to base the ID on the Java class name of the
	 * implementing class.
	 * 
	 * @return an identifier for this plugin.
	 */
	PluginID getPluginID();

	/**
	 * A name to be used in the GUI when this plugin is to be listed.
	 * 
	 * @return the presentation name of the plugin.
	 */
	String getPresentationName();

	/**
	 * A description of the plugin.
	 * 
	 * Existing line-breaks are honored, but additional line breaks might be
	 * inserted.
	 * 
	 * @return the description of the plugin, to be used in the GUI when
	 *         describing the plugin
	 */
	String getDescription();

	/**
	 * Return the identifiers of plugins that the current plugin is based on.
	 * 
	 * Some plugins need, in order to run, that some other plugins are active.
	 * 
	 * @return the array of identifiers of plugins that this plugin is based on;
	 *         the empty array is returned if the current plugin is not based on
	 *         any other ones.
	 */
	PluginID[] getBasePluginIDs();

}
