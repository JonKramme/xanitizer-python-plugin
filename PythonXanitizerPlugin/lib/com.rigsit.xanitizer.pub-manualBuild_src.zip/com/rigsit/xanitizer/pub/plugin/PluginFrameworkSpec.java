/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Apr 6, 2020
 *
 */
package com.rigsit.xanitizer.pub.plugin;

import com.rigsit.xanitizer.pub.frameworks.IFrameworkSpec;

/**
 * @author rust
 *
 */
public class PluginFrameworkSpec implements IFrameworkSpec {

	private final String m_Id;
	private final String m_PresentationName;
	private final String m_Description;

	public PluginFrameworkSpec(final String id, final String presentationName, final String desc) {
		m_Id = id;
		m_PresentationName = presentationName;
		m_Description = desc;
	}

	@Override
	public String getId() {
		return m_Id;
	}

	@Override
	public String getPresentationName() {
		return m_PresentationName;
	}

	@Override
	public String getDescription() {
		return m_Description;
	}

}
