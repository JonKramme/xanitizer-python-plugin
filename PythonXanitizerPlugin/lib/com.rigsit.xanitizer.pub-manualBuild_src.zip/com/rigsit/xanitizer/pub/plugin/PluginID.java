/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Dec 22, 2016
 *
 */
package com.rigsit.xanitizer.pub.plugin;

/**
 * Type-safe plugin ID (wraps a string).
 *
 */
public class PluginID {
	private final String m_PluginID;

	public PluginID(final String pluginID) {
		m_PluginID = pluginID;
	}

	@Override
	public String toString() {
		return m_PluginID;
	}

	@Override
	public int hashCode() {
		return m_PluginID.hashCode();
	}

	@Override
	public boolean equals(final Object o_) {
		if (this == o_) {
			return true;
		}
		if (o_ == null || o_.getClass() != this.getClass()) {
			return false;
		}
		final PluginID o = (PluginID) o_;
		return m_PluginID.equals(o.m_PluginID);
	}
}
