/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 14, 2016
 *
 */
package com.rigsit.xanitizer.pub.problemtypes;

import com.rigsit.xanitizer.pub.plugin.IXanitizerPlugin;

/**
 * Registry for problem types.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IProblemTypeRegistry {

	/**
	 * Register a problem type.
	 *
	 * This method can be used to register additional problem types that are
	 * provided by a plugin
	 * 
	 * @param problemTypeId
	 *            the identifier of the problem type; in order to make this
	 *            unique,it is a good idea to use a prefix for this problem type
	 *            than starts with the framework id
	 * @param warningRatherThanInfo
	 *            boolean flag telling if instances of this problem type are
	 *            warnings and not mere informations
	 * @param presentationName
	 *            a human-readable name for instances of this problem type
	 * @param description
	 *            a description for instances of these problem type
	 * @param howToFix
	 *            a short description telling how instances of this problem type
	 *            might be fixed
	 * 
	 * @param cweNumber
	 *            the CWE number for this problem type or -1 if no CWE entry
	 *            matches the problem type
	 * @param defaultRating
	 *            the rating, a double in the range from 0 (harmless) to 10
	 *            (most severe)
	 * 
	 * @param isOnByDefault
	 *            if the problem type is switched on (rather than switched off)
	 *            by default
	 * 
	 * @param hasPaths
	 *            if instances of the the problem type have dataflow paths
	 */
	void registerProblemType(IXanitizerPlugin plugin, String problemTypeId,
			boolean warningRatherThanInfo, String presentationName, String description,
			String howToFix, int cweNumber, double defaultRating, boolean isOnByDefault,
			boolean hasPaths);

}
