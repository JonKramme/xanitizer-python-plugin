/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 7, 2016
 *
 */
package com.rigsit.xanitizer.pub.signatures;

/**
 * Type signature for array types.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IArrayTypeSignature extends ITypeSignature {

	/**
	 * The signature of the type of the array elements.
	 * 
	 * @return signature of array content
	 */
	ITypeSignature getContentSignature();

}
