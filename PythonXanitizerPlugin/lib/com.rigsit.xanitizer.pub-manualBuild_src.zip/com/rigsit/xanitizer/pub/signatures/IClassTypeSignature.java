/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 7, 2016
 *
 */
package com.rigsit.xanitizer.pub.signatures;

import java.util.List;

import com.rigsit.xanitizer.pub.languageelements.ITypeDescriptor;

/**
 * Type signature variant: class, with potential further type arguments.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IClassTypeSignature extends ITypeSignature {

	/**
	 * The type signature of the base class.
	 * 
	 * @return the type descriptor
	 */
	ITypeDescriptor getTypeDescriptor();

	/**
	 * List of type arguments, never null, but possibly empty.
	 * 
	 * @return the list of type arguments, possibly empty
	 */
	List<ITypeArgument> getTypeArguments();
}
