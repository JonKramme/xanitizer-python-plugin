/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 7, 2016
 *
 */
package com.rigsit.xanitizer.pub.signatures;

import java.util.List;

/**
 * A method's type signature, i.e., can contain information about generic types.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IMethodTypeSignature {

	/**
	 * The method's return type, possibly generic.
	 * 
	 * @return the return type
	 */
	ITypeSignature getReturnType();

	/**
	 * The method's arguments, possibly generic.
	 * 
	 * @return the list of arguments
	 */
	List<ITypeSignature> getArguments();
}
