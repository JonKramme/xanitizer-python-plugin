/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 7, 2016
 *
 */
package com.rigsit.xanitizer.pub.signatures;

/**
 * Represents a type argument
 *
 * Not meant to be implemented by the simulation code.
 */
public interface ITypeArgument {

	/**
	 * Tells if this is the wild card type argument
	 * 
	 * @return if this is a wildcard type argument
	 */
	boolean isWildcard();

	/**
	 * The type signature of this type argument
	 * 
	 * @return the type signature, or null if there is none
	 */
	ITypeSignature getTypeSignatureOrNull();
}
