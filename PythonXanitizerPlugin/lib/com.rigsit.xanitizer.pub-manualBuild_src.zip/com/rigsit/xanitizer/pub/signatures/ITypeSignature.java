/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 7, 2016
 *
 */
package com.rigsit.xanitizer.pub.signatures;

/**
 * A type signature. There are more specific interfaces for the different kinds
 * of type interfaces.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface ITypeSignature {

	/**
	 * Tells if this is an array type signature
	 * 
	 * @return if this an array type signature
	 */
	boolean isArrayTypeSignature();

	/**
	 * Tells if this is a class type signature
	 * 
	 * @return if this a class type signature
	 */
	boolean isClassTypeSignature();

	/**
	 * Tells if this is a type variable
	 * 
	 * @return if this a type variable
	 */
	boolean isTypeVariable();

	/**
	 * Tells if this is a base type
	 * 
	 * @return if this is a base type
	 */
	boolean isBaseType();
}
