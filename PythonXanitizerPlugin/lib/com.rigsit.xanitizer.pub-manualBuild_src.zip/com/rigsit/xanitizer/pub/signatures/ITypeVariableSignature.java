/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 7, 2016
 *
 */
package com.rigsit.xanitizer.pub.signatures;

/**
 * A variable type signature.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface ITypeVariableSignature extends ITypeSignature {

	/**
	 * The identifier of the type variable
	 * 
	 * @return the type variable identifier
	 */
	String getIdentifier();
}
