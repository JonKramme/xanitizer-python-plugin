/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 2, 2016
 *
 */
package com.rigsit.xanitizer.pub.springmvc;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.rigsit.xanitizer.pub.callgraph.ISpringMVCCallGraphProcessor;
import com.rigsit.xanitizer.pub.languageelements.IMethod;
import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;
import com.rigsit.xanitizer.pub.languageelements.ITypeDescriptor;

/**
 * Provides non-generic internal Xanitizer functionality that, at the moment,
 * cannot be performed by the generic functionality exposed.
 * 
 * Perhaps, we will find the resources some day to extend the generic
 * functionality later so that usages of this interface can be replaced by
 * implementations in the plugin code.
 */
public interface ISpringMVCFrameworkSimulationHelper {

	/**
	 * @param methodDescriptor
	 * @param classParamNum
	 * @param instanceParamNum
	 * @param accu
	 */
	void collectClassesThatAreProvidedAndClassesThatAreInstantiated(
			IMethodDescriptor methodDescriptor, int classParamNum, int instanceParamNum,
			Map<ITypeDescriptor, Set<ITypeDescriptor>> accu);

	/**
	 * @param m
	 * @param paramNumOrMinus1ForReturnValue
	 * @return
	 */
	Set<ITypeDescriptor> mkRuntimeTypesForParameterOrReturnValueLocally(IMethod m,
			int paramNumOrMinus1ForReturnValue);

	/**
	 * @param md
	 * @param paramNum.
	 * @param accu
	 */
	void collectClassesThatAreProvidedAsParameterToAMethodInvocation(IMethodDescriptor md,
			int paramNum, LinkedHashMap<IMethodDescriptor, LinkedHashSet<ITypeDescriptor>> accu);

	/**
	 * @param controllerToURLsMap
	 * @param allPossibleViewNames
	 * @param callerToCalledModelAndViewReturningMethodsAccu
	 * @param modelDataPerHandlerMethodAccu
	 * @param viewNameSearchRequired
	 * @return
	 */
	ISpringMVCCallGraphProcessor mkSpringMVCCallGraphProcessor(String freemarkerPkgWithDor,
			Map<ISpringMVCController, Set<String>> controllerToURLsMap,
			Set<String> allPossibleViewNames,
			LinkedHashMap<IMethodDescriptor, Set<IMethodDescriptor>> callerToCalledModelAndViewReturningMethodsAccu,
			Map<IMethodDescriptor, ISpringMVCModelDataOfOneHandlerMethod> modelDataPerHandlerMethodAccu,
			boolean viewNameSearchRequired);

	/**
	 * A Spring MVC controller object is represented either by a method
	 * descriptor, or a type descriptor.
	 * 
	 * Exactly one of the two get methods with return a non-null value.
	 */
	public interface ISpringMVCController {

		IMethodDescriptor getMethodDescriptorOrNull();

		ITypeDescriptor getTypeDescriptorOrNull();
	}
}
