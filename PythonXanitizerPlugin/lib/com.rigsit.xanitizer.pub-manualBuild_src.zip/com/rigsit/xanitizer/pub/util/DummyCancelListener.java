/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Feb 11, 2013
 *
 */
package com.rigsit.xanitizer.pub.util;

/**
 * @author rust
 * 
 */
public class DummyCancelListener implements ICancelListener {

	public DummyCancelListener() {
	}

	@Override
	public String getReasonIfCancelledOrNull() {
		return null;
	}

	@Override
	public String getProgressMessageOrNull() {
		return null;
	}
}
