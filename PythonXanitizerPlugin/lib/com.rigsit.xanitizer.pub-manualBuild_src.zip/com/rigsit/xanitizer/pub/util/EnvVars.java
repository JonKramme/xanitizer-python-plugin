package com.rigsit.xanitizer.pub.util;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * ATTENTION: Changes on these file have to be reflected at the adapted files
 * for other languages (e.g. TypeScript)!
 */
public enum EnvVars {
	/**
	 * Used for the Xanitizer SARIF exporter to make paths relative to the
	 * checkout directory of the GitHub repository. The relative paths are used
	 * by GitHub to display the source code for findings and path segments.
	 * 
	 * If the Xanitizer configuration file is not located in the root directory
	 * of the GitHub repository, the relative paths from Xanitizer contains ../
	 * path segments which can not be handled by GitHub.
	 * 
	 * Furthermore if this environment variable is set, some special GitHub
	 * changes will be applied to the exported SARIF file so that the resulting
	 * SARIF file can be successfully imported by the GitHub Developer Security
	 * Portal (DSP).
	 */
	XAN_GITHUB_CHECKOUT_LOCATION,

	/**
	 * Used during Java-to-bytecode compilation as parameter with "-encoding
	 * <value>" for overriding the default "utf-8', and used during Java source
	 * code parsing.
	 */
	XAN_JAVAC_ENCODING,

	/**
	 * If set to 'true', the TLD file analysis during JSP processing is logged
	 * in detail.
	 */
	XAN_LOG_DETAILED_TLD_ANALYSIS,

	;

	private final static Logger LOG = Logger.getLogger(EnvVars.class.getName());

	public boolean isSet() {
		return getValue() != null;
	}

	public String getValue() {
		return System.getenv(this.name());
	}

	private static Charset s_JavaSourceCharSetCache;

	public static Charset mkJavaSourceCharSet() {
		if (null != s_JavaSourceCharSetCache) {
			return s_JavaSourceCharSetCache;
		}
		// Default.
		s_JavaSourceCharSetCache = StandardCharsets.UTF_8;
		final var envVarValue = EnvVars.XAN_JAVAC_ENCODING.getValue();
		if (null != envVarValue) {
			try {
				s_JavaSourceCharSetCache = Charset.forName(envVarValue);
			} catch (final Exception ex) {
				final var sb = new StringBuilder();
				sb.append("[");
				Charset.availableCharsets().keySet().forEach(cs -> {
					sb.append(cs);
					sb.append(",");
				});
				sb.append("]");
				LOG.log(Level.WARNING, String.format(
						"Unable to create Charset from value '%s' of env var '%s', reverting to UTF-8\nAvailable: "
								+ sb,
						envVarValue, EnvVars.XAN_JAVAC_ENCODING.name()), ex);
			}
		}
		return s_JavaSourceCharSetCache;
	}
}