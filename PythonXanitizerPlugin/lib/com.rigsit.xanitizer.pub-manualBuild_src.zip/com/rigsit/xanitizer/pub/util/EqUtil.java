/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 27, 2013
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;

/**
 * @author rust
 * 
 */
public class EqUtil {
	
	public static int hashCode(final Object o) {
		return o == null ? 0 : o.hashCode();
	}

	@SuppressWarnings("unlikely-arg-type")
	public static <T, U> boolean sameContent(final Collection<T> c1, final Collection<U> c2) {
		if (c1 == c2) {
			return true;
		}
		if (c1 == null) {
			return c2.isEmpty();
		}
		if (c2 == null) {
			return c1.isEmpty();
		}

		final HashSet<T> h1 = new HashSet<T>(c1);
		final HashSet<U> h2 = new HashSet<U>(c2);
		if (h1.size() != h2.size()) {
			return false;
		}
		return h1.containsAll(h2);
	}

	public static <K, V> boolean sameMapContent(final Map<K, V> m1, final Map<K, V> m2) {
		if (m1 == m2) {
			return true;
		}
		if (m1 == null || m2 == null) {
			return false;
		}
		if (m1.size() != m2.size()) {
			return false;
		}
		for (final Map.Entry<K, V> e : m1.entrySet()) {
			final V otherV = m2.get(e.getKey());
			if (!sameOrSameContent(e.getValue(), otherV)) {
				return false;
			}
		}
		return true;
	}

	public static boolean sameOrSameContent(final Object o1, final Object o2) {
		if (Objects.equals(o1, o2)) {
			return true;
		}
		if (!(o1 instanceof Collection) || !(o2 instanceof Collection)) {
			return false;
		}
		final Collection<?> c1 = (Collection<?>) o1;
		final Collection<?> c2 = (Collection<?>) o2;
		return sameContent(c1, c2);
	}

	public static boolean sameContent(final Object[] a1, final Object[] a2) {
		if (a1 == a2) {
			return true;
		}
		if (a1 == null || a2 == null) {
			return false;
		}
		if (a1.length != a2.length) {
			return false;
		}
		final int len = a1.length;
		for (int i = 0; i < len; ++i) {
			if (!Objects.equals(a1[i], a2[i])) {
				return false;
			}
		}
		return true;
	}
}
