/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on 14.06.2019
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.util.HashSet;
import java.util.Set;

/**
 * @author norma
 *
 */
public class FileExtensions {

	public final static Set<String> JAR_ARCHIVE_EXTENSIONS;
	public final static Set<String> ZIP_ARCHIVE_EXTENSIONS;
	public final static Set<String> CODE_EXTENSIONS;
	public static final Set<String> JSP_EXTENSIONS;
	public static final Set<String> XML_EXTENSIONS;
	public static final Set<String> CONFIG_FILE_EXTENSIONS;
	public final static Set<String> WAR_EAR_EXTENSIONS;
	public final static Set<String> BYTE_CODE_EXTENSIONS;

	public static final String POM_FILE = "pom.xml";

	static {
		// edit ConfigureSearchPathsComposites if this changes
		JAR_ARCHIVE_EXTENSIONS = new HashSet<>();
		JAR_ARCHIVE_EXTENSIONS.add("jar");
		JAR_ARCHIVE_EXTENSIONS.add("jmod");
		JAR_ARCHIVE_EXTENSIONS.add("aar");

		BYTE_CODE_EXTENSIONS = new HashSet<>();
		BYTE_CODE_EXTENSIONS.add("class");

		ZIP_ARCHIVE_EXTENSIONS = new HashSet<>();
		ZIP_ARCHIVE_EXTENSIONS.add("zip");
		ZIP_ARCHIVE_EXTENSIONS.addAll(JAR_ARCHIVE_EXTENSIONS);

		// WAR and EAR files have the class files in a form that Wala does not
		// accept (the root of the archive is not the root of the namespace).
		// Let us drop them from ZIP archive extensions.

		CODE_EXTENSIONS = new HashSet<>();
		CODE_EXTENSIONS.add("java");
		CODE_EXTENSIONS.add("scala");
		CODE_EXTENSIONS.addAll(BYTE_CODE_EXTENSIONS);

		WAR_EAR_EXTENSIONS = new HashSet<>();
		WAR_EAR_EXTENSIONS.add("war");
		WAR_EAR_EXTENSIONS.add("ear");

		JSP_EXTENSIONS = new HashSet<>();
		JSP_EXTENSIONS.add("jsp");

		XML_EXTENSIONS = new HashSet<>();
		XML_EXTENSIONS.add("xml");
		XML_EXTENSIONS.add("wsdd");

		// For now, just ...properties files.
		CONFIG_FILE_EXTENSIONS = new HashSet<>();
		CONFIG_FILE_EXTENSIONS.add("properties");
	}

}
