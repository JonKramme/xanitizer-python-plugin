/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Sep 26, 2012
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipFile;

import com.rigsit.xanitizer.pub.util.collections.SetUtil;
import com.rigsit.xanitizer.pub.util.regex.RegexUtil;

/**
 * @author rust
 * 
 */
public class FileUtil {
	private final static Logger LOG = Logger.getLogger(FileUtil.class.getName());

	public static long getLatestTimestamp(final File[] files, final String... filteredExtensions) {
		long latest = 0;

		for (File file : files) {
			final long lastModified;
			if (file.isFile()) {
				if (filteredExtensions.length > 0) {
					boolean skip = false;
					final String extension = getFileNameExtensionOrEmpty(file.getName());
					for (String filteredExtension : filteredExtensions) {
						if (filteredExtension.equals(extension)) {
							skip = true;
							break;
						}
					}
					if (skip) {
						continue;
					}
				}

				lastModified = file.lastModified();
			} else if (file.isDirectory()) {
				lastModified = getLatestTimestamp(file.listFiles(), filteredExtensions);

			} else {
				lastModified = 0;
			}
			if (lastModified > latest) {
				latest = lastModified;
			}
		}
		return latest;

	}

	public static boolean canWriteToDirectory(final File directory) {
		/*
		 * Create and delete a dummy file in order to check file permissions.
		 * Maybe there is a safer way for this check.
		 */
		File sample = new File(directory, "writeTest.xanitizer");
		try {
			sample.createNewFile();
			deleteRecursively(sample);
			return true;
		} catch (IOException e) {
			return false;
		}
	}

	public static OutputStream openBufferedOutputFile(final File file) throws IOException {
		return new BufferedOutputStream(new FileOutputStream(file));
	}

	public static OutputStream openCompressedOutputFile(final File file) throws IOException {
		return new BufferedOutputStream(new GZIPOutputStream(new FileOutputStream(file)));
	}

	public static InputStream openCompressedInputFile(final File file) throws IOException {
		return new BufferedInputStream(new GZIPInputStream(new FileInputStream(file)));
	}

	public static String getFileNameExtensionOrEmpty(final String fileName) {
		final int idx = fileName.lastIndexOf('.');
		if (idx == -1)
			return "";
		return fileName.substring(idx + 1);
	}

	public static String getFileNameWOExtension(final File file) {
		final String fileName = file.getName();
		final int indexOfPoint = fileName.lastIndexOf(".");
		if (indexOfPoint == -1) {
			return fileName;
		}
		return fileName.substring(0, indexOfPoint);
	}

	public static boolean isZipFormatArchive(final String name) {
		return FileExtensions.ZIP_ARCHIVE_EXTENSIONS
				.contains(getFileNameExtensionOrEmpty(name).toLowerCase());
	}

	public static boolean isJAR(final String name) {
		return FileExtensions.JAR_ARCHIVE_EXTENSIONS
				.contains(getFileNameExtensionOrEmpty(name).toLowerCase());
	}

	public static boolean isJsp(final String name) {
		return FileExtensions.JSP_EXTENSIONS
				.contains(getFileNameExtensionOrEmpty(name).toLowerCase());
	}

	public static boolean isXML(final String name) {
		return FileExtensions.XML_EXTENSIONS
				.contains(getFileNameExtensionOrEmpty(name).toLowerCase());
	}

	public static boolean isJavaClassFile(final String name) {
		return getFileNameExtensionOrEmpty(name).toLowerCase().equals("class");
	}

	public static boolean isJavaSourceFile(final String name) {
		return getFileNameExtensionOrEmpty(name).toLowerCase().equals("java");
	}

	public static File mkCanonical(final File file) {
		try {
			return file.getCanonicalFile();
		} catch (final IOException ex) {
			return file;
		}
	}

	public static void close(final InputStream is) {
		if (is == null) {
			return;
		}
		try {
			is.close();
		} catch (final IOException ex) {
			LOG.log(Level.WARNING, "Closing input stream", ex);
		}
	}

	public static void close(final OutputStream os) {
		if (os == null) {
			return;
		}
		try {
			os.close();
		} catch (final IOException ex) {
			LOG.log(Level.WARNING, "Closing output stream", ex);
		}
	}

	public static void close(final ZipFile zf) {
		if (zf == null) {
			return;
		}
		try {
			zf.close();
		} catch (final IOException ex) {
			LOG.log(Level.WARNING, "Closing zip file " + zf.getName(), ex);
		}
	}

	public static byte[] getBytes(final InputStream is) throws IOException {
		final LinkedHashMap<byte[], Integer> buffers = new LinkedHashMap<byte[], Integer>();
		int sum = 0;
		while (true) {
			final byte[] buffer = new byte[8192];
			final int cnt = is.read(buffer);
			if (cnt == -1) {
				break;
			}
			buffers.put(buffer, cnt);
			sum += cnt;
		}

		final byte[] result = new byte[sum];
		int idx = 0;
		for (final Map.Entry<byte[], Integer> e : buffers.entrySet()) {
			final int len = e.getValue();
			System.arraycopy(e.getKey(), 0, result, idx, len);
			idx += len;
		}
		return result;
	}

	public static int countLOC(final InputStream is, final Charset cs) throws IOException {
		final BufferedReader br = new BufferedReader(
				new InputStreamReader(new BufferedInputStream(is), cs));
		int result = 0;
		while (null != br.readLine()) {
			++result;
		}
		return result;
	}

	public static void copySimpleFileLoggingException(final File source, final File target) {
		try {
			copySimpleFile(source, target);
		} catch (final IOException ex) {
			LOG.log(Level.WARNING,
					"Problem occurred while copying file \"" + source + "\" to \"" + target + "\"",
					ex);
		}
	}

	public static void copySimpleFile(final File source, final File target) throws IOException {
		if (!source.isFile()) {
			/*
			 * If the source does not exist then try it once again. On Windows
			 * sometimes a write operation is not yet finished (e.g. unzip). So
			 * we wait here for a short time and try it again.
			 */
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				LOG.log(Level.WARNING, "Unexpected interrupted", e);
			}
			LOG.log(Level.INFO, "Second attempt to copy file " + source.getAbsolutePath());
		}

		try (

				final FileInputStream is = new FileInputStream(source);
				final FileOutputStream os = new FileOutputStream(target);

		) {
			copy(is, os);
		}
	}

	public static void copyRecursively(File source, File target,
			final Predicate<String> filterForFileNamesToSkipOrNull,
			final boolean deleteExistingTargetDirectories) throws IOException {
		final List<File> workList = new ArrayList<File>();
		workList.add(source);
		workList.add(target);

		final Set<File> alreadyCopied = new HashSet<File>();

		while (!workList.isEmpty()) {
			target = workList.remove(workList.size() - 1);
			source = workList.remove(workList.size() - 1);

			if (!alreadyCopied.add(source.getCanonicalFile())) {
				LOG.warning("Recursive copy: Not copying " + source
						+ " because it already has been copied");
				continue;
			}

			if (target.exists()) {
				if (!target.isDirectory() || deleteExistingTargetDirectories) {
					deleteRecursively(target);
				}
			}
			if (source.isFile()) {
				copySimpleFile(source, target);
				continue;
			}

			if (!source.isDirectory()) {
				LOG.warning("Recursive copy: Unable to copy " + source
						+ ": is neither a simple file nor a directory");
				continue;
			}

			mkDirs(target);

			final File[] content = source.listFiles();
			if (content == null) {
				throw new IOException(
						"Recursive copy: Unable to list content of directory " + source);
			}
			for (final File f : content) {
				if (filterForFileNamesToSkipOrNull != null
						&& filterForFileNamesToSkipOrNull.test(f.getName().replace('\\', '/'))) {
					continue;
				}
				workList.add(f);
				workList.add(new File(target, f.getName()));
			}
		}
	}

	public static void copy(final InputStream is, final OutputStream os) throws IOException {
		final byte[] b = new byte[8096];
		while (true) {
			final int cnt = is.read(b);
			if (cnt == -1) {
				return;
			}
			os.write(b, 0, cnt);
		}
	}

	public static File resolve(final File absoluteReferencingFile, final String referencedFile,
			final Map<String, String> varDefs) {
		assert absoluteReferencingFile.isAbsolute();
		assert !absoluteReferencingFile.isDirectory();

		final String fileNameWReplacedEnvVars = VarUtil.replaceVarRefs(referencedFile, varDefs);
		File f = new File(fileNameWReplacedEnvVars);
		if (!f.isAbsolute()) {
			f = new File(absoluteReferencingFile.getParentFile(), fileNameWReplacedEnvVars);
		}
		try {
			return f.getCanonicalFile();
		} catch (final IOException ex) {
			return f;
		}
	}

	public static List<File> resolvePattern(final File absoluteBaseDir,
			final String referencedFilePattern) {
		return resolvePattern(absoluteBaseDir, referencedFilePattern, _file -> true);
	}

	public static List<File> resolvePattern(final File absoluteBaseDir,
			final String referencedFilePattern, final Predicate<File> acceptor) {
		return resolvePattern(absoluteBaseDir, referencedFilePattern, acceptor, System.getenv());
	}

	public static List<File> resolvePattern(final File absoluteBaseDir,
			final String referencedFilePattern, final Predicate<File> acceptor,
			final Map<String, String> varDefs) {
		assert acceptor != null;
		final String filePatternWReplacedEnvVars = VarUtil.replaceVarRefs(referencedFilePattern,
				varDefs);
		File f = new File(filePatternWReplacedEnvVars);
		if (!f.isAbsolute()) {
			f = new File(absoluteBaseDir, filePatternWReplacedEnvVars);
		}

		final List<File> result = new ArrayList<File>();
		final String patternString = f.getPath().replace(File.separatorChar, '/');
		if (!RegexUtil.isPattern(patternString)) {
			if (f.exists() && acceptor.test(f)) {
				result.add(FileUtil.mkCanonical(f));
			}
			return result;
		}

		final Pattern pat = RegexUtil.mkRegexPatternFromWildcardPattern(patternString, '/');
		final Pair<String, Boolean> nonPatternPrefixAndEndsBeforeLast = mkNonPatternPrefix(
				patternString, "/");
		final boolean isRecursive = nonPatternPrefixAndEndsBeforeLast.m_Second
				|| RegexUtil.patternHasDoubleStar(patternString);
		fillInMatchingChildren(result, new File(nonPatternPrefixAndEndsBeforeLast.m_First),
				isRecursive, pat, acceptor);

		// Use a well-defined order.
		Collections.sort(result);

		return result;
	}

	private static Pair<String, Boolean> mkNonPatternPrefix(final String candidate,
			final String sep) {
		final String[] parts = candidate.split(Pattern.quote(sep));
		final StringBuilder sb = new StringBuilder();

		int idx = 0;
		for (final String p : parts) {
			if (RegexUtil.isPattern(p)) {
				return Pair.make(sb.toString(), idx < parts.length - 1);
			}
			if (idx > 0) {
				sb.append(sep);
			}
			sb.append(p);
			++idx;
		}

		return Pair.make(sb.toString(), false);
	}

	private static void fillInMatchingChildren(final List<File> accu, final File dir,
			final boolean recurIntoSubdirectories, final Pattern pat,
			final Predicate<File> acceptor) {
		final File[] children = dir.listFiles();
		if (children == null) {
			return;
		}
		for (final File f : children) {
			// Pattern is defined with a slash separator character.
			if (pat.matcher(f.getPath().replace('\\', '/')).matches() && acceptor.test(f)) {
				accu.add(FileUtil.mkCanonical(f));
			}
			if (recurIntoSubdirectories && f.isDirectory()) {
				fillInMatchingChildren(accu, f, recurIntoSubdirectories, pat, acceptor);
			}
		}
	}

	public static String mkRelativeString(final File absoluteReferencingFile,
			final File absoluteFileToBeAdapted) {
		return mkRelative(absoluteReferencingFile, absoluteFileToBeAdapted).getPath().replace('\\',
				'/');
	}

	/**
	 * Compute a relative variant of an absolute file name.
	 * 
	 * If there is no relative variant (e.g., when the file to be adapted is
	 * located on another Windows volume than the reference directory), the
	 * absolute input file itself is returned
	 * 
	 * @param absoluteReferencingFile
	 *            the file relative to the directory of which the path is to be
	 *            computed
	 * @param absoluteFileToBeAdapted
	 *            the absolute file for which a relative variant is to be
	 *            computed
	 * @return the relative filename, if possible, otherwise the absolute one
	 */
	public static File mkRelative(File absoluteReferencingFile, File absoluteFileToBeAdapted) {

		assert absoluteReferencingFile.isAbsolute();
		assert !absoluteReferencingFile.isDirectory();
		assert absoluteFileToBeAdapted.isAbsolute() : "File is not absolute: "
				+ absoluteFileToBeAdapted;

		// Make both input files canonical, but be lenient about problems.
		File absoluteReferencingDir = absoluteReferencingFile.getParentFile();
		try {
			absoluteReferencingDir = absoluteReferencingDir.getCanonicalFile();
		} catch (final IOException ex) {
			LOG.log(Level.WARNING, "Could not get canonical file of " + absoluteReferencingDir, ex);
		}
		try {
			absoluteFileToBeAdapted = absoluteFileToBeAdapted.getCanonicalFile();
		} catch (final IOException ex) {
			LOG.log(Level.WARNING, "Could not get canonical file of " + absoluteFileToBeAdapted,
					ex);
		}

		// Compute all the parents of both files. Check for the common prefix in
		// both. If there is none, just return the the input. If there is a
		// common prefix, climb up from the reference dir up to the common
		// prefix, then use the rest of the file to be adapted.
		final List<File> reference_selfAndParents = new ArrayList<File>();
		final List<File> toBeAdapted_selfAndParents = new ArrayList<File>();
		File tmp = absoluteReferencingDir;
		while (tmp != null) {
			reference_selfAndParents.add(tmp);
			tmp = tmp.getParentFile();
		}
		tmp = absoluteFileToBeAdapted;
		while (tmp != null) {
			toBeAdapted_selfAndParents.add(tmp);
			tmp = tmp.getParentFile();
		}

		// We want higher parents at the beginning of the lists: reverse them.
		Collections.reverse(reference_selfAndParents);
		Collections.reverse(toBeAdapted_selfAndParents);

		// Compute length of common ancestor prefix.
		int pfix = 0;
		while (pfix < reference_selfAndParents.size() && pfix < toBeAdapted_selfAndParents.size()
				&& reference_selfAndParents.get(pfix)
						.equals(toBeAdapted_selfAndParents.get(pfix))) {
			++pfix;
		}

		if (pfix == 0) {
			// No common prefix found: We cannot create a relative path from the
			// reference directory to the file to be adapted.
			return absoluteFileToBeAdapted;
		}

		// How many directories must we climb up in order to reach the common
		// prefix?
		final int climbUpCount = reference_selfAndParents.size() - pfix;

		// Determine the part of the absolute file name of the file to be
		// adapted behind the common prefix.
		final int toBeCutAway = toBeAdapted_selfAndParents.get(pfix - 1).getPath().length();
		String relativePathBeneathPrefix = absoluteFileToBeAdapted.getPath().substring(toBeCutAway)
				.replace('\\', '/');
		// What has been cut aways normally (though not necessarily) leaves the
		// relative path starting with a slash; we remove this. Note that when
		// only something like "/" or "C:\\" is the common prefix, the relative
		// path does *not* start with a slash.
		if (relativePathBeneathPrefix.startsWith("/")) {
			relativePathBeneathPrefix = relativePathBeneathPrefix.substring(1);
		}

		// Compute result.
		final StringBuilder sb = new StringBuilder();
		for (int i = 0; i < climbUpCount; ++i) {
			sb.append("../");
		}
		sb.append(relativePathBeneathPrefix);
		if (sb.length() == 0) {
			sb.append(".");
		}
		return new File(sb.toString());
	}

	public static String mkSourceContent(final URL resourceIdentifier, final Charset cs,
			final String dflt) {
		try {
			return mkSourceContent(resourceIdentifier, cs);
		} catch (final IOException ex) {
			return dflt;
		}
	}

	public static String mkSourceContent(final URL resourceIdentifier, final Charset cs)
			throws IOException {
		final InputStream is = resourceIdentifier.openStream();
		try {
			return mkTextFromStream(is, cs);
		} finally {
			is.close();
		}
	}

	private static String mkTextFromStream(final InputStream is, final Charset cs)
			throws IOException {
		final InputStreamReader isr = new InputStreamReader(is, cs);
		final StringBuilder sb = new StringBuilder();

		final BufferedReader br = new BufferedReader(isr);
		try {
			String line;
			while (null != (line = br.readLine())) {
				sb.append(line);
				sb.append('\n');
			}
		} finally {
			br.close();
		}

		return sb.toString();
	}

	public static String mkName(final String s) {
		final int idx = s.replace('\\', '/').lastIndexOf('/');
		if (idx == -1) {
			return s;
		}
		return s.substring(idx + 1);
	}

	public static File findEmptyOrCreateNewDirectory(final File parentDir, final String dirNamePfix)
			throws IOException {
		assert parentDir.isDirectory();
		final File[] content = parentDir.listFiles();
		if (content == null) {
			throw new IOException("Could not read content of " + parentDir);
		}

		final List<String> foundSuffixes = new ArrayList<String>();
		for (final File f : content) {
			if (f.getName().startsWith(dirNamePfix)) {
				if (isEmptyDirectory(f)) {
					return f;
				}
				foundSuffixes.add(f.getName().substring(dirNamePfix.length()));
			}
		}
		int i = 0;
		while (true) {
			if (!foundSuffixes.contains(Integer.toString(i))) {
				final File newDir = new File(parentDir, dirNamePfix + i);
				mkDirs(newDir);
				return newDir;
			}
			++i;
		}
	}

	public static boolean isEmptyDirectory(final File f) {
		if (!f.isDirectory())
			return false;

		final File[] content = f.listFiles();
		if (content == null)
			return false;

		for (final File c : content) {
			if (!c.getName().equals(".") && !c.getName().equals("..")) {
				return false;
			}
		}

		return true;
	}

	public static boolean deleteRecursively(final File f) {
		if (!f.exists()) {
			return true;
		}
		if (f.isDirectory()) {
			final File[] content = f.listFiles();
			if (content == null)
				return false;

			for (final File f1 : content) {
				if (!deleteRecursively(f1)) {
					return false;
				}
			}
		}

		if (f.delete()) {
			return true;
		}

		// if deletion fails then try it once again
		// on windows (at least XP) sometimes it needs a second try if the file
		// was blocked
		// but the blocking application has finished meanwhile
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			LOG.log(Level.WARNING, "Unexpected interrupted", e);
		}
		LOG.log(Level.INFO, "Second attempt to delete file " + f.getAbsolutePath());
		final boolean result = f.delete();
		if (!result) {
			LOG.log(Level.WARNING, "Giving up deleting file " + f.getAbsolutePath());
		}

		return result;
	}

	/**
	 * Note that this normalizes line endings to "\n", and adds one to a last
	 * line that might not have one.
	 */
	public static String mkString(final Path path, final Charset encoding) throws IOException {
		final StringBuilder sb = new StringBuilder();
		try (

				final Stream<String> lines = Files.lines(path, encoding)

		) {
			lines.forEach(l -> sb.append(l + "\n"));
		}
		return sb.toString();
	}

	public static String mkString(final File f, final Charset encoding)
			throws UnsupportedEncodingException, IOException {
		try (

				final FileInputStream fis = new FileInputStream(f)

		) {
			return mkString(fis, encoding);
		}
	}

	public static String mkString(final InputStream is, final Charset encoding) throws IOException {
		final StringBuilder sb = new StringBuilder();
		final InputStreamReader rdr = new InputStreamReader(new BufferedInputStream(is), encoding);
		int ch;
		while (-1 != (ch = rdr.read())) {
			sb.append((char) ch);
		}
		return sb.toString();
	}

	public static List<File> findExecutablesAlongPath(final List<String> execNames) {

		// Avoid duplicates.
		final LinkedHashSet<File> searchPath = new LinkedHashSet<File>();
		{
			final List<String> candidates = new ArrayList<String>();
			{
				// Path from environment.
				final String pathString = System.getenv("PATH");
				if (pathString != null) {
					candidates.addAll(Arrays.asList(pathString.split(File.pathSeparator)));
				}
				// Extra standard directories.
				candidates.addAll(Arrays.asList("/usr/bin", "/usr/bin/X11", "/usr/X11/bin", "/bin",
						"/bin/X11", "/X11/bin",
						System.getProperty("user.home") + File.separatorChar + "bin"));

				// /opt/* and /opt/*/bin
				final File[] optsContent = new File("/opt").listFiles();
				if (optsContent != null) {
					for (final File f : optsContent) {
						candidates.add(f.getPath());
						candidates.add(new File(f, "bin").getPath());
					}
				}
			}

			for (final String pathElement : candidates) {
				final File f = new File(pathElement);
				if (f.isDirectory() && f.isAbsolute()) {
					try {
						searchPath.add(f.getCanonicalFile());
					} catch (final IOException ex) {
						LOG.log(Level.WARNING, "Could not determine canonical form of " + f, ex);
					}
				}
			}
		}

		// Remove duplicates.
		final LinkedHashSet<File> result = new LinkedHashSet<File>();
		for (final File f : searchPath) {
			for (final String execName : execNames) {
				final File e = new File(f, execName);
				if (e.isFile() && e.canExecute()) {
					try {
						result.add(e.getCanonicalFile());
					} catch (final IOException ex) {
						LOG.log(Level.WARNING, "Could not determine canonical form of " + e, ex);
					}
				}
			}
		}

		return new ArrayList<File>(result);
	}

	public static void processFilesOrDirectoriesRecursivelyBeneathRootDirs(
			final Collection<File> rootDirs, final Consumer<File> rootDirProcessorOrNull,
			final Consumer<File> fileOrDirectoryProcessor, final FileFilter fileFilterOrNull,
			final ICancelListener cancelListenerOrNull, final boolean processJustFiles) {
		final List<File> normalizedRootDirs = normalize(rootDirs);

		int numberOfVisitedDirectoriesOrFiles = 0;
		for (final File rootDir : normalizedRootDirs) {
			if (rootDirProcessorOrNull != null) {
				rootDirProcessorOrNull.accept(rootDir);
			}
			final List<File> workList = new ArrayList<File>();
			workList.add(rootDir);

			long lastOutputTime = 0;
			while (!workList.isEmpty()) {
				// Use last element; new ones are added at end, leading to
				// depth-first search.
				final File currentItem = workList.remove(workList.size() - 1);
				numberOfVisitedDirectoriesOrFiles++;
				if (cancelListenerOrNull != null) {
					final long curTime = System.currentTimeMillis();
					if (curTime > lastOutputTime + 200) {
						lastOutputTime = curTime;
						cancelListenerOrNull.throwExceptionIfCancelled(null);
						cancelListenerOrNull.showProgressMessage("Checked "
								+ numberOfVisitedDirectoriesOrFiles
								+ " directories or files. Current: " + currentItem.getName());
					}
				}

				if (!processJustFiles || currentItem.isFile()) {
					fileOrDirectoryProcessor.accept(currentItem);
				}

				if (!currentItem.isDirectory()) {
					continue;
				}

				final File[] content = fileFilterOrNull == null ? currentItem.listFiles()
						: currentItem.listFiles(fileFilterOrNull);
				if (content != null) {
					// Sort alphabetically.
					// Please see notice at isBetterRepresentantOfDuplicateGroup
					// of class RootPathUtil if this will be changed
					Arrays.sort(content, new Comparator<File>() {
						@Override
						public int compare(final File o1, final File o2) {
							return o1.getPath().compareTo(o2.getPath());
						}
					});

					/*
					 * Depth first search: add element at end, where we pick up
					 * the next element to be processed. But see to it that
					 * alphabetically smaller elements will be located behind
					 * alphabetically larger ones, so that the next one being
					 * processed (the one at the very end) is the next one
					 * alphabetically.
					 */
					final int insertionPositionForWorkList = workList.size();
					for (final File f : content) {
						// Directories are searched recursively.
						if (f.isDirectory()) {
							workList.add(insertionPositionForWorkList, f);
						} else {
							fileOrDirectoryProcessor.accept(f);
						}
					}
				}
			}
		}
	}

	public static List<File> normalize(final Collection<File> rootPaths) {
		// Order canonical paths alphabetically.
		final TreeSet<String> canonicalPaths = new TreeSet<String>();
		for (final File rootDir : rootPaths) {
			assert rootDir.isAbsolute();

			// Use a final slash so that a string prefix always represents an
			// ancestor directory (otherwise dir '/123' would wrongly be
			// considered to be an ancestor of '/1234').
			String canonicalPath = FileUtil.mkCanonical(rootDir).getPath().replace('\\', '/');
			if (!canonicalPath.endsWith("/")) {
				canonicalPath = canonicalPath + "/";
			}
			canonicalPaths.add(canonicalPath);
		}

		// Drop all root directories for which another root directory is a
		// prefix. Note that a prefix of a path will be earlier in the list than
		// the element itself.
		final List<File> workList = new ArrayList<File>();
		String lastUsedDir = null;
		for (final String absPath : canonicalPaths) {
			final File absPathFile = new File(absPath);
			final boolean isFile = absPathFile.isFile();
			if (lastUsedDir == null || isFile || !absPath.startsWith(lastUsedDir)) {
				// First, or a file (not a directory), or lastUsedDir not a
				// prefix: Use this
				// in the work list.
				workList.add(absPathFile);
				if (!isFile) {
					lastUsedDir = absPath;
				}
			}
		}

		return workList;
	}

	public static File mkTempDirectory(final File dir, final String prefix) throws IOException {
		mkDirs(dir);
		final Path dirPath = Paths.get(dir.getAbsolutePath());
		final Path tmpDir = Files.createTempDirectory(dirPath, prefix);
		return tmpDir.toFile();
	}

	public static void mkDirs(final File d) throws IOException {
		if (d.isDirectory()) {
			return;
		}
		if (d.mkdirs()) {
			return;
		}
		// if creation fails then try it once again
		// on Windows sometimes it needs a second try if the directory
		// was blocked but the blocking application has finished meanwhile
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			LOG.log(Level.WARNING, "Unexpected interrupted", e);
		}
		LOG.log(Level.INFO, "Second attempt to create dir " + d.getAbsolutePath());

		if (!d.mkdirs()) {
			LOG.log(Level.WARNING, "Giving up creating directory " + d.getAbsolutePath());
			throw new IOException("Unable to create directory '" + d + "'");
		}
	}

	public static boolean thereIsAFileWithNameEndingInBeneath(final File f,
			final String fileNameEnding) {
		if (f.isFile() && f.getName().endsWith(fileNameEnding)) {
			return true;
		}
		if (!f.isDirectory()) {
			return false;
		}
		final File[] content = f.listFiles();
		if (content == null) {
			return false;
		}
		for (final File c : content) {
			if (thereIsAFileWithNameEndingInBeneath(c, fileNameEnding)) {
				return true;
			}
		}
		return false;
	}

	public static void collectDirectChildrenPuttingSiblingsInAlphabeticalOrder(final File base,
			final Predicate<File> pred, final List<File> accu) {
		final File[] content = base.listFiles();
		if (content != null) {
			// Sort by simple file name.
			Arrays.sort(content, new Comparator<File>() {
				@Override
				public int compare(final File o1, final File o2) {
					return o1.getName().compareTo(o2.getName());
				}
			});

			for (final File c : content) {
				if (pred.test(c)) {
					accu.add(c);
				}
			}
		}
	}

	public static void collectRecursivelyPuttingSiblingsInAlphabeticalOrder(final File base,
			final Predicate<File> pred, final Collection<File> accu) {
		final Set<File> seen = SetUtil.makeHashSet();
		final List<File> work = new LinkedList<File>();
		work.add(base);
		while (!work.isEmpty()) {
			final File current = work.remove(0);
			if (!seen.add(FileUtil.mkCanonical(current))) {
				// Already seen.
				continue;
			}

			if (pred.test(current)) {
				accu.add(current);
			}

			// We enter the directory even if predicate did not return true.
			if (current.isDirectory()) {
				final File[] content = current.listFiles();
				if (content != null) {
					// Sort by simple file name.
					Arrays.sort(content, new Comparator<File>() {
						@Override
						public int compare(final File o1, final File o2) {
							return o1.getName().compareTo(o2.getName());
						}
					});
					// Put in front of work list - we go depth first.
					int i = 0;
					for (final File c : content) {
						work.add(i++, c);
					}
				}
			}
		}
	}

	public static void moveFile(final File src, final File tgt) throws IOException {
		/*
		 * Deletion needed: moving does not work with an existing non-empty
		 * target directory.
		 */
		if (!FileUtil.deleteRecursively(tgt)) {
			throw new IOException("Failed to delete '" + tgt + "'");
		}

		final Path srcPath = Paths.get(src.getAbsolutePath());
		final Path tgtPath = Paths.get(tgt.getAbsolutePath());

		try {
			Files.move(srcPath, tgtPath, StandardCopyOption.REPLACE_EXISTING);
		} catch (final IOException e) {
			// if move fails then try it once again
			// on windows sometimes it needs a second try if the
			// file was blocked but the blocking application has finished
			// meanwhile

			LOG.log(Level.INFO, "Failed to move " + src.getAbsolutePath() + " to "
					+ tgt.getAbsolutePath() + ". Start second atempt.", e);

			try {
				Thread.sleep(2000);
			} catch (InterruptedException e1) {
				LOG.log(Level.WARNING, "Unexpected interrupted", e1);
			}

			// first try to move again
			try {
				Files.move(srcPath, tgtPath, StandardCopyOption.REPLACE_EXISTING);
			} catch (final IOException e2) {
				LOG.log(Level.INFO, "Second atempt failed, now trying to copy", e2);
				// if this fails (and this happens often on Windows), try to
				// copy
				FileUtil.copyRecursively(src, tgt, null, true);

				// if copying was successful, delete the source directory
				FileUtil.deleteRecursively(src);
			}
		}
	}

	/**
	 * Delete empty directories beneath the root directory recursively;
	 * optionally, keep or also delete the root dir itself if it is empty when
	 * all contained empty directories have been deleted.
	 * 
	 * @param rootDir
	 * @param deleteAlsoRootDir
	 */
	public static void deleteEmptyDirectoriesRecursively(final File rootDir,
			final boolean deleteAlsoRootDir) {
		if (!rootDir.isDirectory()) {
			return;
		}
		final List<File> stack = new ArrayList<File>();
		stack.add(rootDir);

		// Collect all directories recursively.
		for (int i = 0; i < stack.size(); ++i) {
			final File dir = stack.get(i);
			final File[] content = dir.listFiles();
			if (content != null) {
				for (final File f : content) {
					if (f.isDirectory()) {
						stack.add(f);
					}
				}
			}
		}

		// Clean up, starting at end.
		for (int i = stack.size() - 1; i >= 0; --i) {
			final File dir = stack.get(i);
			if (!deleteAlsoRootDir && dir.equals(rootDir)) {
				// Do not delete the root directory.
				continue;
			}
			final File[] content = dir.listFiles();
			if (content != null && content.length == 0) {
				deleteRecursively(dir);
			}
		}
	}

	public static boolean isRecursivelyBeneathOrEquals(File f, final File dir) {
		while (f != null) {
			if (f.equals(dir)) {
				return true;
			}
			f = f.getParentFile();
		}
		return false;
	}

	public static File mkNewFileName(final File dir, final String pfix) {
		File candidate = new File(dir, pfix);
		int i = 0;
		while (candidate.exists()) {
			candidate = new File(dir, pfix + i);
			++i;
		}
		return candidate;
	}

	public static List<List<File>> groupDuplicates(final Collection<File> baseCollection,
			final Predicate<File> isRelevantPredOrNull, final boolean recursively) {

		final List<List<File>> result = new ArrayList<>();

		/*
		 * Elements in the following list correspond to those in the list above,
		 * i.e., the equivalence check information for the correspnding
		 * equivalence class is either null, or has been filled from a previous
		 * equivalence check.
		 */
		final List<Map<String, File>> eqCheckInfo = new ArrayList<>();

		for (final File f : baseCollection) {
			// There should be no isRelevantPred for files.
			assert !f.isFile() || isRelevantPredOrNull == null;

			// There must be an isRelevantPred for directories.
			assert !f.isDirectory() || isRelevantPredOrNull != null;

			boolean done = false;

			@SuppressWarnings("unchecked")
			final Map<String, File>[] cacheForCandidatesEqCheckInfo = new Map[1];

			int i = -1;
			for (final List<File> eqClass : result) {
				++i;

				// Equivalent classes are never empty.
				assert !eqClass.isEmpty();

				/*
				 * Can just compare with first element of equivalence class -
				 * all are equivalent.
				 */
				final File eqClassRepresentant = eqClass.get(0);

				if (f.isFile()) {
					if (eqClassRepresentant.isFile()
							&& areFilesEquivalent(f, eqClassRepresentant)) {
						// Same names and contents: same equivalence class.
						eqClass.add(f);
						done = true;
						break;
					}
				} else if (f.isDirectory()) {
					if (eqClassRepresentant.isDirectory()) {
						final Map<String, File> eqCheckInfoOfEqClass = eqCheckInfo.get(i);

						// For a directory, the info must have been computed.
						assert eqCheckInfoOfEqClass != null;

						if (areDirsEquivalent(f, eqClassRepresentant, eqCheckInfoOfEqClass,
								isRelevantPredOrNull, recursively, cacheForCandidatesEqCheckInfo)) {
							// same equivalence class.
							eqClass.add(f);
							done = true;
							break;
						}
					}
				} else {
					// Neither file nor dir: no equivalence.
					break;
				}
			}

			if (!done) {
				final List<File> newEqClass = new ArrayList<>(1);
				newEqClass.add(f);

				result.add(newEqClass);

				Map<String, File> cachedEqCheckInfoForCandidate = cacheForCandidatesEqCheckInfo[0];
				if (cachedEqCheckInfoForCandidate == null && f.isDirectory()) {
					// Cache not yet filled.
					cachedEqCheckInfoForCandidate = new HashMap<String, File>();
					collectRelevantFiles(f, isRelevantPredOrNull, recursively,
							cachedEqCheckInfoForCandidate);
				}
				// Note: For non-directories, this inserts a null value.
				eqCheckInfo.add(cachedEqCheckInfoForCandidate);
			}
		}

		return result;
	}

	private static boolean areDirsEquivalent(final File candidateDir,
			final File eqClassRepresentant, final Map<String, File> eqCheckInfoOfEqClass,
			final Predicate<File> isRelevantPred, final boolean recursively,
			final Map<String, File>[] accuForCandidatesEqCheckInfo) {
		assert candidateDir.isDirectory();
		assert eqClassRepresentant.isDirectory();

		/*
		 * Two directories are equivalent if their content is equivalent. For
		 * non-recursive cases, for the relevant files contained in them there
		 * must be equivalent versions in the other directory. For the recursive
		 * case, all the relevant files recursively contained must habe
		 * equivalent counterparts with the same relative names beneath the
		 * directories.
		 */

		/*
		 * Check if the equivalence check info has already been computed for the
		 * candidate.
		 */
		Map<String, File> relativePathToRelevantFileForCandidate = accuForCandidatesEqCheckInfo[0];
		if (relativePathToRelevantFileForCandidate == null) {
			relativePathToRelevantFileForCandidate = new HashMap<>();
			collectRelevantFiles(candidateDir, isRelevantPred, recursively,
					relativePathToRelevantFileForCandidate);
			accuForCandidatesEqCheckInfo[0] = relativePathToRelevantFileForCandidate;
		}

		// Check that the relative path sets are equal.
		if (!SetUtil.equals(relativePathToRelevantFileForCandidate.keySet(),
				eqCheckInfoOfEqClass.keySet())) {
			return false;
		}

		for (final Map.Entry<String, File> e : relativePathToRelevantFileForCandidate.entrySet()) {
			final File c1 = e.getValue();
			assert c1.isFile();

			final File c2 = eqCheckInfoOfEqClass.get(e.getKey());
			assert c2 != null;
			assert c2.isFile();

			if (!areFilesEquivalent(c1, c2)) {
				// Files not equivalent.
				return false;
			}
		}

		// Everything equivalent.
		return true;
	}

	public static void collectRelevantFiles(File rootDir, Predicate<File> isRelevantPred,
			boolean recursively, Map<String, File> relativePathToRelevantFileAccu) {
		collectRelevantFiles(rootDir, isRelevantPred, recursively, relativePathToRelevantFileAccu,
				"", new HashSet<File>());
	}

	private static void collectRelevantFiles(final File dir, final Predicate<File> isRelevantPred,
			final boolean recursively, final Map<String, File> relativePathToRelevantFileAccu,
			final String pfix, final Set<File> seen) {
		assert dir.isDirectory();

		final String[] contentOrNull = dir.list();
		if (contentOrNull == null) {
			return;
		}
		for (final String contained : contentOrNull) {
			// Symlinks etc. can lead to loops in the directory hierarchy.
			final File containedFile = FileUtil.mkCanonical(new File(dir, contained));
			if (seen.add(containedFile)) {
				if (recursively && containedFile.isDirectory()) {
					collectRelevantFiles(containedFile, isRelevantPred, true,
							relativePathToRelevantFileAccu,
							(pfix.isEmpty() ? "" : pfix + "/") + contained, seen);
				} else if (containedFile.isFile() && isRelevantPred.test(containedFile)) {
					relativePathToRelevantFileAccu
							.put((pfix.isEmpty() ? "" : pfix + "/") + contained, containedFile);
				}
			}
		}
	}

	private static boolean areFilesEquivalent(final File f1, final File f2) {
		try {
			return f1.getName().equals(f2.getName()) && haveSameContent(f1, f2);
		} catch (final Throwable t) {
			LOG.log(Level.WARNING,
					"Exception while checking if files are equal '" + f1 + "' and '" + f2 + "'.",
					t);
			return false;
		}
	}

	public static boolean haveSameContent(final File f1, final File f2) throws IOException {
		assert f1.isFile();
		assert f2.isFile();

		if (f1.length() != f2.length()) {
			return false;
		}

		try (

				final BufferedInputStream b1 = new BufferedInputStream(new FileInputStream(f1));
				final BufferedInputStream b2 = new BufferedInputStream(new FileInputStream(f2));

		) {
			while (true) {
				final int ch1 = b1.read();
				final int ch2 = b2.read();

				if (ch1 != ch2) {
					return false;
				}

				if (ch1 == -1) {
					return true;
				}
			}
		}
	}

	public static void collectRelativePathMatches(final File baseDir,
			final IPersistibleFileMatcher allRelativePathMatcher,
			final IPersistibleFileMatcher workspaceRelativePathMatcher,
			final Consumer<String> callback, final List<String> libraryAccuOrNull,
			final ICancelListener cancelListener) {
		// Avoid infinite loop via symbolic links.
		final Set<String> canonicalDirsSeen = new HashSet<>();
		if (baseDir.isDirectory()) {
			/*
			 * The prefix length to be cut off removes also the directory
			 * separator.
			 */
			collectMatches(baseDir.getPath().length() + 1, baseDir, allRelativePathMatcher,
					workspaceRelativePathMatcher, canonicalDirsSeen, callback, libraryAccuOrNull,
					cancelListener);
		}
	}

	/**
	 * Process children of the current directory.
	 */
	private static void collectMatches(final int baseLen, final File curDir,
			final IPersistibleFileMatcher relativePathMatcher,
			final IPersistibleFileMatcher workspacePathMatcher, final Set<String> canonicalDirsSeen,
			final Consumer<String> callback, final List<String> libraryAccuOrNull,
			final ICancelListener cancelListener) {
		final String curDirCanonical;
		try {
			curDirCanonical = curDir.getCanonicalPath();
		} catch (final IOException ex) {
			LOG.log(Level.WARNING, "Unable to determine canonical path of '" + curDir + "'", ex);
			return;
		}
		if (!canonicalDirsSeen.add(curDirCanonical)) {
			// Already processed.
			return;
		}

		/*
		 * If the library files are not to be collected and this directory and
		 * all beneath it is library, we need not go on.
		 */
		{
			final var relativeDirPath = '/'
					+ (curDir.getPath().replace('\\', '/') + '/').substring(baseLen);
			if (null == libraryAccuOrNull
					&& workspacePathMatcher.canSkipEverythingInDir(relativeDirPath)) {
				return;
			}
		}

		for (final var child : curDir.listFiles()) {
			cancelListener.throwExceptionIfCancelled("While collecting JavaScript workspace files");
			final var childIsDir = child.isDirectory();
			/*
			 * Use '/' as dir separator also under windows, and append '/' to
			 * directories.
			 */
			final var relative = child.getPath().substring(baseLen).replace('\\', '/');
			final var relativeWithPrefixAndSuffix = '/' + relative + (childIsDir ? "/" : "");
			/*
			 * The prefix allows to use double-star-slash at the start of
			 * patterns to match also the base directory.
			 */
			if (relativePathMatcher.test(relativeWithPrefixAndSuffix)) {
				if (workspacePathMatcher.test(relativeWithPrefixAndSuffix)) {
					callback.accept(relative);
				} else if (null != libraryAccuOrNull) {
					libraryAccuOrNull.add(relative);
				}
			}
			if (childIsDir
					&& !relativePathMatcher.canSkipEverythingInDir(relativeWithPrefixAndSuffix)) {
				collectMatches(baseLen, child, relativePathMatcher, workspacePathMatcher,
						canonicalDirsSeen, callback, libraryAccuOrNull, cancelListener);
			}
		}
	}

	public static void copyDirContentRecursively(final File srcDir, final File tgtDir,
			final boolean deleteExistingTgtDir) throws IOException {
		if (deleteExistingTgtDir && tgtDir.exists()) {
			deleteRecursively(tgtDir);
			tgtDir.mkdirs();
		}
		for (final var content : srcDir.list()) {
			copyRecursively(new File(srcDir, content), new File(tgtDir, content),
					null /* filterForFileNamesToSkipOrNull */,
					false /* deleteExistingTargetDirectories */);
		}
	}
}
