/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 * Created on 07.11.2012
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.util.List;
import java.util.logging.Logger;

import com.rigsit.xanitizer.pub.util.exceptions.TimeOutException;
import com.rigsit.xanitizer.pub.util.exceptions.UserCancelledException;

/**
 * @author nwe
 */
public interface ICancelListener {
	/**
	 * Check if cancellation has been requested.
	 *
	 * Typically, implementations should be synchronized so that the cancel
	 * listener can be used from different threads.
	 *
	 * @return something != null if cancellation has been requested; this is the
	 *         reason for cancellation.
	 */
	String getReasonIfCancelledOrNull();

	default boolean wasCancelled() {
		return null != getReasonIfCancelledOrNull();
	}

	default void throwExceptionIfCancelled(final String pfix) {
		throwExceptionIfCancelled(pfix, true);
	}

	default void throwExceptionIfCancelled(final String pfixOrNull, final boolean showReason) {
		final String reasonOrNull = getReasonIfCancelledOrNull();
		if (reasonOrNull != null) {
			throwException(pfixOrNull, reasonOrNull, showReason);
		}
	}

	default void throwException(final String pfixOrNull, final String reason,
			final boolean showReason) {
		assert (!showReason ? pfixOrNull != null : true);

		// Construct a message for the exception.
		final StringBuilder msg = new StringBuilder();
		if (pfixOrNull != null) {
			msg.append(pfixOrNull);
			if (showReason) {
				msg.append(": ");
			}
		}
		if (showReason) {
			msg.append(reason);
		}

		// This might have been a time-out, or an explicit user cancellation.
		if (gotTimeOut()) {
			throw new TimeOutException(msg.toString());
		}
		throw new UserCancelledException(msg.toString());
	}

	/**
	 * Info-level logging output by default.
	 */
	default void showProgressMessage(final String message) {
		final Logger log = Logger.getLogger(ICancelListener.class.getName());
		log.info("[ICancelListener.showProgressMessage] " + message);
	}

	// Get the current progress message.
	String getProgressMessageOrNull();

	/**
	 * No output by default.
	 */
	default void setProgressTitle(@SuppressWarnings("unused") String title) {
	}

	/**
	 * No timeout by default.
	 */
	default boolean gotTimeOut() {
		return false;
	}

	/**
	 * Set up the multi cancel listener functionality.
	 */
	default void setParallelExecutor(
			@SuppressWarnings("unused") IParallelExecutor parallelExecutor) {
	}

	/**
	 * This allows to display the currently running jobs.
	 */
	default List<JobInfo> getCopyOfCurrentlyRunningJobsOrNull() {
		return null;
	}

	/**
	 * This allows to cancel one runnable.
	 */
	default boolean requestCancellationOfOneRunnable(
			@SuppressWarnings("unused") Runnable toBeCancelled) {
		return false;
	}

	/*
	 * Register a callback to be called whenever the running map changes.
	 */
	default void registerRunningMapHasChangedCallback(
			@SuppressWarnings("unused") Runnable callback) {
	}

	/*
	 * De-register a callback that was to be called whenever the running map
	 * changed.
	 */
	default void deregisterRunningMapHasChangedCallback(
			@SuppressWarnings("unused") Runnable callback) {
	}
}
