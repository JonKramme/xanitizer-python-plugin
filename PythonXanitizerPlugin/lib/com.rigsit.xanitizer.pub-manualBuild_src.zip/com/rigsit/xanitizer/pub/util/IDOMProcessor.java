/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Oct 25, 2012
 *
 */
package com.rigsit.xanitizer.pub.util;

import org.w3c.dom.Document;

/**
 * A DOM processor is returned by the framework plugin if it is interested in
 * analyzing XML files. The environment invokes the DOM processor for all XML
 * files found in the work space.
 *
 * This is meant to be implemented by the simulation code.
 */
public interface IDOMProcessor {
	/**
	 * Process a given XML file.
	 * 
	 * @param doc
	 *            Document structure of any XML files in the workspace.
	 *            Currently these are files with extension *.xml or *.wsdd
	 * @param fileName
	 *            full name including path
	 * @param content
	 *            content of the given file as byte array
	 */
	void process(Document doc, String fileName, byte[] content);
}
