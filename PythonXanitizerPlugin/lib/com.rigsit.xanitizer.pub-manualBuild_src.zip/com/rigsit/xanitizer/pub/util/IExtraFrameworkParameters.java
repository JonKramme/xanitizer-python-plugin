/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Dec 2, 2016
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.util.function.Predicate;

/**
 * An object that allows to access extra parameters for framework plugins.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface IExtraFrameworkParameters {

	/**
	 * Accepts fully qualified class names of classes for which the framework
	 * should work.
	 * 
	 * @return acceptor for class names
	 */
	Predicate<String> mkClassNameAcceptor();

	/**
	 * ID of taint source kind to use for setters, if any.
	 * 
	 * @return null, or the source kind to be used for setters
	 */
	String getSourceKindIDForSettersOrNull();

	/**
	 * ID of taint source kind to use for constructor arguments, if any.
	 * 
	 * @return null, or the source kind to be used for constructor arguments
	 */
	String getSourceKindIDForConstructorArgumentsOrNull();

}
