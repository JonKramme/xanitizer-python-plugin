/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 11, 2016
 *
 */
package com.rigsit.xanitizer.pub.util;

/**
 * An object that allows to register issues of specific categories.
 *
 * Meant to be implemented by the simulation code.
 */
public interface IIssueCategory {

	public enum Severity {
		INFO, WARNING, ERROR,
	}

	public enum IssueCategoryGroup {
		WORKSPACE_ISSUES("Workspace Issues", "Workspace"),

		CALL_GRAPH_ISSUES("Call Graph Issues", "Call Graph"),

		ANALYSIS_ISSUES("Analysis Issues", "Analysis"),

		MIGRATION_ISSUES("Migration Issues", "Migration");
		
		

		private final String m_PresentationName;
		private final String m_Group;

		private IssueCategoryGroup(final String presentationName, final String group) {
			m_PresentationName = presentationName;
			m_Group = group;
		}

		public String getPresentationName() {
			return m_PresentationName;
		}

		public String getGroup() {
			return m_Group;
		}
	}

	/**
	 * The presentation name of the issue category
	 * 
	 * @return the presentation name
	 */
	String getPresentationName();

	/**
	 * The description of the issue category
	 * 
	 * @return the description
	 */
	String getDescription();

	/**
	 * The format pattern used to format descriptions for issues contained in
	 * this category
	 * 
	 * @return the format
	 */
	String getFormat();

	/**
	 * Tells if the issues contained in this category are problems or only
	 * informational issues.
	 * 
	 * @return the severity of the issue
	 */
	Severity getSeverity();

	/**
	 * The group that the issue category is assigned to.
	 * 
	 * @return the group
	 */
	IssueCategoryGroup getGroup();

	/**
	 * If for this issue category, there is an 'Info' variant, return this;
	 * otherwise return itself.
	 * 
	 * @return the 'Info' variant of this category, or itself.
	 */
	IIssueCategory mkInfoVariantOrSelf();

}
