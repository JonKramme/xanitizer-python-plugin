/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Mar 12, 2020
 *
 */
package com.rigsit.xanitizer.pub.util;

/**
 * @author rust
 *
 */
public interface IIssueInformation {

	/**
	 * @param string
	 */
	IIssueInformation addChild(String string);

}
