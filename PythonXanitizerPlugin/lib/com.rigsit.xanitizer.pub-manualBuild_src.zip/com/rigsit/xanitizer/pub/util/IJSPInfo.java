/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 29, 2016
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.io.File;
import java.util.Map;

/**
 * JSP information collected in the current project.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface IJSPInfo {

	/**
	 * Map from JSP source file to java FQNs of generated class.
	 * 
	 * @return map from JSP files to Java type names
	 */
	Map<File, String> getJspSourceFileToJavaClassFQNRef();

	/**
	 * Map from JSP source file to JSP resource name as used in the Web server.
	 * 
	 * @return map from JSP files to resource names
	 */
	Map<File, String> getJspSourceFileToJspLocationRef();
}
