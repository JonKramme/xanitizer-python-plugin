/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 14, 2017
 *
 */
package com.rigsit.xanitizer.pub.util;

/**
 * Wrapper for internal object that is used for matching method signatures,
 * containing several IMethodPattern instances.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface IMethodMatcher {

	/**
	 * Add a method pattern to the current method matcher.
	 * 
	 * @param methodPattern
	 *            the method pattern to be added
	 */
	void add(IMethodPattern methodPattern);
}
