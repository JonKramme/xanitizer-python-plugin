/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 22, 2016
 *
 */
package com.rigsit.xanitizer.pub.util;

import com.rigsit.xanitizer.pub.languageelements.IMethodDescriptor;

/**
 * Wrapper for internal object that is used for matching method signatures.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface IMethodPattern {

	/**
	 * This method pattern's Java-style specification.
	 * 
	 * @return the Java-style specification
	 */
	String getJavaSpec();

	/**
	 * The method pattern may only be matched for the given call site.
	 * 
	 * @param callingMethod
	 *            the calling method of the call site
	 * @param byteCodeIdx
	 *            the byte code index of the call site
	 */
	void setFilterCallSite(IMethodDescriptor callingMethod, int byteCodeIdx);
}
