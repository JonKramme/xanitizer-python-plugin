/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.util.List;

public interface IParallelExecutor {
	// This allows to display the currently running jobs.
	List<JobInfo> getCopyOfCurrentlyRunningJobs();

	boolean requestCancellationOfOneRunnable(Runnable toBeInterrupted);

	String getReasonForCurrentThreadCancellationOrNull();

	void registerRunningMapHasChangedCallback(Runnable callback);

	void deregisterRunningMapHasChangedCallback(Runnable callback);

	/**
	 * Returns true if there is a runnable for the current job, so that the
	 * message could be registered.
	 */
	boolean registerProgressMessageForCurrentThread(String message);

}
