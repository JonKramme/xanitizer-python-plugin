/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Aug 16, 2016
 *
 */
package com.rigsit.xanitizer.pub.util;

/**
 * Wraps an internal Xanitizer object that allows to monitor progress.
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IProgressMonitor {

	/**
	 * Throw a cancellation exception if this progress monitor has been
	 * cancelled, e.g., by the user clicking on a "Cancel" button in the GUI.
	 * 
	 * @param hintOrNull
	 *            if not null, a short description of the phase in which the
	 *            activity was cancelled
	 */
	void throwExceptionIfCancelled(String hintOrNull);

}
