/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 18, 2016
 *
 */
package com.rigsit.xanitizer.pub.util;

/**
 * Source line data for a framework-generated finding.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface ISourceLineData {

	String mkPresentationName();
}
