/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 22, 2016
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.util.Collection;
import java.util.function.Function;

/**
 * Wrapper for internal object that are used for matching strings with wild card
 * patterns.
 * 
 * Not meant to be implemented by the simulation code.
 */
public interface IWildcardPatternDefinition {

	/**
	 * The include patterns in this pattern definition.
	 * 
	 * @return include patterns
	 */
	Collection<String> getIncludePatterns();

	/**
	 * The exclude patterns in this pattern definition.
	 * 
	 * @return exclude patterns
	 */
	Collection<String> getExcludePatterns();

	/**
	 * A function that checks if some string matches this pattern definition.
	 * 
	 * @return string acceptor for this definition
	 */
	Function<String, Boolean> mkStringAcceptor();
}
