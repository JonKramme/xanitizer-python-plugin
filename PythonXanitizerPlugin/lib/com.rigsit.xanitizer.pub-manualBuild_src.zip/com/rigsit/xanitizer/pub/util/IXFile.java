/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 4, 2016
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.net.URL;

/**
 * Represents some resource in the file system
 *
 * Not meant to be implemented by the simulation code.
 */
public interface IXFile {

	/**
	 * Tells if this is a ZIP member
	 * 
	 * @return if this is a ZIP memmer
	 */
	boolean isZipMember();

	/**
	 * Returns true if this resource exists
	 * 
	 * @param context The file context of the current project.
	 * 
	 * @return if the resource exists
	 */
	boolean exists(IXFileContext context);

	/**
	 * String to be used in persistence when storing a reference to this IXFile.
	 * 
	 * @return the persistence string of this resource
	 */
	String getPersistenceString();
	
	/**
	 * Formated String representation
	 * @param xFileContext
	 * @return
	 */
	String getPresentationString(IXFileContext xFileContext);

	/**
	 * The relative path of this resource, if it can be computed, relative to
	 * the location of the project's configuration file.
	 * 
	 * @return relative path, or null
	 */
	String getRelativePathOrNull();

	/**
	 * The path variable on which this resource is based, or null if it is not
	 * based on one.
	 * 
	 * @return path variable on which this resource is based, or null
	 */
	String getPathVariableStringOrNull();

	/**
	 * Create an URL corresponding to this resource, if possible.
	 * 
	 * @param context The file context of the current project.
	 * @return this resource's URL, or null
	 */
	URL mkUrlOrNull(IXFileContext context);
}
