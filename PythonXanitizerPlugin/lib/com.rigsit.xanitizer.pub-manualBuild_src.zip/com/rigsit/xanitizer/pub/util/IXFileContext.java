/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Jun 12, 2019
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.io.File;
import java.net.URL;
import java.util.Map;

/**
 * @author rust
 *
 */
public interface IXFileContext {

	File getProjectDirectory();

	File mkEffectiveReferenceFileOrNull();

	File getWarEarFatJarWorkDirOrDummy();

	URL mkURLOrNullForResource(String descriptor,
			boolean originalLocationRatherThanProjectDirLocation);

	URL mkSourcecodeURLOrNullForJavaClassFQN(String classFQN,
			boolean originalLocationRatherThanProjectDirLocation);

	URL mkOriginalSourcecodeURLOrNullForPath(String descriptor);

	String mkJavaClassFQNOrNullForSourcecodeURL(String url);

	Map<String, String> mkPathVariablesMap();

	boolean isSnapshot();
}
