/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Jan 7, 2019
 *
 */
package com.rigsit.xanitizer.pub.util;

/**
 * @author rust
 *
 */
public class JobInfo {
	private final String m_PresentationName;
	private final Runnable m_Runnable;
	private String m_ProgressMessageOrNull;

	public JobInfo(final String presentationName, final Runnable runnable) {
		m_PresentationName = presentationName;
		m_Runnable = runnable;
	}

	public String getPresentationName() {
		return m_PresentationName;
	}

	public Runnable getRunnable() {
		return m_Runnable;
	}

	public String getProgressMessageOrNull() {
		return m_ProgressMessageOrNull;
	}

	public void setProgressMessageOrNull(final String msgOrNull) {
		m_ProgressMessageOrNull = msgOrNull;
	}

	@Override
	public String toString() {
		return m_PresentationName;
	}
}
