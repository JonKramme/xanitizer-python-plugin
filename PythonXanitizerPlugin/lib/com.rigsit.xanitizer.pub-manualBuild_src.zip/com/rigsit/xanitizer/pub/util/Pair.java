/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 5, 2012
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.util.Objects;

/**
 * @author rust
 * 
 */
public class Pair<T, U> {

	public final T m_First;
	public final U m_Second;

	protected Pair(final T first, final U second) {
		m_First = first;
		m_Second = second;
	}

	public static <T, U> Pair<T, U> make(final T first, final U second) {
		return new Pair<T, U>(first, second);
	}

	@Override
	public int hashCode() {
		return (m_First == null ? 0 : m_First.hashCode()) + 3 * (m_Second == null ? 0 : m_Second.hashCode());
	}

	@Override
	public boolean equals(final Object o_) {
		if (this == o_) {
			return true;
		}
		if (null == o_ || getClass() != o_.getClass()) {
			return false;
		}

		final Pair<?, ?> o = (Pair<?, ?>) o_;
		return Objects.equals(m_First, o.m_First) && Objects.equals(m_Second, o.m_Second);
	}
}
