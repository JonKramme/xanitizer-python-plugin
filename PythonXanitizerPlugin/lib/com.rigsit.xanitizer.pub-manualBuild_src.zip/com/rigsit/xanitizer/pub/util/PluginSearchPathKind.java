/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Dec 12, 2019
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.nio.file.Path;

import com.rigsit.xanitizer.pub.plugin.PluginID;

/**
 * @author rust
 *
 */
public abstract class PluginSearchPathKind implements ISearchPathKind {
	private final PluginID m_PluginId;
	private final String m_Id;
	private final String m_PresentationName;
	private final String m_Description;
	private final boolean m_IsFileRatherThanDirOrPattern;
	private final ProgrammingLanguage m_ProgrammingLanguage;

	public PluginSearchPathKind(final PluginID pluginId, final String localId,
			final String presentationName, final String description,
			final boolean isFileRatherThanDirOrPattern, final ProgrammingLanguage language) {
		m_PluginId = pluginId;
		m_Id = pluginId.toString() + '/' + localId;
		m_PresentationName = presentationName;
		m_Description = description;
		m_IsFileRatherThanDirOrPattern = isFileRatherThanDirOrPattern;
		m_ProgrammingLanguage = language;
	}

	public PluginID getPluginID() {
		return m_PluginId;
	}

	public String getId() {
		return m_Id;
	}

	public String getPresentationName() {
		return m_PresentationName;
	}

	public String getDescription() {
		return m_Description;
	}

	@Override
	public boolean isFileRatherThanDirOrPattern() {
		return m_IsFileRatherThanDirOrPattern;
	}

	@Override
	public ProgrammingLanguage getProgrammingLanguage() {
		return m_ProgrammingLanguage;
	}

	public abstract boolean checkFile(Path fileOrDirToCheck);

	@Override
	public boolean isUserDefinable() {
		return true;
	}
}
