/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Dec 3, 2012
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Properties;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author rust
 * 
 */
public class ProcessUtil {
	private static Logger LOG = Logger.getLogger(ProcessUtil.class.getName());

	public static void createClassPathJar(final Collection<File> l, final File tgtJar)
			throws IOException {

		// Create the manifest entry.
		final StringBuilder sb = new StringBuilder();
		for (final File f : l) {
			assert f.isAbsolute();
			sb.append(' ');
			sb.append(f.toURI());
		}

		final Manifest manifest = new Manifest();
		manifest.getMainAttributes().putValue("Class-Path", sb.toString());
		manifest.getMainAttributes().putValue("Manifest-Version", "1.0");

		// Create a JAR with the Manifest.

		final FileOutputStream fos = new FileOutputStream(tgtJar);
		try {
			final JarOutputStream jos = new JarOutputStream(fos, manifest);
			jos.close();
		} finally {
			fos.close();
		}
	}

	private static class StreamReaderThread extends Thread {
		private final InputStream m_Is;
		private final OutputStream m_Os;
		private final Reader m_Rdr;
		private final StringBuilder m_Accu;

		public StreamReaderThread(final String threadName, final InputStream is) {
			super(threadName);
			assert is != null;

			m_Is = is;
			m_Os = null;
			m_Rdr = null;
			m_Accu = null;
		}

		public StreamReaderThread(final String threadName, final InputStream is,
				final OutputStream os) {
			super(threadName);
			assert is != null;
			assert os != null;

			m_Is = is;
			m_Os = os;
			m_Rdr = null;
			m_Accu = null;
		}

		public StreamReaderThread(final String threadName, final InputStream is,
				final Charset charset, final StringBuilder accu) {
			super(threadName);
			assert is != null;
			assert charset != null;
			assert accu != null;

			m_Is = null;
			m_Os = null;
			m_Rdr = new InputStreamReader(is, charset);
			m_Accu = accu;
		}

		@Override
		public void run() {
			while (true) {
				final int ch;
				try {
					ch = m_Rdr == null ? m_Is.read() : m_Rdr.read();
				} catch (final IOException ex) {
					return;
				}
				if (ch == -1) {
					return;
				}
				if (m_Accu != null) {
					synchronized (m_Accu) {
						m_Accu.append((char) ch);
					}
				}
				if (m_Os != null) {
					try {
						m_Os.write(ch);
					} catch (final IOException ex) {
						return;
					}
				}
			}
		}
	}

	public static int exec(final String[] cmdarray, final String[] envpOrNull,
			final File workDirOrNull, final Charset charset,
			final StringBuilder outputAccuOrNull, final StringBuilder errorAccuOrNull,
			final ICancelListener cancelListenerOrNull) throws IOException, InterruptedException {
		
		assert charset != null;
		
		final var process = Runtime.getRuntime().exec(cmdarray, envpOrNull, workDirOrNull);

		try (

				final var pis = process.getInputStream();
				final var pes = process.getErrorStream();

		) {

			final StreamReaderThread outputStreamReader = outputAccuOrNull == null
					? new StreamReaderThread("Output stream reader", pis)
					: new StreamReaderThread("Output stream reader", pis, charset,
							outputAccuOrNull);
			final StreamReaderThread errorStreamReader = errorAccuOrNull == null
					? new StreamReaderThread("Error stream reader", pes)
					: new StreamReaderThread("Error stream reader", pes, charset,
							errorAccuOrNull);
			return execHelper(process, outputStreamReader, errorStreamReader, cancelListenerOrNull);
		}
	}

	public static int exec(final String[] cmdarray, final String[] envpOrNull,
			final File workDirOrNull, final OutputStream osOut, final OutputStream osErr,
			final ICancelListener cancelListenerOrNull) throws IOException, InterruptedException {
		final Process process = Runtime.getRuntime().exec(cmdarray, envpOrNull, workDirOrNull);
		
		try (

				final var pis = process.getInputStream();
				final var pes = process.getErrorStream();

		) {
			final StreamReaderThread outputStreamReader = new StreamReaderThread("Output stream reader",
					pis, osOut);
			final StreamReaderThread errorStreamReader = new StreamReaderThread("Error stream reader",
					pes, osErr);
			return execHelper(process, outputStreamReader, errorStreamReader, cancelListenerOrNull);
		}
	}

	public static int execHelper(final Process process, final StreamReaderThread outputStreamReader,
			final StreamReaderThread errorStreamReader, final ICancelListener cancelListenerOrNull)
			throws InterruptedException {

		outputStreamReader.start();
		errorStreamReader.start();

		if (cancelListenerOrNull == null) {
			process.waitFor();
		} else {
			while (true) {
				if (cancelListenerOrNull.wasCancelled()) {
					process.destroy();
					cancelListenerOrNull.throwExceptionIfCancelled(null);
				}
				// Wait a moment.
				try {
					Thread.sleep(100);
				} catch (final InterruptedException ex) {
					LOG.log(Level.WARNING, "Unexpectedly caught an exception", ex);
				}
				try {
					// Has this process finished?
					process.exitValue();
					break;
				} catch (final IllegalThreadStateException ex) {
					// Not yet terminated: continue.
					continue;
				}
			}
		}

		final int retVal = process.waitFor();

		outputStreamReader.join();
		errorStreamReader.join();

		return retVal;
	}

	/**
	 * Construct a command line from the given pattern, replacing variable
	 * references by the values in props.
	 * 
	 * In the pattern, variable references (of form ${var-name}) are replaced by
	 * their values from props. If a value is missing, an
	 * IllegalArgumentException is thrown.
	 * 
	 * After replacement, the pattern is split at unquoted whitespace-sequences
	 * into words. Quotes are either double quotes ("") or single quotes ('').
	 * To put a quote character into the result, enclose it with quotes of the
	 * other kind.
	 * 
	 * @param template
	 *            the template from which to create the command line
	 * @param props
	 *            variables that are replaced in the template
	 * @return the constructed command line
	 * @throws IllegalArgumentException
	 *             if an undefined variable is referenced, or the template ends
	 *             in an unterminated quoted string
	 */
	public static String[] mkCommandLine(final String template, final Properties props) {
		LOG.fine("Creating command line/template: " + template);
		final String cmdLine = VarUtil.replaceVarRefs(template, props);
		LOG.fine("Creating command line/result: " + cmdLine);

		final List<String> result = new ArrayList<String>();
		fillInSpaceSeparatedWords(cmdLine, 0, result);

		return result.toArray(new String[result.size()]);
	}

	private static void fillInSpaceSeparatedWords(final String line, int idx,
			final List<String> result) {
		// state==0: outside quotes, nothing has been read
		// state==1: outside quotes, something has been read (perhaps an empty
		// quoted string)
		// state=='\'': inside single quotes
		// state=='"': inside double quotes
		int state = 0;

		final StringBuilder wordAccu = new StringBuilder();
		while (idx < line.length()) {
			final char ch = line.charAt(idx++);
			switch (state) {
			case 0:
				if (ch == '\'' || ch == '"') {
					// Starting a quoted string.
					state = ch;
				} else if (!Character.isWhitespace(ch)) {
					// First character in a word.
					wordAccu.append(ch);
					state = 1;
				}
				break;
			case 1:
				if (ch == '\'' || ch == '"') {
					// Starting a quoted string.
					state = ch;
				} else if (Character.isWhitespace(ch)) {
					// Reached the end of a word.
					result.add(wordAccu.toString());
					wordAccu.setLength(0);
					state = 0;
				} else {
					// Word goes on.
					wordAccu.append(ch);
				}
				break;
			case '\'':
			case '"':
				if (ch == state) {
					// Ended a quoted string.
					state = 1;
				} else {
					// Next character in quoted string.
					wordAccu.append(ch);
				}
				break;
			}
		}

		switch (state) {
		case 0:
			// Nothing to do; there were spaces at the end of the template, or
			// there was no content at all.
			break;
		case 1:
			// There is a last word in the word accu.
			result.add(wordAccu.toString());
			break;
		case '"':
		case '\'':
			throw new IllegalArgumentException("Nonterminated quoted string in: " + line);
		}
	}
}
