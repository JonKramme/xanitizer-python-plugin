/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on 24.03.2020
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.util.ArrayList;
import java.util.List;

/**
 * @author norma
 *
 */
public enum ProgrammingLanguage {

	JAVA("Java"), JAVA_SCRIPT("JavaScript"), PYTHON("Python"), PHP("PHP"), GO("GO"), RUBY(
			"Ruby"), DOT_NET(".Net"), SWIFT("Swift"), NONE("None"), MULTIPLE("Multiple");

	private final String m_PresentationName;

	private ProgrammingLanguage(final String presentationName) {
		m_PresentationName = presentationName;
	}

	public String getPresentationName() {
		return m_PresentationName;
	}

	public static ProgrammingLanguage getLanguageFromString(final String name) {
		for (ProgrammingLanguage language : values()) {
			if (language.m_PresentationName.equals(name)) {
				return language;
			}
		}

		return null;
	}

	public static String[] getPresentationNames() {
		final List<String> result = new ArrayList<>();
		for (ProgrammingLanguage language : values()) {
			result.add(language.getPresentationName());
		}
		return result.toArray(new String[result.size()]);
	}
}
