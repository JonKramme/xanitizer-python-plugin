/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Dec 2, 2016
 *
 */
package com.rigsit.xanitizer.pub.util;

import com.rigsit.xanitizer.pub.plugin.PluginID;

/**
 * Some constants that are needed in the plugin code.
 */
public class PublicConstants {
	public static final PluginID GENERIC_FRAMEWORKSIMULATION_ID = new PluginID(
			"BasicGenericFrameworkSupport");
	public static final String GENERIC_FRAMEWORKSIMULATION__PRESENTATION_NAME = "Basic Generic Framework Support";
	
}
