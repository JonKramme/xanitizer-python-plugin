/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on May 24, 2017
 *
 */
package com.rigsit.xanitizer.pub.util;

/**
 * @author rust
 *
 */
public enum ScalaVersion {
	V2_12("2_12"),

	;

	private final String m_VersionString;

	private ScalaVersion(final String versionString) {
		m_VersionString = versionString;
	}

	public String getVersionString() {
		return m_VersionString;
	}

}
