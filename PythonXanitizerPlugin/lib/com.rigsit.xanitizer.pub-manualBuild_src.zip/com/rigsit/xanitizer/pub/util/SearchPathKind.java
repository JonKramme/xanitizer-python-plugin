/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 10, 2016
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.io.File;
import java.util.function.Predicate;

public enum SearchPathKind implements ISearchPathKind {
	JAVA_JAR("Java Jar File", true, true, "Search path element for the specified Java jar file.",
			null, false, ProgrammingLanguage.JAVA),

	JAVA_JAR_PATTERN("Java Jar Pattern", false, true,
			"Wildcard-pattern for specifying sets of Java jar files.", null, false,
			ProgrammingLanguage.JAVA),

	JAVA_SRC_DIR("Java/Scala Source Directory", false, true,
			"Search path element for Java/Scala source files located in this directory and in all of its subdirectories.",
			f -> f.getName().endsWith(".java") || f.getName().endsWith(".scala"), true,
			ProgrammingLanguage.JAVA),

	JAVA_CLASS_DIR("Java/Scala Class Directory", false, true,
			"Search path element for Java/Scala class files located in this directory and in all of its subdirectories.",
			f -> f.getName().endsWith(".class"), true, ProgrammingLanguage.JAVA),

	SYSTEM_JAR("System Jar File", true, false,
			"Search path element for the specified Java system jar file.", null, false,
			ProgrammingLanguage.JAVA),

	PREINSTALLED_NON_SYSTEM_JAR("Pre-Installed Jar File", true, false,
			"Search path element for the specified preinstalled non-system Java jar file.", null,
			false, ProgrammingLanguage.JAVA),

	JSP_DIR("JSP Directory", false, true,
			"Search path element for JSP files located in this directory and in all of its subdirectories.",
			f -> FileExtensions.JSP_EXTENSIONS.contains(mkFileNameExtensionOrEmpty(f.getName())),
			true, ProgrammingLanguage.JAVA),

	XML_DIR("XML Directory", false, true,
			"Search path element for XML files located in this directory (but not in subdirectories).",
			f -> FileExtensions.XML_EXTENSIONS.contains(mkFileNameExtensionOrEmpty(f.getName())),
			false, ProgrammingLanguage.NONE),

	CONFIG_FILE_DIR("Config File Directory", false, true,
			"Search path element for configuration files located in this directory (but not in subdirectories).",
			f -> FileExtensions.CONFIG_FILE_EXTENSIONS
					.contains(mkFileNameExtensionOrEmpty(f.getName())),
			false, ProgrammingLanguage.NONE),

	WEB_INF_DIR("WEB-INF Directory", false, true,
			"Search path element for a directory named 'WEB-INF'.", (File f) -> true, true,
			ProgrammingLanguage.NONE),

	/*
	 * Directly in such directories, we collect extra resources, i.e. all files
	 * matching the non-filter resource pattern are used.
	 */
	EXTRA_RESOURCES_DIR("Extra Resources Directory", false, true,
			"Search path element for additional resource files located in this directory (but not in subdirectories).",
			f -> true, false, ProgrammingLanguage.NONE),

	WAR_OR_EAR("WAR, EAR, or Fat JAR File", true, true,
			"Web archive or enterprise web archive, or Fat Jar file", null, false,
			ProgrammingLanguage.JAVA),

	POM_FILE("Maven POM File", true, true,
			"A Maven POM file that is used to collect the required JAR files.", null, false,
			ProgrammingLanguage.NONE),

	;

	private final String m_PresentationName;
	private final boolean m_IsFileRatherThanDirOrPattern;
	private final boolean m_IsUserDefinable;
	private final String m_Description;
	private final Predicate<File> m_IsRelevantFilePredicateForEquivalenceComputationOfDirectoriesOrNull;
	private final boolean m_EquivalenceComputationForDirectoriesMustBeDoneRecursively;
	private final ProgrammingLanguage m_ProgrammingLanguage;

	private SearchPathKind(final String presentationName,
			final boolean isFileRatherThanDirOrPattern, final boolean isUserDefinable,
			final String description,
			final Predicate<File> isRelevantFilePredicateForEquivalenceComputationOfDirectoriesOrNull,
			final boolean equivalenceComputationForDirectoriesMustBeDoneRecursively,
			final ProgrammingLanguage language) {
		m_PresentationName = presentationName;
		m_IsFileRatherThanDirOrPattern = isFileRatherThanDirOrPattern;
		m_IsUserDefinable = isUserDefinable;
		m_Description = description;
		m_IsRelevantFilePredicateForEquivalenceComputationOfDirectoriesOrNull = isRelevantFilePredicateForEquivalenceComputationOfDirectoriesOrNull;
		m_EquivalenceComputationForDirectoriesMustBeDoneRecursively = equivalenceComputationForDirectoriesMustBeDoneRecursively;
		m_ProgrammingLanguage = language;
	}

	public String getId() {
		return name();
	}

	public String getPresentationName() {
		return m_PresentationName;
	}

	public boolean isFileRatherThanDirOrPattern() {
		return m_IsFileRatherThanDirOrPattern;
	}

	public boolean isUserDefinable() {
		return m_IsUserDefinable;
	}

	public String getDescription() {
		return m_Description;
	}

	@Override
	public ProgrammingLanguage getProgrammingLanguage() {
		return m_ProgrammingLanguage;
	}

	public Predicate<File> getIsRelevantFilePredicateForEquivalenceComputationOfDirectoriesOrNull() {
		return m_IsRelevantFilePredicateForEquivalenceComputationOfDirectoriesOrNull;
	}

	public boolean equivalenceComputationForDirectoriesMustBeDoneRecursively() {
		return m_EquivalenceComputationForDirectoriesMustBeDoneRecursively;
	}

	public static SearchPathKind getFromPresentationNameOrNull(final String presentationName) {
		for (final SearchPathKind value : values()) {
			if (value.getPresentationName().equals(presentationName)) {
				return value;
			}
		}
		return null;
	}

	private static String mkFileNameExtensionOrEmpty(final String fileName) {
		final int idx = fileName.lastIndexOf('.');
		if (idx == -1)
			return "";
		return fileName.substring(idx + 1);
	}

	public static SearchPathKind[] getResourceKinds() {
		return new SearchPathKind[] { SearchPathKind.EXTRA_RESOURCES_DIR, SearchPathKind.XML_DIR,
				SearchPathKind.CONFIG_FILE_DIR };
	}
}