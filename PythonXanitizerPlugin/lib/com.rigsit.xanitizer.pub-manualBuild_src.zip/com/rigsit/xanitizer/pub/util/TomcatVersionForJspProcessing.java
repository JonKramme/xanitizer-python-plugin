/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 29, 2016
 *
 */
package com.rigsit.xanitizer.pub.util;

public enum TomcatVersionForJspProcessing {
	V7_0("7.0"),

	V8_0("8.0"),

	V8_5("8.5"),
	
	V9_0("9.0"),

	;

	private final String m_VersionString;

	private TomcatVersionForJspProcessing(final String versionString) {
		m_VersionString = versionString;
	}

	public String getVersionString() {
		return m_VersionString;
	}

	public static String getConfigurationItemXMLElementName() {
		return "WS_TomcatVersionForJspProcessing";
	}

	public static TomcatVersionForJspProcessing mkNewest() {
		return values()[values().length - 1];
	}
}