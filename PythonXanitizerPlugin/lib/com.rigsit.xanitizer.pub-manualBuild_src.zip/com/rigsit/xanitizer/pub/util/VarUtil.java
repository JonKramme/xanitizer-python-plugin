/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 * Created on 26.11.2012
 *
 */
package com.rigsit.xanitizer.pub.util;

import java.util.Map;
import java.util.Properties;
import java.util.function.Function;

/**
 * @author nwe
 * 
 */
public class VarUtil {

	public static String replaceVarRefs(final String s, final Properties props) {
		final Function<String, String> f = u -> props.getProperty(u);
		return replaceVarRefs(s, f);
	}

	public static String replaceVarRefs(final String s, final Map<String, String> varDefs) {
		final Function<String, String> f = u -> varDefs.get(u);
		return replaceVarRefs(s, f);
	}

	public static String replaceVarRefs(final String s, final Function<String, String> varDefs) {
		final StringBuilder sb = new StringBuilder();
		int nextStartIdx = 0;
		while (true) {
			// Var refs start with "${" and end with "}".
			final int idx = s.indexOf("${", nextStartIdx);
			if (idx == -1 || idx == s.length() - 1) {
				// No env var reference found.
				sb.append(s.substring(nextStartIdx));
				break;
			}

			// Look for closing brace.
			final int idx2 = s.indexOf("}", idx + 2);

			assert idx2 != -1 : "Invalid variable reference in '" + s + "': no closing brace";

			if (idx2 != -1) {
				final String var = s.substring(idx + 2, idx2);
				final String val = varDefs.apply(var);
				assert val != null : "Invalid variable reference in '" + var
						+ "': no value found for var '" + var + "'";

				if (val != null) {
					sb.append(s.substring(nextStartIdx, idx));
					sb.append(val);
					nextStartIdx = idx2 + 1;

					// Go on.
					continue;
				}
			}

			// Copy current string to result.
			sb.append(s.substring(nextStartIdx, idx + 2));
			nextStartIdx = idx + 2;
		}

		return sb.toString();
	}

	public static String replaceLongestPossiblePrefixByVarRef(final String s,
			final Map<String, String> varDefs) {
		// Look for longest prefix.
		String var = null;
		String pfix = null;
		for (final Map.Entry<String, String> e : varDefs.entrySet()) {
			final String val = e.getValue();
			if (!val.isEmpty() && s.startsWith(val)
					&& (pfix == null || pfix.length() < val.length())) {
				// Found a better prefix.
				var = e.getKey();
				pfix = val;
			}
		}

		if (var == null) {
			// No matching variable found.
			return s;
		}
		return "${" + var + "}" + s.substring(pfix.length());
	}
}
