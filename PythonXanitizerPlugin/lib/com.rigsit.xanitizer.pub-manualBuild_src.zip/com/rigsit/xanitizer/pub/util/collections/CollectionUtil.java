/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Feb 14, 2014
 *
 */
package com.rigsit.xanitizer.pub.util.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

/**
 * @author rust
 * 
 */
public class CollectionUtil {
	public static <T> Iterable<T> combineIterables(final Iterable<T> it1, final Iterable<T> it2) {
		return new Iterable<T>() {
			@Override
			public Iterator<T> iterator() {
				return new Iterator<T>() {

					private boolean m_First = true;
					private Iterator<T> m_Current = null;

					@Override
					public boolean hasNext() {
						if (m_Current == null) {
							m_Current = it1.iterator();
						}
						if (m_First && !m_Current.hasNext()) {
							// Proceed to next iterator.
							m_First = false;
							m_Current = it2.iterator();
						}
						return m_Current.hasNext();
					}

					@Override
					public T next() {
						if (!hasNext()) {
							throw new NoSuchElementException();
						}
						return m_Current.next();
					}

					@Override
					public void remove() {
						if (null == m_Current) {
							throw new IllegalStateException();
						}
						m_Current.remove();
					}
				};
			}
		};
	}
	
	public static <T1, T2> List<T1> findOrCreateList(final Map<T2, List<T1>> m, final T2 k) {
		List<T1> result = m.get(k);
		if (result == null) {
			result = new ArrayList<>();
			m.put(k, result);
		}
		return result;
	}

	public static <T1, T2> Set<T1> findOrCreateLinkedHashSet(final Map<T2, Set<T1>> m, final T2 k) {
		Set<T1> result = m.get(k);
		if (result == null) {
			result = new LinkedHashSet<>();
			m.put(k, result);
		}
		return result;
	}
}
