/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 5, 2012
 *
 */
package com.rigsit.xanitizer.pub.util.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * @author rust
 */
public class MapUtil {

	public static <T> Integer getValueOrZero(final Map<T, Integer> map, final T key) {
		final Integer value = map.get(key);
		if (value == null) {
			return 0;
		}
		return value;
	}

	public static <T> void increment(final Map<T, Integer> map, final T key) {
		map.put(key, getValueOrZero(map, key) + 1);
	}

	public static <K, T> List<T> findOrCreateList(final Map<K, List<T>> M, final K key) {
		List<T> result = M.get(key);
		if (result == null) {
			result = new ArrayList<T>(3);
			M.put(key, result);
		}
		return result;
	}

	public static <K, T> LinkedHashSet<T> findOrCreateLinkedHashSet(
			final Map<K, LinkedHashSet<T>> M, final K key) {
		LinkedHashSet<T> result = M.get(key);
		if (result == null) {
			result = SetUtil.makeLinkedHashSet();
			M.put(key, result);
		}
		return result;
	}

	public static <K, T> Set<T> findOrCreateSet(final Map<K, Set<T>> M, final K key) {
		Set<T> result = M.get(key);
		if (result == null) {
			result = new LinkedHashSet<T>(3);
			M.put(key, result);
		}
		return result;
	}

	public static <K, T, V> Map<T, V> findOrCreateMap(final Map<K, Map<T, V>> M, final K key) {
		Map<T, V> result = M.get(key);
		if (result == null) {
			result = new HashMap<T, V>(3);
			M.put(key, result);
		}
		return result;
	}

	public static <K, T, V> Map<T, V> findOrCreateTreeMap(final Map<K, Map<T, V>> M, final K key) {
		Map<T, V> result = M.get(key);
		if (result == null) {
			result = new TreeMap<T, V>();
			M.put(key, result);
		}
		return result;
	}

	public static <K, T> List<T> getListOrEmpty(final Map<K, List<T>> M, final K key) {
		final List<T> result = M.get(key);
		if (result != null) {
			return result;
		}
		return Collections.emptyList();
	}

	public static <K, T> HashMap<K, T> makeHashMap() {
		return new HashMap<K, T>();
	}

	public static <K, T> TreeMap<K, T> makeTreeMap() {
		return new TreeMap<K, T>();
	}

	public static <K, T> TreeMap<K, T> makeTreeMap(Comparator<K> comparator) {
		return new TreeMap<K, T>(comparator);
	}

	public static <K, T> LinkedHashMap<K, T> makeLinkedHashMap() {
		return new LinkedHashMap<K, T>();
	}

	public static <K, T> TinyMap<K, T> makeTinyMap() {
		return new TinyMap<K, T>();
	}
}
