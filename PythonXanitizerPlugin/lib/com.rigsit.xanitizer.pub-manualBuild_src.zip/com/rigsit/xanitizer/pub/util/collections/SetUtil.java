/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Nov 5, 2012
 *
 */
package com.rigsit.xanitizer.pub.util.collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author rust
 */
public class SetUtil {
	public static <T> HashSet<T> makeHashSet() {
		return new HashSet<T>();
	}

	public static <T> LinkedHashSet<T> makeLinkedHashSet() {
		return new LinkedHashSet<T>();
	}

	public static <T> TreeSet<T> makeTreeSet() {
		return new TreeSet<T>();
	}

	public static <T> boolean equals(final Set<T> s1, final Set<T> s2) {
		assert s1 != null && s2 != null;
		if (s1.size() != s2.size()) {
			return false;
		}
		return s1.containsAll(s2);
	}
}
