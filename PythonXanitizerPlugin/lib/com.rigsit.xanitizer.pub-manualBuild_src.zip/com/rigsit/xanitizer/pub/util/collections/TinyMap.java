/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 */
package com.rigsit.xanitizer.pub.util.collections;

import java.util.AbstractCollection;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

public final class TinyMap<K, V> implements Map<K, V> {
	// The keys are in even positions, values in following odd. When array is
	// empty, it is replaced by null instead.
	private Object[] m_Content;

	@Override
	public int size() {
		return m_Content == null ? 0 : m_Content.length / 2;
	}

	@Override
	public boolean isEmpty() {
		return size() == 0;
	}

	@Override
	public boolean containsKey(final Object key) {
		return mkStepTwoIndex(key, 0) >= 0;
	}

	@Override
	public boolean containsValue(final Object value) {
		return mkStepTwoIndex(value, 1) >= 0;
	}

	@Override
	@SuppressWarnings("unchecked")
	public V put(final K key, final V value) {
		if (m_Content == null) {
			m_Content = new Object[] { key, value };
			return null;
		}

		final int idx = mkStepTwoIndex(key, 0);

		if (idx != -1) {
			final V oldValue = (V) m_Content[idx + 1];
			m_Content[idx + 1] = value;

			return oldValue;
		}

		final int oldLength = m_Content.length;
		final Object[] newArray = new Object[oldLength + 2];
		newArray[0] = key;
		newArray[1] = value;
		System.arraycopy(m_Content, 0, newArray, 2, oldLength);
		m_Content = newArray;

		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public V get(final Object key) {
		final int idx = mkStepTwoIndex(key, 0);
		return (idx < 0) ? null : (V) m_Content[idx + 1];
	}

	@Override
	@SuppressWarnings("unchecked")
	public V remove(final Object key) {
		final int idx = mkStepTwoIndex(key, 0);
		if (idx < 0) {
			return null;
		}
		final V oldValue = (V) m_Content[idx + 1];
		removeEntryAt(idx);
		return oldValue;
	}

	@Override
	public void putAll(final Map<? extends K, ? extends V> m) {
		for (final Map.Entry<? extends K, ? extends V> e : m.entrySet()) {
			put(e.getKey(), e.getValue());
		}
	}

	@Override
	public void clear() {
		m_Content = null;
	}

	// Set operations are based on entry set iterators.

	@Override
	public Set<K> keySet() {
		return new AbstractSet<K>() {
			@Override
			public Iterator<K> iterator() {
				return new Iterator<K>() {
					private Iterator<Map.Entry<K, V>> m_Iterator = entrySet().iterator();

					@Override
					public boolean hasNext() {
						return m_Iterator.hasNext();
					}

					@Override
					public K next() {
						return m_Iterator.next().getKey();
					}

					@Override
					public void remove() {
						m_Iterator.remove();
					}
				};
			}

			@Override
			public int size() {
				return TinyMap.this.size();
			}
		};
	}

	// Set operations are based on entry set iterators.
	@Override
	public Collection<V> values() {
		return new AbstractCollection<V>() {
			@Override
			public Iterator<V> iterator() {
				return new Iterator<V>() {
					private Iterator<Map.Entry<K, V>> m_Iterator = entrySet().iterator();

					@Override
					public boolean hasNext() {
						return m_Iterator.hasNext();
					}

					@Override
					public V next() {
						return m_Iterator.next().getValue();
					}

					@Override
					public void remove() {
						m_Iterator.remove();
					}
				};
			}

			@Override
			public int size() {
				return TinyMap.this.size();
			}
		};
	}

	@Override
	public Set<Map.Entry<K, V>> entrySet() {
		return new AbstractSet<Map.Entry<K, V>>() {
			@Override
			public Iterator<Map.Entry<K, V>> iterator() {
				return new Iterator<Map.Entry<K, V>>() {
					// Index of next key.
					private int m_Idx = 0;

					// Is removal of the last returned element allowed?
					private boolean m_RemovalAllowed = false;

					@Override
					public boolean hasNext() {
						return m_Content != null && m_Idx < m_Content.length;
					}

					@SuppressWarnings("unchecked")
					public Map.Entry<K, V> next() {
						if (!hasNext()) {
							throw new NoSuchElementException();
						}

						m_RemovalAllowed = true;

						final int idx = m_Idx;
						m_Idx += 2;

						return new Map.Entry<K, V>() {
							@Override
							public K getKey() {
								return (K) m_Content[idx];
							}

							@Override
							public V getValue() {
								return (V) m_Content[idx + 1];
							}

							@Override
							public V setValue(final V value) {
								final V oldVal = (V) m_Content[idx + 1];
								m_Content[idx + 1] = value;
								return oldVal;
							}

							@Override
							public boolean equals(final Object otherObject) {
								if (!(otherObject instanceof Map.Entry)) {
									return false;
								}
								final Map.Entry<K, V> other = (Map.Entry<K, V>) otherObject;
								return eq(getKey(), other.getKey())
										&& eq(getValue(), other.getValue());
							}

							@Override
							public int hashCode() {
								final Map.Entry<K, V> e = this;
								return (e.getKey() == null ? 0 : e.getKey().hashCode())
										+ (e.getValue() == null ? 0 : e.getValue().hashCode());
							}
						};
					}

					@Override
					public void remove() {
						if (!m_RemovalAllowed) {
							throw new IllegalStateException();
						}
						m_RemovalAllowed = false;
						m_Idx -= 2;
						TinyMap.this.removeEntryAt(m_Idx);
					}
				};
			}

			@Override
			public int size() {
				return TinyMap.this.size();
			}
		};
	}

	private void removeEntryAt(final int idx) {
		assert idx % 2 == 0;

		final int len = m_Content.length;
		if (len == 2) {
			m_Content = null;
		} else {
			final Object[] newArray = new Object[len - 2];
			if (idx > 0) {
				System.arraycopy(m_Content, 0, newArray, 0, idx);
			}
			if (idx < len - 2) {
				System.arraycopy(m_Content, idx + 2, newArray, idx, len - 2 - idx);
			}
			m_Content = newArray;
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (!(o instanceof Map)) {
			return false;
		}

		final Map<Object, Object> m = (Map<Object, Object>) o;
		if (m.size() != this.size()) {
			return false;
		}

		for (final Map.Entry<Object, Object> e : m.entrySet()) {
			final Object oKey = e.getKey();
			final int idx = mkStepTwoIndex(oKey, 0);
			if (idx < 0) {
				return false;
			}
			final Object oVal = e.getValue();
			final Object thisVal = m_Content[idx + 1];
			if (!eq(thisVal, oVal)) {
				return false;
			}
		}
		return true;
	}

	@Override
	public int hashCode() {
		int result = 0;
		for (final Map.Entry<K, V> e : entrySet()) {
			result = 3 * result + e.hashCode();
		}
		return result;
	}

	private int mkStepTwoIndex(final Object value, int i) {
		if (m_Content == null) {
			return -1;
		}
		final int len = m_Content.length;
		for (; i < len; i += 2) {
			final Object elem = m_Content[i];
			if (eq(elem, value)) {
				return i;
			}
		}
		return -1;
	}

	private static boolean eq(final Object o1, final Object o2) {
		return o1 == o2 || o1 != null && o1.equals(o2);
	}
}