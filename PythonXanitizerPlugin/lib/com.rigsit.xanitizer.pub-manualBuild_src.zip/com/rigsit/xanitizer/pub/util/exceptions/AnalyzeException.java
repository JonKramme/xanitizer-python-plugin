/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 * Created on 02.11.2012
 *
 */
package com.rigsit.xanitizer.pub.util.exceptions;

/**
 * @author nwe
 * 
 */
public class AnalyzeException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AnalyzeException(final String message, final Throwable cause) {
		super(message, cause);
	}

	public AnalyzeException(final String message) {
		super(message);
	}
}
