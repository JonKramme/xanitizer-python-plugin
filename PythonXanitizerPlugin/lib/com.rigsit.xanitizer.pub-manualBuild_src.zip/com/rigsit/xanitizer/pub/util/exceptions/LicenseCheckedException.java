/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 * Created on 13.11.2012
 *
 */
package com.rigsit.xanitizer.pub.util.exceptions;

/**
 * @author thomass
 *
 */
public class LicenseCheckedException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LicenseCheckedException(String message) {
		super(message);
	}
}
