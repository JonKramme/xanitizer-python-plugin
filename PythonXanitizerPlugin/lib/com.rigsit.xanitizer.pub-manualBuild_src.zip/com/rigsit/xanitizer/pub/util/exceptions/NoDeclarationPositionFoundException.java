/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on 18.06.2015
 *
 */
package com.rigsit.xanitizer.pub.util.exceptions;

/**
 * @author nwe
 *
 */
public class NoDeclarationPositionFoundException extends Exception {

	public NoDeclarationPositionFoundException(final String message) {
		super(message);
	}

	private static final long serialVersionUID = -8424824371030349110L;

}
