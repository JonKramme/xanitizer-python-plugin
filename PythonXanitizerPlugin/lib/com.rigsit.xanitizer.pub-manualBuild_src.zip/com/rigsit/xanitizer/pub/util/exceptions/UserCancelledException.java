/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 * Created on 12.02.2013
 *
 */
package com.rigsit.xanitizer.pub.util.exceptions;

/**
 * @author hru
 * 
 */
@SuppressWarnings("serial")
public class UserCancelledException extends CancelledException {
	public UserCancelledException(final String msg) {
		super(msg);
	}
}
