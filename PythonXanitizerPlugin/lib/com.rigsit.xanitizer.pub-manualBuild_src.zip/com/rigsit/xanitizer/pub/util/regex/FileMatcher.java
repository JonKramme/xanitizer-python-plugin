/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch.
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Mar 8, 2020
 *
 */
package com.rigsit.xanitizer.pub.util.regex;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import com.rigsit.xanitizer.pub.util.IPersistibleFileMatcher;

/**
 * @author rust
 *
 */
public class FileMatcher implements IPersistibleFileMatcher {
	public static FileMatcher mk(final Collection<String> includePatterns,
			final Collection<String> excludePatterns) {
		final FileMatcher result = new FileMatcher();
		result.m_IncludePatterns.addAll(includePatterns);
		result.m_ExcludePatterns.addAll(excludePatterns);
		result.recomputeRegexPatterns();
		return result;
	}

	/*
	 * ';'-delimited list of patterns, each starting with '+' or '-' for include
	 * or exclude patterns.
	 */
	public static FileMatcher parse(final String matcherText) throws PatternSyntaxException {
		final FileMatcher result = new FileMatcher();
		int i = 0;
		final int len = matcherText.length();
		for (; i < len; ++i) {
			// Skip whitespace and comments.
			for (; i < len; ++i) {
				char ch = matcherText.charAt(i);
				if (Character.isWhitespace(ch)) {
					continue;
				}
				if (ch == '#') {
					++i;
					// Skip to end of line.
					for (; i < len; ++i) {
						ch = matcherText.charAt(i);
						if (ch == '\n' || ch == '\r') {
							if (ch == '\r' && i + 1 < len && matcherText.charAt(i + 1) == '\n') {
								++i;
							}
							break;
						}
						continue;
					}
					continue;
				}
				break;
			}
			// Have skipped whitespace and comment. Anything still left?
			if (i >= len) {
				break;
			}
			int nxtSemiOrEnd = matcherText.indexOf(';', i);
			if (nxtSemiOrEnd == -1) {
				nxtSemiOrEnd = matcherText.length();
			}
			final var s_ = matcherText.substring(i, nxtSemiOrEnd);
			final var s = s_.trim();
			final List<String> tgt;
			if (s.startsWith("+")) {
				tgt = result.m_IncludePatterns;
				tgt.add(s.substring(1).trim());
			} else if (s.startsWith("-")) {
				tgt = result.m_ExcludePatterns;
				tgt.add(s.substring(1).trim());
			} else if (s.equals("")) {
				// Nothing to be done.
			} else {
				throw new PatternSyntaxException("Pattern with invalid prefix", matcherText, i);
			}
			i = nxtSemiOrEnd;
		}
		result.recomputeRegexPatterns();
		return result;
	}

	private final List<String> m_IncludePatterns = new ArrayList<>();
	private final List<String> m_ExcludePatterns = new ArrayList<>();

	private final List<Pattern> m_IncludeRegexPatterns = new ArrayList<>();
	private final List<Pattern> m_ExcludeRegexPatterns = new ArrayList<>();

	private final List<Pattern> m_DirExclusionPatterns = new ArrayList<>();

	private FileMatcher() {
	}

	public List<String> getIncludePatterns() {
		return m_IncludePatterns;
	}

	public List<String> getExcludePatterns() {
		return m_ExcludePatterns;
	}

	public boolean hasPattern(final String pattern) {
		return m_IncludePatterns.contains(pattern) || m_ExcludePatterns.contains(pattern);
	}

	private void recomputeRegexPatterns() {
		m_IncludeRegexPatterns.clear();
		for (var s : m_IncludePatterns) {
			// Add a '/' at the start if there is none.
			if (!s.startsWith("**") && !s.startsWith("/")) {
				s = '/' + s;
			}
			m_IncludeRegexPatterns.add(RegexUtil.mkRegexPatternFromWildcardPattern(s, '/'));
		}
		m_ExcludeRegexPatterns.clear();
		for (var s : m_ExcludePatterns) {
			// Add a '/' at the start if there is none.
			if (!s.startsWith("**") && !s.startsWith("/")) {
				s = '/' + s;
			}
			m_ExcludeRegexPatterns.add(RegexUtil.mkRegexPatternFromWildcardPattern(s, '/'));
			if (s.endsWith("/**")) {
				m_DirExclusionPatterns.add(RegexUtil
						.mkRegexPatternFromWildcardPattern(s.substring(0, s.length() - 2), '/'));
			}
		}
	}

	@Override
	public String mkPersistenceString() {
		return convertToString(m_IncludePatterns, m_ExcludePatterns);
	}

	public static String convertToString(final List<String> includePatterns,
			final List<String> excludePatterns) {
		final StringBuilder sb = new StringBuilder();
		for (final var s : includePatterns) {
			if (sb.length() > 0) {
				sb.append(';');
			}
			sb.append('+' + s);
		}
		for (final var s : excludePatterns) {
			if (sb.length() > 0) {
				sb.append(';');
			}
			sb.append('-' + s);
		}
		return sb.toString();
	}

	@Override
	public boolean test(final String tested) {
		boolean sawMatch = false;
		for (final var p : m_IncludeRegexPatterns) {
			if (p.matcher(tested).matches()) {
				sawMatch = true;
				break;
			}
		}
		if (!sawMatch) {
			return false;
		}

		for (final var p : m_ExcludeRegexPatterns) {
			if (p.matcher(tested).matches()) {
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean canSkipEverythingInDir(final String relativeDirPath) {
		/*
		 * If there is an exclusion pattern ending in "/**" and the part before
		 * the "**" matches the relative dir path, we can skip the dir and
		 * everything in it.
		 */
		for (final var p : m_DirExclusionPatterns) {
			if (p.matcher(relativeDirPath).matches()) {
				return true;
			}
		}
		return false;
	}
}
