/** This code is proprietary/confidential information of the RIGS IT GmbH, Switzerland.
 * Copyright 2012-2021 by RIGS IT GmbH, Switzerland, www.rigs-it.ch
 * All rights reserved. Use is subject to license terms.
 *
 * Created on Oct 1, 2012
 *
 */
package com.rigsit.xanitizer.pub.util.regex;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * @author rust
 */
public class RegexUtil {
	public final static Pattern JAVA_METHOD_INTERFACE_REGEX;
	public final static Pattern JAVA_METHOD_INTERFACE_PATTERN_REGEX;
	public final static Pattern JAVA_FQ_CLASS_REGEX;
	public final static Pattern INT_LISTS_REGEX;
	public final static Pattern INT_REGEX;
	public final static Pattern EMPTY_REGEX;
	public final static Pattern NON_EMPTY_REGEX;
	public final static Pattern EMPTY_OR_BOOLEAN_REGEX;
	public final static Pattern BOOLEAN_REGEX;

	static {
		final String ws = "(?:\\p{Space}+)";
		final String wsOpt = "(?:\\p{Space}*)";
		final String id = "(?:[_\\p{Alpha}][_$\\p{Alnum}]*)";
		final String fqMethodName = "(?:(?:" + id + "[.])*" + id + ")";
		final String type = fqMethodName + "(?:" + wsOpt + "\\[\\])*";
		final String nonEmptyCommaSepTypeSeq = "(?:" + wsOpt + type + wsOpt + "[,])*" + wsOpt
				+ type;

		final String idPattern = "(?:[*?_\\p{Alpha}][*?_$\\p{Alnum}]*)";
		final String fqMethodNamePattern = "(?:(?:" + idPattern + "[.])*" + idPattern + ")";
		final String typePattern = fqMethodNamePattern + "(?:" + wsOpt + "\\[\\])*";
		final String nonEmptyCommaSepTypePatternSeq = "(?:" + wsOpt + typePattern + wsOpt + "[,])*"
				+ wsOpt + typePattern;

		final String intger = "(?:-?\\p{Digit}+)";

		// final String nonEmptyCommaSepIntSeq = "(?:" + wsOpt + intger + wsOpt
		// + ",)*" + wsOpt + intger;
		final String potentiallyEmptyCommaSepIntSeq = "(?:|" + wsOpt + intger + wsOpt + ",)*"
				+ wsOpt + intger;

		try {
			// Pos 1: optional return type, none given for constructors.
			// Pos 2: method start (fully qualified name, w/o arguments).
			// Pos 3: comma-separated argument type list.

			JAVA_METHOD_INTERFACE_REGEX = Pattern.compile(wsOpt // Comment
																// helping
																// Eclipse to
																// format
					// this...

					+ "(|static" + ws + ")" // Optional "static"

					+ "(|" + type + ws + ")" // When no return type is given, we
												// have a
												// constructor.

					+ "(" + fqMethodName + ")"

					+ wsOpt

					+ "\\(" + wsOpt + "(|" + nonEmptyCommaSepTypeSeq + ")" + wsOpt + "\\)"

					+ wsOpt);

			JAVA_METHOD_INTERFACE_PATTERN_REGEX = Pattern.compile(wsOpt // Comment
					// helping
					// Eclipse to
					// format
					// this...

					+ "(|static" + ws + ")" // Optional "static"

					+ "(|" + typePattern + ws + ")" // When no return type is
													// given, we have a
					// constructor.

					+ "(" + fqMethodNamePattern + ")"

					+ wsOpt

					+ "\\(" + wsOpt + "(|" + nonEmptyCommaSepTypePatternSeq + ")" + wsOpt + "\\)"

					+ wsOpt);

			JAVA_FQ_CLASS_REGEX = Pattern.compile(wsOpt + fqMethodName + wsOpt);

			INT_LISTS_REGEX = Pattern.compile(wsOpt + "(?:|" + potentiallyEmptyCommaSepIntSeq
					+ "(?:" + wsOpt + ";(?:|" + potentiallyEmptyCommaSepIntSeq + "))*)" + wsOpt);

			INT_REGEX = Pattern.compile(intger);

			EMPTY_REGEX = Pattern.compile("");
			NON_EMPTY_REGEX = Pattern.compile("..*");

			EMPTY_OR_BOOLEAN_REGEX = Pattern.compile("|true|false");
			BOOLEAN_REGEX = Pattern.compile("true|false");

		} catch (final PatternSyntaxException ex) {
			// Cannot occur.
			assert false;
			throw new Error("Should never occur", ex);
		}
	}

	public static Pattern mkEmptyOrEnumValue(final Class<?> enumClass,
			final boolean allowLowerCase) {
		final StringBuilder sb = new StringBuilder();

		for (final Object o : enumClass.getEnumConstants()) {
			sb.append("|");
			sb.append(o.toString());

			if (allowLowerCase) {
				sb.append("|");
				sb.append(o.toString().toLowerCase());
			}
		}

		return Pattern.compile(sb.toString());
	}

	public static boolean isPattern(final String candidate) {
		// There is a question mark or a star in the pattern.
		return -1 != candidate.indexOf('?') || -1 != candidate.indexOf('*');
	}

	public static boolean patternHasDoubleStar(final String pattern) {
		return -1 != pattern.indexOf("**");
	}

	public static Pattern mkRegexPatternFromWildcardPattern(final String pat,
			final char separatorChar) {
		return Pattern.compile(mkRegexStringFromWildcardPattern(pat, separatorChar));
	}

	public static String mkRegexStringFromWildcardPattern(final String patternString,
			final char separatorChar) {
		final StringBuilder sb = new StringBuilder();
		final int len = patternString.length();
		for (int i = 0; i < len; ++i) {
			final char ch = patternString.charAt(i);
			switch (ch) {
			case '*':
				if (i + 1 < len && patternString.charAt(i + 1) == '*') {
					// Double star: Any sequence of characters.
					sb.append(".*");
					++i;
				} else {
					// Single star: Sequence of non-separator characters.
					sb.append("[^" + separatorChar + "]*");
				}
				break;
			case '?':
				// Single letter, but no separator.
				sb.append("[^" + separatorChar + "]");
				break;
			default:
				if (Character.isLetterOrDigit(ch) || ch == ';' || ch == '/') {
					// No need to quote.
					sb.append(Character.toString(ch));
				} else {
					// Quote.
					sb.append(Pattern.quote(Character.toString(ch)));
				}
				break;
			}
		}

		return sb.toString();
	}
}
